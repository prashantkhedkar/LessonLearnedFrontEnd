-- Sample optimized queries for common MasterLookup operations
-- Use these patterns in your stored procedures for better performance

-- 1. Get lookup data by type (most common pattern)
-- BEFORE (slower)
SELECT * 
FROM MasterLookup 
WHERE LookupType = 'TaskStatus' AND IsActive = 1
ORDER BY OrderBy

-- AFTER (optimized)
SELECT LookupId, LookupName, LookupNameAr, LookupCode, ColorCode, BgColorCode, OrderBy
FROM MasterLookup WITH(INDEX(IX_MasterLookup_ActiveOnly_Quick))
WHERE LookupType = 'TaskStatus' AND IsActive = 1
ORDER BY OrderBy

-- 2. JOIN with MasterLookup for lookup values
-- BEFORE (slower)
SELECT t.TaskName, ml1.LookupName as StatusName, ml2.LookupName as PriorityName
FROM Tasks t
LEFT JOIN MasterLookup ml1 ON ml1.LookupType = 'TaskStatus' AND ml1.LookupId = t.TaskStatusId
LEFT JOIN MasterLookup ml2 ON ml2.LookupType = 'TaskPriority' AND ml2.LookupId = t.TaskPriorityId
WHERE ml1.IsActive = 1 AND ml2.IsActive = 1

-- AFTER (optimized)
SELECT t.TaskName, ml1.LookupName as StatusName, ml2.LookupName as PriorityName
FROM Tasks t
LEFT JOIN MasterLookup ml1 WITH(INDEX(IX_MasterLookup_TypeId_Quick)) 
    ON ml1.LookupType = 'TaskStatus' AND ml1.LookupId = t.TaskStatusId AND ml1.IsActive = 1
LEFT JOIN MasterLookup ml2 WITH(INDEX(IX_MasterLookup_TypeId_Quick))
    ON ml2.LookupType = 'TaskPriority' AND ml2.LookupId = t.TaskPriorityId AND ml2.IsActive = 1

-- 3. Lookup by code
-- BEFORE (slower)
SELECT * 
FROM MasterLookup 
WHERE LookupCode = 'STATUS_001' AND IsActive = 1

-- AFTER (optimized)
SELECT LookupId, LookupName, LookupNameAr, LookupType, ColorCode, BgColorCode
FROM MasterLookup WITH(INDEX(IX_MasterLookup_LookupCode_Quick))
WHERE LookupCode = 'STATUS_001' AND IsActive = 1

-- 4. Get all lookup types with counts
-- BEFORE (slower)
SELECT LookupType, COUNT(*) as ItemCount
FROM MasterLookup
WHERE IsActive = 1
GROUP BY LookupType
ORDER BY LookupType

-- AFTER (optimized)
SELECT LookupType, COUNT(*) as ItemCount
FROM MasterLookup WITH(INDEX(IX_MasterLookup_Type_Active_Quick))
WHERE IsActive = 1
GROUP BY LookupType
ORDER BY LookupType

-- 5. Multiple lookup types in single query
-- BEFORE (slower)
SELECT LookupType, LookupId, LookupName, LookupNameAr, ColorCode, OrderBy
FROM MasterLookup 
WHERE LookupType IN ('TaskStatus', 'TaskPriority', 'TaskCategory') 
AND IsActive = 1
ORDER BY LookupType, OrderBy

-- AFTER (optimized with UNION ALL for better performance)
SELECT LookupType, LookupId, LookupName, LookupNameAr, ColorCode, OrderBy
FROM MasterLookup WITH(INDEX(IX_MasterLookup_ActiveOnly_Quick))
WHERE LookupType = 'TaskStatus' AND IsActive = 1
UNION ALL
SELECT LookupType, LookupId, LookupName, LookupNameAr, ColorCode, OrderBy  
FROM MasterLookup WITH(INDEX(IX_MasterLookup_ActiveOnly_Quick))
WHERE LookupType = 'TaskPriority' AND IsActive = 1
UNION ALL
SELECT LookupType, LookupId, LookupName, LookupNameAr, ColorCode, OrderBy
FROM MasterLookup WITH(INDEX(IX_MasterLookup_ActiveOnly_Quick))
WHERE LookupType = 'TaskCategory' AND IsActive = 1
ORDER BY LookupType, OrderBy

-- 6. Check if lookup value exists (for validation)
-- BEFORE (slower)
SELECT COUNT(*)
FROM MasterLookup 
WHERE LookupType = 'TaskStatus' AND LookupId = 1 AND IsActive = 1

-- AFTER (optimized)
SELECT 1
FROM MasterLookup WITH(INDEX(IX_MasterLookup_TypeId_Quick))
WHERE LookupType = 'TaskStatus' AND LookupId = 1 AND IsActive = 1

-- 7. Get lookup hierarchy (parent-child relationships)
-- If you have hierarchical lookup data
WITH LookupHierarchy AS (
    -- Parent lookups
    SELECT LookupId, LookupName, LookupNameAr, LookupCode, 0 as Level, LookupId as RootId
    FROM MasterLookup WITH(INDEX(IX_MasterLookup_ActiveOnly_Quick))
    WHERE LookupType = 'Categories' AND IsActive = 1
    
    UNION ALL
    
    -- Child lookups (assuming a ParentLookupId column exists)
    SELECT ml.LookupId, ml.LookupName, ml.LookupNameAr, ml.LookupCode, lh.Level + 1, lh.RootId
    FROM MasterLookup ml WITH(INDEX(IX_MasterLookup_TypeId_Quick))
    INNER JOIN LookupHierarchy lh ON ml.ParentLookupId = lh.LookupId
    WHERE ml.LookupType = 'Categories' AND ml.IsActive = 1
)
SELECT * FROM LookupHierarchy
ORDER BY RootId, Level, OrderBy