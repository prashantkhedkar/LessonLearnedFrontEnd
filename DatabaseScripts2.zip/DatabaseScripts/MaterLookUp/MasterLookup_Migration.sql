/****** Migration Script: Update MasterLookup Table for Performance ******/
-- This script optimizes the existing MasterLookup table structure
-- Run this during maintenance window as it involves table restructuring

SET NOCOUNT ON
GO

BEGIN TRANSACTION OptimizeMasterLookup

BEGIN TRY
    PRINT 'Starting MasterLookup optimization...'
    
    -- Step 1: Update NULL LookupCode values to prevent issues
    UPDATE [dbo].[MasterLookup] 
    SET [LookupCode] = CONCAT('CODE_', [Id])
    WHERE [LookupCode] IS NULL OR [LookupCode] = ''
    
    PRINT 'Updated NULL LookupCode values'
    
    -- Step 2: Update NULL OrderBy values
    UPDATE [dbo].[MasterLookup] 
    SET [OrderBy] = 0
    WHERE [OrderBy] IS NULL
    
    PRINT 'Updated NULL OrderBy values'
    
    -- Step 3: Reduce ImageUrl column size (backup large URLs first if needed)
    -- Note: Check if any existing URLs are longer than 500 characters
    IF EXISTS (SELECT 1 FROM [dbo].[MasterLookup] WHERE LEN([ImageUrl]) > 500)
    BEGIN
        PRINT 'Warning: Some ImageUrl values are longer than 500 characters'
        -- Optionally truncate or handle long URLs
        -- UPDATE [dbo].[MasterLookup] SET [ImageUrl] = LEFT([ImageUrl], 500) WHERE LEN([ImageUrl]) > 500
    END
    
    -- Step 4: Drop existing indexes if they exist
    IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('[dbo].[MasterLookup]') AND name = 'IX_MasterLookup_LookupCode')
        DROP INDEX [IX_MasterLookup_LookupCode] ON [dbo].[MasterLookup]
    
    IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('[dbo].[MasterLookup]') AND name = 'IX_MasterLookup_OrderBy')
        DROP INDEX [IX_MasterLookup_OrderBy] ON [dbo].[MasterLookup]
        
    IF EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('[dbo].[MasterLookup]') AND name = 'IX_MasterLookup_Type_Active')
        DROP INDEX [IX_MasterLookup_Type_Active] ON [dbo].[MasterLookup]
    
    PRINT 'Dropped existing indexes'
    
    -- Step 5: Alter column constraints
    ALTER TABLE [dbo].[MasterLookup] ALTER COLUMN [LookupCode] [nvarchar](256) NOT NULL
    ALTER TABLE [dbo].[MasterLookup] ALTER COLUMN [OrderBy] [smallint] NOT NULL
    -- Note: ImageUrl size reduction requires recreating the table in production
    
    PRINT 'Updated column constraints'
    
    -- Step 6: Add default constraints
    IF NOT EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID('[dbo].[DF_MasterLookup_OrderBy]'))
        ALTER TABLE [dbo].[MasterLookup] ADD CONSTRAINT [DF_MasterLookup_OrderBy] DEFAULT (0) FOR [OrderBy]
    
    IF NOT EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID('[dbo].[DF_MasterLookup_IsActive]'))
        ALTER TABLE [dbo].[MasterLookup] ADD CONSTRAINT [DF_MasterLookup_IsActive] DEFAULT (1) FOR [IsActive]
    
    PRINT 'Added default constraints'
    
    -- Step 7: Create optimized indexes
    
    -- Index for LookupCode queries (most common lookup pattern)
    CREATE NONCLUSTERED INDEX [IX_MasterLookup_LookupCode] ON [dbo].[MasterLookup]
    (
        [LookupCode] ASC,
        [IsActive] ASC
    )
    INCLUDE ([LookupName], [LookupNameAr], [LookupType], [LookupId], [ColorCode], [BgColorCode])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
    
    PRINT 'Created LookupCode index'
    
    -- Index for LookupType and LookupId queries (join patterns)
    CREATE NONCLUSTERED INDEX [IX_MasterLookup_Type_LookupId] ON [dbo].[MasterLookup]
    (
        [LookupType] ASC,
        [LookupId] ASC,
        [IsActive] ASC
    )
    INCLUDE ([LookupName], [LookupNameAr], [LookupCode], [ColorCode], [BgColorCode], [OrderBy])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
    
    PRINT 'Created Type/LookupId composite index'
    
    -- Index for OrderBy sorting operations
    CREATE NONCLUSTERED INDEX [IX_MasterLookup_OrderBy] ON [dbo].[MasterLookup]
    (
        [LookupType] ASC,
        [OrderBy] ASC,
        [IsActive] ASC
    )
    INCLUDE ([LookupName], [LookupNameAr], [LookupCode], [LookupId], [ColorCode])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
    
    PRINT 'Created OrderBy index'
    
    -- Filtered index for only active records (most queries filter by IsActive = 1)
    CREATE NONCLUSTERED INDEX [IX_MasterLookup_Active_Only] ON [dbo].[MasterLookup]
    (
        [LookupType] ASC,
        [LookupId] ASC
    )
    INCLUDE ([LookupName], [LookupNameAr], [LookupCode], [ColorCode], [BgColorCode], [OrderBy])
    WHERE ([IsActive] = 1)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95) ON [PRIMARY]
    
    PRINT 'Created filtered index for active records'
    
    -- Step 8: Add check constraints for data integrity
    ALTER TABLE [dbo].[MasterLookup] ADD CONSTRAINT [CK_MasterLookup_LookupType_NotEmpty] 
    CHECK ([LookupType] <> '')
    
    ALTER TABLE [dbo].[MasterLookup] ADD CONSTRAINT [CK_MasterLookup_LookupName_NotEmpty] 
    CHECK ([LookupName] <> '')
    
    ALTER TABLE [dbo].[MasterLookup] ADD CONSTRAINT [CK_MasterLookup_LookupCode_NotEmpty] 
    CHECK ([LookupCode] <> '')
    
    PRINT 'Added check constraints'
    
    -- Step 9: Update statistics for optimal query plans
    UPDATE STATISTICS [dbo].[MasterLookup] WITH FULLSCAN
    
    PRINT 'Updated statistics'
    
    COMMIT TRANSACTION OptimizeMasterLookup
    PRINT 'MasterLookup optimization completed successfully!'
    
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION OptimizeMasterLookup
    
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE()
    DECLARE @ErrorNumber INT = ERROR_NUMBER()
    DECLARE @ErrorLine INT = ERROR_LINE()
    
    PRINT 'Error occurred during optimization:'
    PRINT 'Error Number: ' + CAST(@ErrorNumber AS NVARCHAR(50))
    PRINT 'Error Line: ' + CAST(@ErrorLine AS NVARCHAR(50))
    PRINT 'Error Message: ' + @ErrorMessage
    
    -- Re-throw the error
    THROW
END CATCH

-- Performance monitoring query (run after optimization)
/*
-- Use this to monitor index usage after deployment
SELECT 
    i.name AS IndexName,
    s.user_seeks,
    s.user_scans,
    s.user_lookups,
    s.user_updates,
    s.avg_fragmentation_in_percent
FROM sys.dm_db_index_usage_stats s
INNER JOIN sys.indexes i ON s.object_id = i.object_id AND s.index_id = i.index_id
LEFT JOIN sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('[dbo].[MasterLookup]'), NULL, NULL, 'LIMITED') f
    ON s.object_id = f.object_id AND s.index_id = f.index_id
WHERE s.object_id = OBJECT_ID('[dbo].[MasterLookup]')
ORDER BY s.user_seeks + s.user_scans + s.user_lookups DESC
*/