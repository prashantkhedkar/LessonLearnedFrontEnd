/****** SQL Server Edition Compatibility Check ******/
-- Run this script first to check SQL Server edition and capabilities

SET NOCOUNT ON
GO

PRINT '=== SQL Server Edition and Feature Compatibility Check ==='
PRINT ''

-- Check SQL Server Edition
DECLARE @Edition NVARCHAR(128) = CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128))
DECLARE @Version NVARCHAR(128) = CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128))
DECLARE @Level NVARCHAR(128) = CAST(SERVERPROPERTY('ProductLevel') AS NVARCHAR(128))

PRINT 'SQL Server Edition: ' + @Edition
PRINT 'SQL Server Version: ' + @Version
PRINT 'SQL Server Level: ' + @Level
PRINT ''

-- Check if online index operations are supported
IF @Edition LIKE '%Enterprise%' OR @Edition LIKE '%Developer%' OR @Edition LIKE '%Azure%'
BEGIN
    PRINT '? Online index operations are SUPPORTED'
    PRINT '  You can use ONLINE=ON for minimal downtime'
END
ELSE
BEGIN
    PRINT '? Online index operations are NOT SUPPORTED'
    PRINT '  Index creation will require brief table locks'
    PRINT '  Recommendation: Run during maintenance window or low usage periods'
END

PRINT ''

-- Check if filtered indexes are supported (SQL Server 2008+)
IF CAST(LEFT(@Version, CHARINDEX('.', @Version) - 1) AS INT) >= 10
BEGIN
    PRINT '? Filtered indexes are SUPPORTED'
END
ELSE
BEGIN
    PRINT '? Filtered indexes are NOT SUPPORTED'
    PRINT '  Will use regular indexes instead'
END

PRINT ''

-- Check current MasterLookup table size and structure
IF OBJECT_ID('[dbo].[MasterLookup]') IS NOT NULL
BEGIN
    DECLARE @RowCount BIGINT
    DECLARE @DataSizeMB DECIMAL(10,2)
    DECLARE @IndexSizeMB DECIMAL(10,2)
    
    -- Get row count
    SELECT @RowCount = SUM(rows) 
    FROM sys.partitions 
    WHERE object_id = OBJECT_ID('[dbo].[MasterLookup]') 
    AND index_id IN (0,1)
    
    -- Get size information
    SELECT 
        @DataSizeMB = SUM(CASE WHEN index_id IN (0,1) THEN used_page_count * 8.0 / 1024 ELSE 0 END),
        @IndexSizeMB = SUM(CASE WHEN index_id > 1 THEN used_page_count * 8.0 / 1024 ELSE 0 END)
    FROM sys.dm_db_partition_stats 
    WHERE object_id = OBJECT_ID('[dbo].[MasterLookup]')
    
    PRINT 'MasterLookup Table Analysis:'
    PRINT '  Total Rows: ' + FORMAT(@RowCount, 'N0')
    PRINT '  Data Size: ' + CAST(@DataSizeMB AS NVARCHAR(20)) + ' MB'
    PRINT '  Index Size: ' + CAST(@IndexSizeMB AS NVARCHAR(20)) + ' MB'
    
    -- Estimate index creation time
    IF @RowCount < 100000
        PRINT '  Estimated index creation time: < 1 minute'
    ELSE IF @RowCount < 1000000
        PRINT '  Estimated index creation time: 1-5 minutes'
    ELSE
        PRINT '  Estimated index creation time: 5+ minutes'
    
    PRINT ''
    
    -- Check existing indexes
    PRINT 'Current Indexes on MasterLookup:'
    SELECT 
        i.name AS IndexName,
        i.type_desc AS IndexType,
        CASE WHEN i.is_unique = 1 THEN 'UNIQUE' ELSE '' END AS IsUnique,
        CASE WHEN i.has_filter = 1 THEN 'FILTERED' ELSE '' END AS IsFiltered
    FROM sys.indexes i
    WHERE i.object_id = OBJECT_ID('[dbo].[MasterLookup]')
    AND i.index_id > 0
    ORDER BY i.index_id
    
    PRINT ''
    
    -- Check for potential issues
    DECLARE @NullLookupCodes INT = (SELECT COUNT(*) FROM [dbo].[MasterLookup] WHERE [LookupCode] IS NULL OR [LookupCode] = '')
    DECLARE @NullOrderBy INT = (SELECT COUNT(*) FROM [dbo].[MasterLookup] WHERE [OrderBy] IS NULL)
    DECLARE @InactiveRecords INT = (SELECT COUNT(*) FROM [dbo].[MasterLookup] WHERE [IsActive] = 0)
    
    PRINT 'Data Quality Issues to Fix:'
    IF @NullLookupCodes > 0
        PRINT '  ? ' + CAST(@NullLookupCodes AS NVARCHAR(10)) + ' records with NULL/empty LookupCode'
    ELSE
        PRINT '  ? No NULL LookupCode values found'
        
    IF @NullOrderBy > 0
        PRINT '  ? ' + CAST(@NullOrderBy AS NVARCHAR(10)) + ' records with NULL OrderBy'
    ELSE
        PRINT '  ? No NULL OrderBy values found'
        
    PRINT '  ? ' + CAST(@InactiveRecords AS NVARCHAR(10)) + ' inactive records (IsActive = 0)'
END
ELSE
BEGIN
    PRINT '? MasterLookup table NOT FOUND!'
    PRINT 'Please ensure the table exists before running optimization scripts.'
END

PRINT ''
PRINT '=== RECOMMENDATIONS ==='

IF @Edition NOT LIKE '%Enterprise%' AND @Edition NOT LIKE '%Developer%' AND @Edition NOT LIKE '%Azure%'
BEGIN
    PRINT '1. Use MasterLookup_QuickFix.sql (modified for Standard Edition)'
    PRINT '2. Schedule index creation during low-usage periods'
    PRINT '3. Monitor for blocking during index creation'
    PRINT '4. Consider table size and expected lock duration'
END
ELSE
BEGIN
    PRINT '1. You can use online index operations for minimal impact'
    PRINT '2. Safe to run during business hours'
END

PRINT ''
PRINT 'Next Steps:'
PRINT '1. Review the recommendations above'
PRINT '2. Plan maintenance window if needed'
PRINT '3. Run MasterLookup_QuickFix.sql for immediate improvements'
PRINT '4. Monitor performance improvements'

PRINT ''
PRINT '=== END OF COMPATIBILITY CHECK ==='