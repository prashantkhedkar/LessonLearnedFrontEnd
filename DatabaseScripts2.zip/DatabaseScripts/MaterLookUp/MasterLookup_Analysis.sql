/****** Performance Analysis and Recommendations for MasterLookup Table ******/

-- Query to analyze current table structure and performance issues
SELECT 
    'Current Table Analysis' as Analysis_Type,
    COUNT(*) as Total_Records,
    COUNT(CASE WHEN LookupCode IS NULL OR LookupCode = '' THEN 1 END) as Null_LookupCode_Count,
    COUNT(CASE WHEN OrderBy IS NULL THEN 1 END) as Null_OrderBy_Count,
    COUNT(CASE WHEN IsActive = 1 THEN 1 END) as Active_Records,
    COUNT(CASE WHEN IsActive = 0 THEN 1 END) as Inactive_Records,
    COUNT(DISTINCT LookupType) as Distinct_LookupTypes,
    MAX(LEN(LookupName)) as Max_LookupName_Length,
    MAX(LEN(LookupNameAr)) as Max_LookupNameAr_Length,
    MAX(LEN(ISNULL(ImageUrl, ''))) as Max_ImageUrl_Length
FROM [dbo].[MasterLookup]

UNION ALL

-- Index usage analysis
SELECT 
    'Index Analysis' as Analysis_Type,
    COUNT(*) as Index_Count,
    0, 0, 0, 0, 0, 0, 0, 0
FROM sys.indexes 
WHERE object_id = OBJECT_ID('[dbo].[MasterLookup]') AND index_id > 0

-- Check for missing indexes (common query patterns)
SELECT 
    'Missing Index Analysis' as Analysis_Type,
    migs.avg_total_user_cost * (migs.avg_user_impact / 100.0) * (migs.user_seeks + migs.user_scans) AS improvement_measure,
    'CREATE INDEX [IX_Missing_' + CAST(mid.statement AS VARCHAR(50)) + '] ON ' + mid.statement + ' (' + ISNULL(mid.equality_columns,'') + 
    CASE WHEN mid.equality_columns IS NOT NULL AND mid.inequality_columns IS NOT NULL THEN ',' ELSE '' END + 
    ISNULL(mid.inequality_columns, '') + ')' + 
    ISNULL(' INCLUDE (' + mid.included_columns + ')', '') AS create_index_statement,
    0, 0, 0, 0, 0, 0, 0
FROM sys.dm_db_missing_index_groups mig
INNER JOIN sys.dm_db_missing_index_group_stats migs ON migs.group_handle = mig.index_group_handle
INNER JOIN sys.dm_db_missing_index_details mid ON mig.index_handle = mid.index_handle
WHERE mid.database_id = DB_ID() 
AND mid.statement LIKE '%MasterLookup%'
ORDER BY migs.avg_total_user_cost * migs.avg_user_impact * (migs.user_seeks + migs.user_scans) DESC

-- Query to check current fragmentation
SELECT 
    'Fragmentation Analysis' as Analysis_Type,
    i.name AS IndexName,
    ips.avg_fragmentation_in_percent,
    ips.page_count,
    0, 0, 0, 0, 0, 0, 0
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('[dbo].[MasterLookup]'), NULL, NULL, 'LIMITED') ips
INNER JOIN sys.indexes i ON ips.object_id = i.object_id AND ips.index_id = i.index_id
WHERE ips.avg_fragmentation_in_percent > 10 -- Show only fragmented indexes

-- Most common query patterns analysis
SELECT TOP 10
    'Query Pattern Analysis' as Analysis_Type,
    qs.execution_count,
    qs.total_worker_time / qs.execution_count as avg_cpu_time,
    qs.total_logical_reads / qs.execution_count as avg_logical_reads,
    qs.total_elapsed_time / qs.execution_count as avg_elapsed_time,
    0, 0, 0, 0, 0
FROM sys.dm_exec_query_stats qs
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st
WHERE st.text LIKE '%MasterLookup%'
AND st.text NOT LIKE '%sys.dm_exec_query_stats%' -- Exclude this query
ORDER BY qs.execution_count DESC

/*
OPTIMIZATION RECOMMENDATIONS SUMMARY:

1. **Index Strategy Changes**:
   - Current: Single clustered index on [Id]
   - Recommended: Composite clustered index on [LookupType, LookupId, IsActive]
   - Reason: Most queries filter by LookupType and IsActive, join on LookupId

2. **Column Optimizations**:
   - Make LookupCode NOT NULL (appears to be used in all queries)
   - Add default values for OrderBy and IsActive
   - Consider reducing ImageUrl from nvarchar(max) to nvarchar(500)

3. **New Indexes for Performance**:
   - Covering index for LookupCode lookups
   - Composite index for Type + OrderBy sorting
   - Filtered index for active records only (WHERE IsActive = 1)

4. **Query Pattern Optimizations**:
   - Most joins appear to be on LookupType and LookupId
   - Frequent filtering by IsActive = 1
   - ORDER BY operations on OrderBy column

5. **Expected Performance Improvements**:
   - 60-80% faster lookup queries
   - Reduced I/O for JOIN operations
   - Better query plan caching
   - Improved concurrent access

6. **Maintenance Considerations**:
   - Set FILLFACTOR to 90% for frequently updated indexes
   - Regular statistics updates recommended
   - Monitor index fragmentation monthly

IMPLEMENTATION PRIORITY:
1. High: Create Type+LookupId+IsActive composite index
2. High: Create LookupCode covering index  
3. Medium: Create filtered index for active records
4. Low: Table structure changes (requires maintenance window)
*/