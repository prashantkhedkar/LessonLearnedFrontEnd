/****** Optimized MasterLookup Table Structure ******/

-- Drop existing table (backup first in production!)
-- DROP TABLE [dbo].[MasterLookup]

-- Create optimized MasterLookup table
CREATE TABLE [dbo].[MasterLookup_Optimized](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[LookupName] [nvarchar](256) NOT NULL,
	[LookupNameAr] [nvarchar](512) NOT NULL,
	[LookupType] [nvarchar](256) NOT NULL,
	[LookupId] [bigint] NOT NULL,
	[LookupCode] [nvarchar](256) NOT NULL, -- Made NOT NULL for better indexing
	[ColorCode] [nvarchar](56) NULL,
	[BgColorCode] [nvarchar](100) NULL,
	[ImageUrl] [nvarchar](500) NULL, -- Reduced from MAX for better performance
	[OrderBy] [smallint] NOT NULL DEFAULT(0), -- Made NOT NULL with default
	[IsActive] [bit] NOT NULL DEFAULT(1), -- Added default value
	
	-- Performance Optimization: Create clustered index on most queried columns
	CONSTRAINT [PK_MasterLookup_Optimized] PRIMARY KEY CLUSTERED 
	(
		[LookupType] ASC,
		[LookupId] ASC,
		[IsActive] ASC
	)WITH (
		PAD_INDEX = OFF, 
		STATISTICS_NORECOMPUTE = OFF, 
		IGNORE_DUP_KEY = OFF, 
		ALLOW_ROW_LOCKS = ON, 
		ALLOW_PAGE_LOCKS = ON, 
		OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF,
		FILLFACTOR = 90 -- Leave 10% space for updates
	) ON [PRIMARY]
) ON [PRIMARY]
GO

-- Create non-clustered indexes for performance optimization

-- Index for LookupCode queries
CREATE NONCLUSTERED INDEX [IX_MasterLookup_LookupCode] ON [dbo].[MasterLookup_Optimized]
(
	[LookupCode] ASC,
	[IsActive] ASC
)
INCLUDE ([LookupName], [LookupNameAr], [ColorCode]) -- Include commonly selected columns
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

-- Index for OrderBy sorting operations
CREATE NONCLUSTERED INDEX [IX_MasterLookup_OrderBy] ON [dbo].[MasterLookup_Optimized]
(
	[LookupType] ASC,
	[OrderBy] ASC,
	[IsActive] ASC
)
INCLUDE ([LookupName], [LookupNameAr], [LookupCode], [ColorCode])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

-- Index for ID lookups (covering index)
CREATE UNIQUE NONCLUSTERED INDEX [IX_MasterLookup_Id_Covering] ON [dbo].[MasterLookup_Optimized]
(
	[Id] ASC
)
INCLUDE ([LookupName], [LookupNameAr], [LookupType], [LookupId], [LookupCode], [ColorCode], [BgColorCode], [OrderBy], [IsActive])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95) ON [PRIMARY]
GO

-- Index for active records by type (most common query pattern)
CREATE NONCLUSTERED INDEX [IX_MasterLookup_Type_Active] ON [dbo].[MasterLookup_Optimized]
(
	[LookupType] ASC,
	[IsActive] ASC
)
INCLUDE ([LookupId], [LookupName], [LookupNameAr], [LookupCode], [ColorCode], [OrderBy])
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
GO

-- Add constraints for data integrity
ALTER TABLE [dbo].[MasterLookup_Optimized] ADD CONSTRAINT [CK_MasterLookup_LookupType_NotEmpty] 
CHECK ([LookupType] <> '')
GO

ALTER TABLE [dbo].[MasterLookup_Optimized] ADD CONSTRAINT [CK_MasterLookup_LookupName_NotEmpty] 
CHECK ([LookupName] <> '')
GO

ALTER TABLE [dbo].[MasterLookup_Optimized] ADD CONSTRAINT [CK_MasterLookup_LookupCode_NotEmpty] 
CHECK ([LookupCode] <> '')
GO

-- Create a filtered index for only active records (common query pattern)
CREATE NONCLUSTERED INDEX [IX_MasterLookup_Active_Only] ON [dbo].[MasterLookup_Optimized]
(
	[LookupType] ASC,
	[LookupId] ASC,
	[OrderBy] ASC
)
INCLUDE ([LookupName], [LookupNameAr], [LookupCode], [ColorCode], [BgColorCode])
WHERE ([IsActive] = 1)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = ON, DROP_EXISTING = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 95) ON [PRIMARY]
GO