using Infrastructure.Base;
using Infrastructure.Base.Services;
using Microsoft.AspNetCore.Mvc;

namespace Examples
{
    /// <summary>
    /// Example showing different ways to get client IP addresses for logging
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class ExampleController : CustomBaseController
    {
        private readonly IClientIpService _clientIpService;
        private readonly ILogger<ExampleController> _logger;

        public ExampleController(
            IHttpContextAccessor httpContextAccessor, 
            IClientIpService clientIpService,
            ILogger<ExampleController> logger) : base(httpContextAccessor)
        {
            _clientIpService = clientIpService;
            _logger = logger;
        }

        /// <summary>
        /// Example 1: Using the base controller method
        /// </summary>
        [HttpGet("method1")]
        public IActionResult GetClientIpMethod1()
        {
            var clientIp = GetClientIpAddress();
            
            _logger.LogInformation("Client IP (Method 1): {ClientIp} - User: {UserId}", 
                clientIp, GetUserId());
            
            return Ok(new { ClientIp = clientIp, Method = "Base Controller" });
        }

        /// <summary>
        /// Example 2: Using the dedicated service
        /// </summary>
        [HttpGet("method2")]
        public IActionResult GetClientIpMethod2()
        {
            var clientIp = _clientIpService.GetClientIpAddress();
            
            _logger.LogInformation("Client IP (Method 2): {ClientIp} - User: {UserId}", 
                clientIp, GetUserId());
            
            return Ok(new { ClientIp = clientIp, Method = "Dedicated Service" });
        }

        /// <summary>
        /// Example 3: Getting detailed IP information
        /// </summary>
        [HttpGet("detailed")]
        public IActionResult GetDetailedIpInfo()
        {
            var ipInfo = _clientIpService.GetDetailedIpInfo();
            
            _logger.LogInformation("Detailed IP Info - Client: {ClientIp}, Direct: {DirectIp}, Proxied: {IsProxied} - User: {UserId}", 
                ipInfo.ClientIp, ipInfo.DirectConnectionIp, ipInfo.IsProxied, GetUserId());
            
            return Ok(ipInfo);
        }

        /// <summary>
        /// Example 4: Complete logging with all user context
        /// </summary>
        [HttpPost("complete-log")]
        public IActionResult CompleteLoggingExample([FromBody] object data)
        {
            var clientIp = GetClientIpAddress();
            var userId = GetUserId();
            var userEmail = GetUserEmail();
            var language = GetLanguage();
            var userRole = GetUserRole();

            // Comprehensive logging
            _logger.LogInformation(
                "Action: {Action} | User: {UserId} ({UserEmail}) | Role: {UserRole} | " +
                "IP: {ClientIp} | Language: {Language} | Data: {Data}",
                nameof(CompleteLoggingExample), userId, userEmail, userRole, 
                clientIp, language, data?.ToString());

            return Ok(new 
            { 
                Success = true, 
                ClientIp = clientIp,
                UserId = userId,
                Timestamp = DateTime.UtcNow
            });
        }
    }
}