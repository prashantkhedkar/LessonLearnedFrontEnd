import React, { useRef, useState } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './ImageSlider.css';

interface SlideData {
  id: number;
  image: string;
  title: string;
  description: string;
}

interface ImageSliderProps {
  slides?: SlideData[];
}

const ImageSlider: React.FC<ImageSliderProps> = ({ slides }) => {
  const sliderRef = useRef<Slider>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  

 

  const handleNext = () => {
    if (sliderRef.current) {
      if (currentSlide === 1) { // Last slide (we have 2 slides: 0 and 1)
        sliderRef.current.slickGoTo(0); // Go to first slide
        setCurrentSlide(0);
      } else {
        sliderRef.current.slickNext();
        setCurrentSlide(currentSlide + 1);
      }
    }
  };

  const handlePrev = () => {
    if (sliderRef.current) {
      if (currentSlide === 0) { // First slide
        sliderRef.current.slickGoTo(1); // Go to last slide
        setCurrentSlide(1);
      } else {
        sliderRef.current.slickPrev();
        setCurrentSlide(currentSlide - 1);
      }
    }
  };

  const CustomNextArrow = (props: any) => {
    return (
      <div 
        className="custom-arrow custom-next-arrow" 
        onClick={() => {
          handleNext();
        }}
        style={{
          display: 'flex', // Always show the arrow
          opacity: 1 // Always fully visible
        }}
      >
        →
      </div>
    );
  };

  const CustomPrevArrow = (props: any) => {
    return (
      <div 
        className="custom-arrow custom-prev-arrow" 
        onClick={() => {
          handlePrev();
        }}
        style={{
          display: 'flex', // Always show the arrow
          opacity: 1 // Always fully visible
        }}
      >
        ←
      </div>
    );
  };

  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: false,
    nextArrow: <CustomNextArrow />,
    prevArrow: <CustomPrevArrow />,
    beforeChange: (oldIndex: number, newIndex: number) => {
      setCurrentSlide(newIndex);
    },
     
  };

  return (
    <div className="image-slider-container">
      <h2 className="slider-title">Image Gallery</h2>
      <Slider ref={sliderRef} {...settings}>
        <div className="slide">
          <div className="slide-content">
            <img 
              src="https://via.placeholder.com/800x400/FF6B6B/FFFFFF?text=Sample+1" 
              alt="Sample Slide 1"
              className="slide-image"
            />
            <div className="slide-overlay">
              <h3 className="slide-title">Sample Title 1</h3>
              <p className="slide-description">This is a sample description for the first slide</p>
            </div>
          </div>
        </div>
        <div className="slide">
          <div className="slide-content">
            <img 
              src="https://via.placeholder.com/800x400/4ECDC4/FFFFFF?text=Sample+2" 
              alt="Sample Slide 2"
              className="slide-image"
            />
            <div className="slide-overlay">
              <h3 className="slide-title">Sample Title 2</h3>
              <p className="slide-description">This is a sample description for the second slide</p>
            </div>
          </div>
        </div>
      </Slider>
    </div>
  );
};

export default ImageSlider;