-- SQL Server Memory Diagnostic Queries for Stored Procedures
-- Database-specific queries to identify stored procedures causing memory issues
-- Replace 'YourDatabaseName' with your actual database name

USE YourDatabaseName; -- Change this to your specific database name
GO

-- =============================================================================
-- 1. Query to find stored procedures with highest memory consumption in current database
-- =============================================================================
SELECT TOP 20
    p.name AS ProcedureName,
    s.name AS schema_name,
    qs.execution_count,
    qs.total_worker_time / 1000 AS total_cpu_time_ms,
    qs.total_worker_time / qs.execution_count / 1000 AS avg_cpu_time_ms,
    qs.total_logical_reads,
    qs.total_logical_reads / qs.execution_count AS avg_logical_reads,
    qs.total_logical_writes,
    qs.total_logical_writes / qs.execution_count AS avg_logical_writes,
    qs.total_physical_reads,
    qs.total_physical_reads / qs.execution_count AS avg_physical_reads,
    qs.total_elapsed_time / 1000 AS total_elapsed_time_ms,
    qs.total_elapsed_time / qs.execution_count / 1000 AS avg_elapsed_time_ms,
    qs.cached_time AS creation_time,
    qs.last_execution_time
FROM sys.procedures p
INNER JOIN sys.schemas s ON p.schema_id = s.schema_id
INNER JOIN sys.dm_exec_procedure_stats qs ON p.object_id = qs.object_id
WHERE p.is_ms_shipped = 0 -- Exclude system stored procedures
  AND DB_NAME(qs.database_id) = DB_NAME() -- Current database only
ORDER BY (qs.total_logical_reads / qs.execution_count) DESC; -- Sort by average logical reads (memory usage)

-- =============================================================================
-- 2. Query to find stored procedures with highest total memory consumption in current database
-- =============================================================================
SELECT TOP 20
    OBJECT_NAME(object_id, database_id) AS ProcedureName,
    OBJECT_SCHEMA_NAME(object_id, database_id) AS SchemaName,
    execution_count,
    total_logical_reads,
    total_logical_reads / execution_count AS avg_logical_reads,
    total_logical_reads / execution_count AS avg_logical_reads_per_execution,
    total_worker_time / 1000 AS total_cpu_time_ms,
    total_elapsed_time / 1000 AS total_elapsed_time_ms,
    cached_time AS creation_time,
    last_execution_time
FROM sys.dm_exec_procedure_stats
WHERE database_id = DB_ID() -- Current database only
ORDER BY total_logical_reads DESC; -- Sort by total logical reads

-- =============================================================================
-- 3. Query to find stored procedures consuming most buffer pool memory in current database
-- =============================================================================
SELECT TOP 20
    p.name AS ProcedureName,
    s.name AS SchemaName,
    SUM(au.total_pages) * 8 / 1024 AS total_space_MB,
    SUM(au.used_pages) * 8 / 1024 AS used_space_MB,
    SUM(au.data_pages) * 8 / 1024 AS data_space_MB
FROM sys.procedures p
INNER JOIN sys.schemas s ON p.schema_id = s.schema_id
INNER JOIN sys.indexes i ON p.object_id = i.object_id
INNER JOIN sys.partitions pt ON i.object_id = pt.object_id AND i.index_id = pt.index_id
INNER JOIN sys.allocation_units au ON pt.partition_id = au.container_id
WHERE au.type IN (1, 3) -- IN_ROW_DATA and LOB_DATA
  AND p.is_ms_shipped = 0 -- Exclude system stored procedures
GROUP BY p.name, s.name
ORDER BY total_space_MB DESC;

-- =============================================================================
-- 4. Query to check plan cache usage by stored procedures in current database
-- =============================================================================
SELECT TOP 20
    OBJECT_NAME(st.objectid, st.dbid) AS ProcedureName,
    OBJECT_SCHEMA_NAME(st.objectid, st.dbid) AS SchemaName,
    cp.objtype,
    cp.cacheobjtype,
    cp.size_in_bytes / 1024 AS size_in_kb,
    cp.size_in_bytes / 1024.0 / 1024 AS size_in_mb,
    cp.usecounts,
    LEFT(st.text, 100) + '...' AS sql_text_preview,
    cp.plan_handle
FROM sys.dm_exec_cached_plans cp
CROSS APPLY sys.dm_exec_sql_text(cp.plan_handle) st
WHERE cp.objtype = 'Proc' -- Procedures only
  AND st.dbid = DB_ID() -- Current database only
  AND st.objectid IS NOT NULL -- Only stored procedures (not ad-hoc queries)
ORDER BY cp.size_in_bytes DESC;

-- =============================================================================
-- 5. Query to find stored procedures with memory grants (sorting/hashing operations) in current database
-- =============================================================================
SELECT 
    r.session_id,
    r.request_id,
    OBJECT_NAME(st.objectid, st.dbid) AS ProcedureName,
    OBJECT_SCHEMA_NAME(st.objectid, st.dbid) AS SchemaName,
    r.start_time,
    r.status,
    r.command,
    mg.requested_memory_kb,
    mg.granted_memory_kb,
    mg.required_memory_kb,
    mg.used_memory_kb,
    mg.max_used_memory_kb,
    LEFT(st.text, 100) + '...' AS sql_text_preview
FROM sys.dm_exec_requests r
INNER JOIN sys.dm_exec_query_memory_grants mg ON r.session_id = mg.session_id 
    AND r.request_id = mg.request_id
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) st
WHERE mg.granted_memory_kb > 0
  AND st.dbid = DB_ID() -- Current database only
  AND st.objectid IS NOT NULL -- Only stored procedures
ORDER BY mg.granted_memory_kb DESC;

-- =============================================================================
-- 6. Query to find stored procedures with high compilation memory usage in current database
-- =============================================================================
SELECT TOP 20
    p.name AS ProcedureName,
    s.name AS SchemaName,
    qs.execution_count,
    qs.total_worker_time / 1000 AS total_cpu_time_ms,
    qs.total_worker_time / qs.execution_count / 1000 AS avg_cpu_time_ms,
    qs.total_logical_reads,
    qs.total_logical_reads / qs.execution_count AS avg_logical_reads,
    qs.cached_time AS creation_time,
    qs.last_execution_time,
    qs.last_worker_time / 1000 AS last_cpu_time_ms,
    -- Check for potential recompilation indicators
    CASE WHEN qs.execution_count = 1 THEN 'Potential recompilation' ELSE 'Normal' END AS recompilation_indicator
FROM sys.dm_exec_procedure_stats qs
INNER JOIN sys.procedures p ON qs.object_id = p.object_id
INNER JOIN sys.schemas s ON p.schema_id = s.schema_id
WHERE p.is_ms_shipped = 0 -- Exclude system stored procedures
  AND qs.database_id = DB_ID() -- Current database only
ORDER BY (qs.total_logical_reads / qs.execution_count) DESC;

-- =============================================================================
-- 7. Query to identify stored procedures with parameter sniffing issues in current database
-- =============================================================================
SELECT TOP 20
    p.name AS ProcedureName,
    s.name AS SchemaName,
    qs.execution_count,
    qs.total_logical_reads / qs.execution_count AS avg_logical_reads,
    qs.min_logical_reads,
    qs.max_logical_reads,
    CASE 
        WHEN qs.min_logical_reads > 0 
        THEN qs.max_logical_reads / qs.min_logical_reads 
        ELSE 0 
    END AS read_variance_ratio,
    qs.cached_time AS creation_time,
    qs.last_execution_time
FROM sys.dm_exec_procedure_stats qs
INNER JOIN sys.procedures p ON qs.object_id = p.object_id
INNER JOIN sys.schemas s ON p.schema_id = s.schema_id
WHERE qs.execution_count > 10 -- Only procedures executed more than 10 times
  AND qs.min_logical_reads > 0
  AND (qs.max_logical_reads / qs.min_logical_reads) > 10 -- High variance in reads
  AND p.is_ms_shipped = 0 -- Exclude system stored procedures
  AND qs.database_id = DB_ID() -- Current database only
ORDER BY read_variance_ratio DESC;

-- =============================================================================
-- 8. Query to get stored procedure execution statistics summary for current database
-- =============================================================================
SELECT 
    'Total Stored Procedures' AS metric,
    COUNT(*) AS count_value,
    NULL AS avg_value,
    NULL AS max_value
FROM sys.procedures 
WHERE is_ms_shipped = 0

UNION ALL

SELECT 
    'Executed Stored Procedures',
    COUNT(DISTINCT qs.object_id),
    NULL,
    NULL
FROM sys.dm_exec_procedure_stats qs
WHERE qs.database_id = DB_ID()

UNION ALL

SELECT 
    'Average Logical Reads per Execution',
    NULL,
    AVG(qs.total_logical_reads / qs.execution_count),
    MAX(qs.total_logical_reads / qs.execution_count)
FROM sys.dm_exec_procedure_stats qs
WHERE qs.database_id = DB_ID()

UNION ALL

SELECT 
    'Average CPU Time (ms) per Execution',
    NULL,
    AVG(qs.total_worker_time / qs.execution_count / 1000),
    MAX(qs.total_worker_time / qs.execution_count / 1000)
FROM sys.dm_exec_procedure_stats qs
WHERE qs.database_id = DB_ID();

-- =============================================================================
-- 9. Query to find stored procedures causing blocking due to memory pressure in current database
-- =============================================================================
SELECT 
    r.session_id,
    r.blocking_session_id,
    OBJECT_NAME(st.objectid, st.dbid) AS ProcedureName,
    OBJECT_SCHEMA_NAME(st.objectid, st.dbid) AS SchemaName,
    r.wait_type,
    r.wait_time,
    r.wait_resource,
    r.total_elapsed_time,
    r.cpu_time,
    r.logical_reads,
    r.reads,
    r.writes,
    LEFT(st.text, 100) + '...' AS sql_text_preview
FROM sys.dm_exec_requests r
CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) st
WHERE (r.wait_type LIKE '%MEMORY%' 
   OR r.wait_type IN ('RESOURCE_SEMAPHORE', 'RESOURCE_SEMAPHORE_QUERY_COMPILE'))
  AND st.dbid = DB_ID() -- Current database only
  AND st.objectid IS NOT NULL -- Only stored procedures
ORDER BY r.wait_time DESC;

-- =============================================================================
-- 10. Query to check buffer pool usage for current database
-- =============================================================================
SELECT 
    'Current Database Buffer Pool Usage' AS description,
    COUNT(*) * 8 / 1024 AS buffer_pool_mb,
    COUNT(*) AS page_count,
    CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM sys.dm_os_buffer_descriptors WHERE database_id > 4) AS DECIMAL(5,2)) AS percentage_of_total
FROM sys.dm_os_buffer_descriptors
WHERE database_id = DB_ID();

-- =============================================================================
-- 11. Query to find stored procedures with most recent executions and high memory usage
-- =============================================================================
SELECT TOP 20
    p.name AS ProcedureName,
    s.name AS SchemaName,
    qs.execution_count,
    qs.total_logical_reads / qs.execution_count AS avg_logical_reads,
    qs.last_execution_time,
    DATEDIFF(MINUTE, qs.last_execution_time, GETDATE()) AS minutes_since_last_execution,
    qs.total_elapsed_time / qs.execution_count / 1000 AS avg_elapsed_time_ms,
    CASE 
        WHEN qs.last_execution_time > DATEADD(HOUR, -1, GETDATE()) THEN 'Recently Active'
        WHEN qs.last_execution_time > DATEADD(DAY, -1, GETDATE()) THEN 'Active Today'
        ELSE 'Less Active'
    END AS activity_status
FROM sys.dm_exec_procedure_stats qs
INNER JOIN sys.procedures p ON qs.object_id = p.object_id
INNER JOIN sys.schemas s ON p.schema_id = s.schema_id
WHERE p.is_ms_shipped = 0 -- Exclude system stored procedures
  AND qs.database_id = DB_ID() -- Current database only
  AND (qs.total_logical_reads / qs.execution_count) > 1000 -- High memory usage threshold
ORDER BY qs.last_execution_time DESC;

-- =============================================================================
-- Instructions for Usage:
-- =============================================================================
/*
IMPORTANT: Replace 'YourDatabaseName' at the top with your actual database name!

Database-Specific Stored Procedure Memory Diagnostic Queries:

1. Run Query #1 to identify stored procedures with highest average memory usage
2. Run Query #2 to find stored procedures with highest total memory consumption
3. Run Query #5 to check active memory grants for stored procedures (run when issues occur)
4. Run Query #8 to get stored procedure execution summary for your database
5. Run Query #9 to identify memory-related blocking from stored procedures
6. Run Query #7 to find parameter sniffing issues in stored procedures
7. Run Query #11 to see recently executed memory-intensive stored procedures

Key Features:
- All queries are filtered to current database only (using DB_ID() and DB_NAME())
- Excludes system stored procedures (is_ms_shipped = 0)
- Focuses specifically on stored procedures (not ad-hoc queries)
- Provides schema information for better identification

Key Metrics to Monitor:
- avg_logical_reads: Average memory pages read per execution
- total_logical_reads: Total memory pages read across all executions
- granted_memory_kb: Memory allocated for sorting/hashing operations
- read_variance_ratio: High values indicate parameter sniffing issues

Recommendations:
- Focus on stored procedures with high avg_logical_reads (> 10,000 pages)
- Investigate procedures with high read_variance_ratio (> 100)
- Monitor memory grants during peak usage times
- Consider query optimization for top memory consumers
- Check for missing indexes on tables used by high-memory procedures

Thresholds to Watch:
- avg_logical_reads > 10,000: Consider optimization
- read_variance_ratio > 100: Likely parameter sniffing issue
- granted_memory_kb > 100,000: High sorting/hashing memory usage
- execution_count = 1 with high logical reads: Possible recompilation issue
*/