-- =============================================
-- Script: Index Performance Monitoring for PushNotification
-- Purpose: Monitor and track index effectiveness over time
-- Author: Database Optimization
-- Date: Created for ongoing performance monitoring
-- =============================================

USE [JointPortal_QA]
GO

PRINT '========================================'
PRINT 'INDEX PERFORMANCE MONITORING'
PRINT '========================================'

-- Create monitoring table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'IndexPerformanceMonitoring')
BEGIN
    CREATE TABLE [dbo].[IndexPerformanceMonitoring] (
        [MonitoringId] BIGINT IDENTITY(1,1) PRIMARY KEY,
        [TableName] NVARCHAR(128) NOT NULL,
        [IndexName] NVARCHAR(128) NOT NULL,
        [UserSeeks] BIGINT NULL,
        [UserScans] BIGINT NULL,
        [UserLookups] BIGINT NULL,
        [UserUpdates] BIGINT NULL,
        [TotalReads] BIGINT NULL,
        [ReadWriteRatio] DECIMAL(10,2) NULL,
        [AvgFragmentation] DECIMAL(5,2) NULL,
        [IndexSizeMB] DECIMAL(10,2) NULL,
        [LastUserSeek] DATETIME2 NULL,
        [LastUserScan] DATETIME2 NULL,
        [RecordedDate] DATETIME2 DEFAULT GETDATE(),
        [Notes] NVARCHAR(MAX) NULL
    )
    
    CREATE INDEX IX_IndexPerformanceMonitoring_TableName_RecordedDate 
    ON [dbo].[IndexPerformanceMonitoring] ([TableName], [RecordedDate])
    
    PRINT 'Created IndexPerformanceMonitoring table'
END

-- Record current index performance metrics
INSERT INTO [dbo].[IndexPerformanceMonitoring] (
    [TableName], [IndexName], [UserSeeks], [UserScans], [UserLookups], 
    [UserUpdates], [TotalReads], [ReadWriteRatio], [AvgFragmentation], 
    [IndexSizeMB], [LastUserSeek], [LastUserScan], [Notes]
)
SELECT 
    'PushNotification' as TableName,
    i.name AS IndexName,
    ISNULL(ius.user_seeks, 0) as UserSeeks,
    ISNULL(ius.user_scans, 0) as UserScans,
    ISNULL(ius.user_lookups, 0) as UserLookups,
    ISNULL(ius.user_updates, 0) as UserUpdates,
    ISNULL(ius.user_seeks + ius.user_scans + ius.user_lookups, 0) as TotalReads,
    CASE 
        WHEN ius.user_updates > 0 
        THEN CAST((ius.user_seeks + ius.user_scans + ius.user_lookups) AS DECIMAL(10,2)) / ius.user_updates
        ELSE NULL 
    END as ReadWriteRatio,
    ips.avg_fragmentation_in_percent,
    ps.used_page_count * 8.0 / 1024 AS IndexSizeMB,
    ius.last_user_seek,
    ius.last_user_scan,
    'Automated monitoring entry'
FROM sys.indexes i
LEFT JOIN sys.dm_db_index_usage_stats ius
    ON i.object_id = ius.object_id AND i.index_id = ius.index_id
LEFT JOIN sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('dbo.PushNotification'), NULL, NULL, 'SAMPLED') ips
    ON i.object_id = ips.object_id AND i.index_id = ips.index_id
LEFT JOIN sys.dm_db_partition_stats ps 
    ON i.object_id = ps.object_id AND i.index_id = ps.index_id
WHERE i.object_id = OBJECT_ID('dbo.PushNotification')
AND i.type > 0

PRINT 'Recorded current index performance metrics'

-- Display current performance summary
PRINT ''
PRINT 'CURRENT INDEX PERFORMANCE SUMMARY:'
PRINT '----------------------------------'

SELECT 
    IndexName,
    TotalReads,
    UserUpdates,
    CASE 
        WHEN UserUpdates = 0 THEN 'READ-only'
        WHEN ReadWriteRatio >= 10 THEN 'excellent'
        WHEN ReadWriteRatio >= 5 THEN 'good'
        WHEN ReadWriteRatio >= 1 THEN 'fair'
        ELSE 'poor'
    END as Performance,
    CASE 
        WHEN AvgFragmentation > 30 THEN 'rebuild needed'
        WHEN AvgFragmentation > 10 THEN 'consider reorganize'
        ELSE 'ok'
    END as FragmentationStatus,
    IndexSizeMB,
    LastUserSeek,
    LastUserScan
FROM [dbo].[IndexPerformanceMonitoring]
WHERE TableName = 'PushNotification'
AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')
ORDER BY TotalReads DESC

-- Identify unused indexes (haven't been used for reads)
PRINT ''
PRINT 'POTENTIALLY UNUSED INDEXES:'
PRINT '---------------------------'

SELECT 
    IndexName,
    IndexSizeMB,
    UserUpdates,
    'Consider dropping - no read activity' as Recommendation
FROM [dbo].[IndexPerformanceMonitoring]
WHERE TableName = 'PushNotification'
AND TotalReads = 0
AND UserUpdates > 0
AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')

-- Identify over-maintained indexes (high update-to-read ratio)
PRINT ''
PRINT 'OVER-MAINTAINED INDEXES:'
PRINT '------------------------'

SELECT 
    IndexName,
    TotalReads,
    UserUpdates,
    ReadWriteRatio,
    'High maintenance cost - consider removing' as Recommendation
FROM [dbo].[IndexPerformanceMonitoring]
WHERE TableName = 'PushNotification'
AND ReadWriteRatio < 0.1
AND UserUpdates > 1000
AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')

-- Performance trend analysis (if historical data exists)
PRINT ''
PRINT 'PERFORMANCE TRENDS (Last 30 Days):'
PRINT '-----------------------------------'

IF EXISTS (
    SELECT 1 FROM [dbo].[IndexPerformanceMonitoring] 
    WHERE TableName = 'PushNotification' 
    AND RecordedDate >= DATEADD(DAY, -30, GETDATE())
    HAVING COUNT(DISTINCT CAST(RecordedDate AS DATE)) > 1
)
BEGIN
    SELECT 
        IndexName,
        MIN(RecordedDate) as FirstRecord,
        MAX(RecordedDate) as LastRecord,
        MAX(TotalReads) - MIN(TotalReads) as ReadGrowth,
        MAX(UserUpdates) - MIN(UserUpdates) as UpdateGrowth,
        AVG(AvgFragmentation) as AvgFragmentation,
        MAX(IndexSizeMB) - MIN(IndexSizeMB) as SizeGrowthMB
    FROM [dbo].[IndexPerformanceMonitoring]
    WHERE TableName = 'PushNotification'
    AND RecordedDate >= DATEADD(DAY, -30, GETDATE())
    GROUP BY IndexName
    HAVING COUNT(*) > 1
    ORDER BY ReadGrowth DESC
END
ELSE
BEGIN
    PRINT 'Insufficient historical data for trend analysis'
    PRINT 'Run this script regularly to build performance history'
END

-- Generate index maintenance recommendations
PRINT ''
PRINT 'MAINTENANCE RECOMMENDATIONS:'
PRINT '----------------------------'

DECLARE @RecommendationCount INT = 0

-- Check for fragmented indexes
IF EXISTS (
    SELECT 1 FROM [dbo].[IndexPerformanceMonitoring]
    WHERE TableName = 'PushNotification'
    AND AvgFragmentation > 30
    AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')
)
BEGIN
    PRINT '1. REBUILD HIGHLY FRAGMENTED INDEXES:'
    SELECT 
        '   ALTER INDEX [' + IndexName + '] ON [dbo].[PushNotification] REBUILD WITH (ONLINE=OFF, MAXDOP=0)' as SQLCommand
    FROM [dbo].[IndexPerformanceMonitoring]
    WHERE TableName = 'PushNotification'
    AND AvgFragmentation > 30
    AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')
    
    SET @RecommendationCount = @RecommendationCount + 1
END

-- Check for moderately fragmented indexes
IF EXISTS (
    SELECT 1 FROM [dbo].[IndexPerformanceMonitoring]
    WHERE TableName = 'PushNotification'
    AND AvgFragmentation BETWEEN 10 AND 30
    AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')
)
BEGIN
    PRINT '2. REORGANIZE MODERATELY FRAGMENTED INDEXES:'
    SELECT 
        '   ALTER INDEX [' + IndexName + '] ON [dbo].[PushNotification] REORGANIZE' as SQLCommand
    FROM [dbo].[IndexPerformanceMonitoring]
    WHERE TableName = 'PushNotification'
    AND AvgFragmentation BETWEEN 10 AND 30
    AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')
    
    SET @RecommendationCount = @RecommendationCount + 1
END

-- Check for unused indexes
IF EXISTS (
    SELECT 1 FROM [dbo].[IndexPerformanceMonitoring]
    WHERE TableName = 'PushNotification'
    AND TotalReads = 0 AND UserUpdates > 1000
    AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')
)
BEGIN
    PRINT '3. CONSIDER DROPPING UNUSED INDEXES:'
    SELECT 
        '   -- DROP INDEX [' + IndexName + '] ON [dbo].[PushNotification]  -- SaveFirst: ' + CAST(IndexSizeMB AS NVARCHAR(10)) + ' MB' as SQLCommand
    FROM [dbo].[IndexPerformanceMonitoring]
    WHERE TableName = 'PushNotification'
    AND TotalReads = 0 AND UserUpdates > 1000
    AND RecordedDate = (SELECT MAX(RecordedDate) FROM [dbo].[IndexPerformanceMonitoring] WHERE TableName = 'PushNotification')
    
    SET @RecommendationCount = @RecommendationCount + 1
END

-- Update statistics recommendation
PRINT '4. UPDATE STATISTICS:'
PRINT '   UPDATE STATISTICS [dbo].[PushNotification] WITH SAMPLE 25 PERCENT'

SET @RecommendationCount = @RecommendationCount + 1

IF @RecommendationCount = 1
    PRINT ''
    PRINT '? Only routine maintenance needed!'

PRINT ''
PRINT 'AUTOMATED MONITORING SETUP:'
PRINT '----------------------------'
PRINT 'To automate this monitoring, create a SQL Server Agent job that runs:'
PRINT 'EXEC [dbo].[USP_Monitor_Index_Performance] -- (Create this procedure)'
PRINT ''
PRINT 'Recommended Schedule:'
PRINT '� Daily: Basic performance metrics'
PRINT '� Weekly: Detailed fragmentation analysis'
PRINT '� Monthly: Trend analysis and optimization review'

-- Create a simple monitoring procedure
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_Monitor_Index_Performance]') AND type in (N'P', N'PC'))
BEGIN
    EXEC ('
    CREATE PROCEDURE [dbo].[USP_Monitor_Index_Performance]
    AS
    BEGIN
        -- Insert current metrics
        INSERT INTO [dbo].[IndexPerformanceMonitoring] (
            [TableName], [IndexName], [UserSeeks], [UserScans], [UserLookups], 
            [UserUpdates], [TotalReads], [ReadWriteRatio], [AvgFragmentation], 
            [IndexSizeMB], [LastUserSeek], [LastUserScan], [Notes]
        )
        SELECT 
            ''PushNotification'' as TableName,
            i.name AS IndexName,
            ISNULL(ius.user_seeks, 0) as UserSeeks,
            ISNULL(ius.user_scans, 0) as UserScans,
            ISNULL(ius.user_lookups, 0) as UserLookups,
            ISNULL(ius.user_updates, 0) as UserUpdates,
            ISNULL(ius.user_seeks + ius.user_scans + ius.user_lookups, 0) as TotalReads,
            CASE 
                WHEN ius.user_updates > 0 
                THEN CAST((ius.user_seeks + ius.user_scans + ius.user_lookups) AS DECIMAL(10,2)) / ius.user_updates
                ELSE NULL 
            END as ReadWriteRatio,
            ips.avg_fragmentation_in_percent,
            ps.used_page_count * 8.0 / 1024 AS IndexSizeMB,
            ius.last_user_seek,
            ius.last_user_scan,
            ''Automated daily monitoring''
        FROM sys.indexes i
        LEFT JOIN sys.dm_db_index_usage_stats ius
            ON i.object_id = ius.object_id AND i.index_id = ius.index_id
        LEFT JOIN sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID(''dbo.PushNotification''), NULL, NULL, ''SAMPLED'') ips
            ON i.object_id = ips.object_id AND i.index_id = ips.index_id
        LEFT JOIN sys.dm_db_partition_stats ps 
            ON i.object_id = ps.object_id AND i.index_id = ps.index_id
        WHERE i.object_id = OBJECT_ID(''dbo.PushNotification'')
        AND i.type > 0
        
        -- Clean up old monitoring data (keep 90 days)
        DELETE FROM [dbo].[IndexPerformanceMonitoring]
        WHERE RecordedDate < DATEADD(DAY, -90, GETDATE())
    END')
    
    PRINT 'Created USP_Monitor_Index_Performance procedure'
END

PRINT ''
PRINT 'Monitoring setup completed successfully!'
PRINT 'Next steps:'
PRINT '1. Review the performance summary above'
PRINT '2. Implement recommended maintenance'
PRINT '3. Set up automated monitoring job'
PRINT '4. Review performance monthly'
GO