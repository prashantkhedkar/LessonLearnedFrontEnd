-- =============================================
-- Manual Test Script for Integration_ShiftDutyRoasterDetail Cleanup
-- Purpose: Test the cleanup procedure and validate results
-- Usage: Run this script to test the cleanup functionality
-- =============================================

USE [JointPortal_QA]
GO

PRINT '========================================'
PRINT 'INTEGRATION_SHIFTDUTYROASTERDETAIL CLEANUP TEST'
PRINT '========================================'
PRINT 'Test started at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)
PRINT ''

-- Step 1: Check current table statistics
PRINT '1. CURRENT TABLE STATISTICS:'
PRINT '----------------------------'

DECLARE @TotalRecords BIGINT
DECLARE @OldRecords BIGINT
DECLARE @RecentRecords BIGINT
DECLARE @OldestRecord DATETIME
DECLARE @NewestRecord DATETIME
DECLARE @CutoffDate DATETIME = DATEADD(MONTH, -1, GETDATE())

SELECT @TotalRecords = COUNT(*)
FROM [dbo].[Integration_ShiftDutyRoasterDetail]

SELECT @OldRecords = COUNT(*)
FROM [dbo].[Integration_ShiftDutyRoasterDetail]
WHERE [CreatedDate] < @CutoffDate

SELECT @RecentRecords = COUNT(*)
FROM [dbo].[Integration_ShiftDutyRoasterDetail]
WHERE [CreatedDate] >= @CutoffDate

SELECT @OldestRecord = MIN([CreatedDate]), @NewestRecord = MAX([CreatedDate])
FROM [dbo].[Integration_ShiftDutyRoasterDetail]

PRINT 'Total records in table: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Records older than 1 month: ' + CAST(ISNULL(@OldRecords, 0) AS NVARCHAR(20))
PRINT 'Records within last month: ' + CAST(ISNULL(@RecentRecords, 0) AS NVARCHAR(20))
PRINT 'Oldest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @OldestRecord, 121), 'N/A')
PRINT 'Newest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @NewestRecord, 121), 'N/A')
PRINT 'Cutoff date (1 month ago): ' + CONVERT(NVARCHAR(23), @CutoffDate, 121)
PRINT ''

-- Step 2: Show sample records that would be deleted
IF @OldRecords > 0
BEGIN
    PRINT '2. SAMPLE RECORDS TO BE DELETED (Top 10):'
    PRINT '----------------------------------------'
    
    SELECT TOP 10
        [Id],
        [PersonId],
        [ApplicationId],
        [NotificationType],
        [NotificationTitle],
        [UserName],
        [CreatedDate],
        DATEDIFF(DAY, [CreatedDate], GETDATE()) AS DaysOld
    FROM [dbo].[Integration_ShiftDutyRoasterDetail]
    WHERE [CreatedDate] < @CutoffDate
    ORDER BY [CreatedDate]
    
    PRINT ''
END
ELSE
BEGIN
    PRINT '2. NO RECORDS TO DELETE'
    PRINT '----------------------'
    PRINT 'All records are within the retention period.'
    PRINT ''
END

-- Step 3: Analyze table space usage (if possible)
PRINT '3. TABLE SPACE ANALYSIS:'
PRINT '-----------------------'

IF EXISTS (SELECT * FROM sys.dm_db_partition_stats WHERE object_id = OBJECT_ID('dbo.Integration_ShiftDutyRoasterDetail'))
BEGIN
    SELECT 
        OBJECT_NAME(ps.object_id) AS TableName,
        ps.row_count AS RowCount,
        ps.used_page_count * 8 AS UsedSpaceKB,
        ps.reserved_page_count * 8 AS ReservedSpaceKB,
        CASE 
            WHEN ps.row_count > 0 
            THEN CAST((ps.used_page_count * 8.0 / 1024.0) AS DECIMAL(10,2))
            ELSE 0 
        END AS UsedSpaceMB
    FROM sys.dm_db_partition_stats ps
    WHERE ps.object_id = OBJECT_ID('dbo.Integration_ShiftDutyRoasterDetail')
      AND ps.index_id IN (0,1)  -- Heap or clustered index
END
PRINT ''

-- Step 4: Test cleanup procedure (DRY RUN)
PRINT '4. TESTING CLEANUP PROCEDURE:'
PRINT '----------------------------'

IF @OldRecords > 0
BEGIN
    PRINT 'Running cleanup procedure...'
    PRINT ''
    
    BEGIN TRY
        -- Execute the cleanup procedure
        EXEC [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup] 
            @RetentionMonths = 1,
            @BatchSize = 1000,  -- Smaller batch for testing
            @LogResults = 1
            
        PRINT ''
        PRINT 'Cleanup procedure executed successfully!'
    END TRY
    BEGIN CATCH
        PRINT 'Error executing cleanup procedure:'
        PRINT 'Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR(10))
        PRINT 'Error Message: ' + ERROR_MESSAGE()
        PRINT 'Error Line: ' + CAST(ERROR_LINE() AS NVARCHAR(10))
    END CATCH
END
ELSE
BEGIN
    PRINT 'Skipping cleanup - no old records found.'
END

PRINT ''

-- Step 5: Post-cleanup statistics
PRINT '5. POST-CLEANUP STATISTICS:'
PRINT '--------------------------'

SELECT @TotalRecords = COUNT(*)
FROM [dbo].[Integration_ShiftDutyRoasterDetail]

SELECT @OldRecords = COUNT(*)
FROM [dbo].[Integration_ShiftDutyRoasterDetail]
WHERE [CreatedDate] < @CutoffDate

SELECT @RecentRecords = COUNT(*)
FROM [dbo].[Integration_ShiftDutyRoasterDetail]
WHERE [CreatedDate] >= @CutoffDate

SELECT @OldestRecord = MIN([CreatedDate]), @NewestRecord = MAX([CreatedDate])
FROM [dbo].[Integration_ShiftDutyRoasterDetail]

PRINT 'Total records after cleanup: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Old records remaining: ' + CAST(ISNULL(@OldRecords, 0) AS NVARCHAR(20))
PRINT 'Recent records: ' + CAST(ISNULL(@RecentRecords, 0) AS NVARCHAR(20))
PRINT 'Oldest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @OldestRecord, 121), 'N/A')
PRINT 'Newest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @NewestRecord, 121), 'N/A')

-- Step 6: Check indexes
PRINT ''
PRINT '6. INDEX STATUS:'
PRINT '---------------'

SELECT 
    i.name AS IndexName,
    i.type_desc AS IndexType,
    i.is_disabled AS IsDisabled,
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
        WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
        ORDER BY ic.key_ordinal
        FOR XML PATH('')
    ), 1, 2, '') AS KeyColumns,
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
        WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 1
        ORDER BY ic.key_ordinal
        FOR XML PATH('')
    ), 1, 2, '') AS IncludedColumns
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID('dbo.Integration_ShiftDutyRoasterDetail')
  AND i.type > 0  -- Exclude heap

PRINT ''
PRINT '========================================'
PRINT 'TEST COMPLETED'
PRINT '========================================'
PRINT 'Test completed at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)

-- Additional recommendations
PRINT ''
PRINT 'RECOMMENDATIONS:'
PRINT '---------------'
PRINT '1. Monitor the cleanup job execution regularly'
PRINT '2. Adjust @BatchSize if cleanup takes too long'
PRINT '3. Consider running manual cleanup before enabling the job if you have many old records'
PRINT '4. Monitor system performance during cleanup operations'
PRINT '5. Consider archiving old data instead of deleting if historical data is needed'
PRINT ''

GO