-- =============================================
-- Manual Test Script for TarasulNotification Cleanup
-- Purpose: Test the cleanup procedure and validate results
-- Usage: Run this script to test the cleanup functionality
-- =============================================

USE [JointPortal_QA]
GO

PRINT '========================================'
PRINT 'TARASULNOTIFICATION CLEANUP TEST'
PRINT '========================================'
PRINT 'Test started at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)
PRINT ''

-- Step 1: Check current table statistics
PRINT '1. CURRENT TABLE STATISTICS:'
PRINT '----------------------------'

DECLARE @TotalRecords BIGINT
DECLARE @DeletedRecords BIGINT
DECLARE @ActiveRecords BIGINT
DECLARE @OldRecords BIGINT
DECLARE @RecentRecords BIGINT
DECLARE @OldestRecord DATETIME
DECLARE @NewestRecord DATETIME
DECLARE @CutoffDate DATETIME = DATEADD(MONTH, -1, GETDATE())

SELECT @TotalRecords = COUNT(*)
FROM [dbo].[TarasulNotification]

SELECT @DeletedRecords = COUNT(*)
FROM [dbo].[TarasulNotification]
WHERE [IsDeleted] = 1

SELECT @ActiveRecords = COUNT(*)
FROM [dbo].[TarasulNotification]
WHERE [IsDeleted] = 0 OR [IsDeleted] IS NULL

SELECT @OldRecords = COUNT(*)
FROM [dbo].[TarasulNotification]
WHERE [CreatedDate] < @CutoffDate
  AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)

SELECT @RecentRecords = COUNT(*)
FROM [dbo].[TarasulNotification]
WHERE [CreatedDate] >= @CutoffDate
  AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)

SELECT @OldestRecord = MIN([CreatedDate]), @NewestRecord = MAX([CreatedDate])
FROM [dbo].[TarasulNotification]

PRINT 'Total records in table: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Records marked as deleted (IsDeleted=1): ' + CAST(ISNULL(@DeletedRecords, 0) AS NVARCHAR(20))
PRINT 'Active records (IsDeleted=0 or NULL): ' + CAST(ISNULL(@ActiveRecords, 0) AS NVARCHAR(20))
PRINT 'Old active records (>1 month): ' + CAST(ISNULL(@OldRecords, 0) AS NVARCHAR(20))
PRINT 'Recent active records (<=1 month): ' + CAST(ISNULL(@RecentRecords, 0) AS NVARCHAR(20))
PRINT 'Oldest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @OldestRecord, 121), 'N/A')
PRINT 'Newest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @NewestRecord, 121), 'N/A')
PRINT 'Cutoff date (1 month ago): ' + CONVERT(NVARCHAR(23), @CutoffDate, 121)
PRINT ''

-- Step 2: Show sample marked deleted records
IF @DeletedRecords > 0
BEGIN
    PRINT '2. SAMPLE MARKED DELETED RECORDS (Top 10):'
    PRINT '------------------------------------------'
    
    SELECT TOP 10
        [NotificationId],
        [NotificationHeader],
        [NotificationType],
        [FromUserId],
        [ModuleTypeId],
        [CreatedDate],
        [IsDeleted],
        DATEDIFF(DAY, [CreatedDate], GETDATE()) AS DaysOld
    FROM [dbo].[TarasulNotification]
    WHERE [IsDeleted] = 1
    ORDER BY [CreatedDate]
    
    PRINT ''
END
ELSE
BEGIN
    PRINT '2. NO MARKED DELETED RECORDS'
    PRINT '----------------------------'
    PRINT 'No records marked with IsDeleted = 1 found.'
    PRINT ''
END

-- Step 3: Show sample old active records
IF @OldRecords > 0
BEGIN
    PRINT '3. SAMPLE OLD ACTIVE RECORDS TO BE DELETED (Top 10):'
    PRINT '---------------------------------------------------'
    
    SELECT TOP 10
        [NotificationId],
        [NotificationHeader],
        [NotificationType],
        [FromUserId],
        [ModuleTypeId],
        [CreatedDate],
        [IsDeleted],
        DATEDIFF(DAY, [CreatedDate], GETDATE()) AS DaysOld
    FROM [dbo].[TarasulNotification]
    WHERE [CreatedDate] < @CutoffDate
      AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
    ORDER BY [CreatedDate]
    
    PRINT ''
END
ELSE
BEGIN
    PRINT '3. NO OLD ACTIVE RECORDS TO DELETE'
    PRINT '----------------------------------'
    PRINT 'All active records are within the retention period.'
    PRINT ''
END

-- Step 4: Analyze table space usage
PRINT '4. TABLE SPACE ANALYSIS:'
PRINT '-----------------------'

IF EXISTS (SELECT * FROM sys.dm_db_partition_stats WHERE object_id = OBJECT_ID('dbo.TarasulNotification'))
BEGIN
    SELECT 
        OBJECT_NAME(ps.object_id) AS TableName,
        ps.row_count AS RowCount,
        ps.used_page_count * 8 AS UsedSpaceKB,
        ps.reserved_page_count * 8 AS ReservedSpaceKB,
        CASE 
            WHEN ps.row_count > 0 
            THEN CAST((ps.used_page_count * 8.0 / 1024.0) AS DECIMAL(10,2))
            ELSE 0 
        END AS UsedSpaceMB
    FROM sys.dm_db_partition_stats ps
    WHERE ps.object_id = OBJECT_ID('dbo.TarasulNotification')
      AND ps.index_id IN (0,1)  -- Heap or clustered index
END
PRINT ''

-- Step 5: Check notification distribution by type and module
PRINT '5. NOTIFICATION DISTRIBUTION:'
PRINT '----------------------------'

SELECT 
    'By Type' AS Category,
    CAST([NotificationType] AS NVARCHAR(50)) AS TypeOrModule,
    COUNT(*) AS RecordCount,
    COUNT(CASE WHEN [IsDeleted] = 1 THEN 1 END) AS DeletedCount,
    COUNT(CASE WHEN [CreatedDate] < @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL) THEN 1 END) AS OldActiveCount
FROM [dbo].[TarasulNotification]
GROUP BY [NotificationType]

UNION ALL

SELECT 
    'By Module' AS Category,
    CAST(ISNULL([ModuleTypeId], 0) AS NVARCHAR(50)) AS TypeOrModule,
    COUNT(*) AS RecordCount,
    COUNT(CASE WHEN [IsDeleted] = 1 THEN 1 END) AS DeletedCount,
    COUNT(CASE WHEN [CreatedDate] < @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL) THEN 1 END) AS OldActiveCount
FROM [dbo].[TarasulNotification]
GROUP BY [ModuleTypeId]
ORDER BY Category, RecordCount DESC

PRINT ''

-- Step 6: Test cleanup procedure
PRINT '6. TESTING CLEANUP PROCEDURE:'
PRINT '----------------------------'

IF @DeletedRecords > 0 OR @OldRecords > 0
BEGIN
    PRINT 'Running cleanup procedure...'
    PRINT ''
    
    BEGIN TRY
        -- Execute the cleanup procedure
        EXEC [dbo].[USP_TarasulNotification_Cleanup] 
            @RetentionMonths = 1,
            @BatchSize = 1000,          -- Smaller batch for testing
            @LogResults = 1,
            @DeleteMarkedRecords = 1    -- Include marked deleted records
            
        PRINT ''
        PRINT 'Cleanup procedure executed successfully!'
    END TRY
    BEGIN CATCH
        PRINT 'Error executing cleanup procedure:'
        PRINT 'Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR(10))
        PRINT 'Error Message: ' + ERROR_MESSAGE()
        PRINT 'Error Line: ' + CAST(ERROR_LINE() AS NVARCHAR(10))
        
        -- If procedure doesn't exist, show instructions
        IF ERROR_NUMBER() = 2812 -- Could not find stored procedure
        BEGIN
            PRINT ''
            PRINT 'PROCEDURE NOT FOUND - To create it, run:'
            PRINT 'EXEC the script: DatabaseScripts/StoredProcedures/USP_TarasulNotification_Cleanup.sql'
        END
    END CATCH
END
ELSE
BEGIN
    PRINT 'Skipping cleanup - no records to delete found.'
END

PRINT ''

-- Step 7: Post-cleanup statistics
PRINT '7. POST-CLEANUP STATISTICS:'
PRINT '--------------------------'

SELECT @TotalRecords = COUNT(*) FROM [dbo].[TarasulNotification]
SELECT @DeletedRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 1
SELECT @ActiveRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 0 OR [IsDeleted] IS NULL
SELECT @OldRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [CreatedDate] < @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
SELECT @RecentRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [CreatedDate] >= @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
SELECT @OldestRecord = MIN([CreatedDate]), @NewestRecord = MAX([CreatedDate]) FROM [dbo].[TarasulNotification]

PRINT 'Total records after cleanup: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Marked deleted records remaining: ' + CAST(ISNULL(@DeletedRecords, 0) AS NVARCHAR(20))
PRINT 'Active records after cleanup: ' + CAST(ISNULL(@ActiveRecords, 0) AS NVARCHAR(20))
PRINT 'Old active records remaining: ' + CAST(ISNULL(@OldRecords, 0) AS NVARCHAR(20))
PRINT 'Recent active records: ' + CAST(ISNULL(@RecentRecords, 0) AS NVARCHAR(20))
PRINT 'Oldest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @OldestRecord, 121), 'N/A')
PRINT 'Newest record date: ' + ISNULL(CONVERT(NVARCHAR(23), @NewestRecord, 121), 'N/A')

-- Step 8: Check indexes
PRINT ''
PRINT '8. INDEX STATUS:'
PRINT '---------------'

SELECT 
    i.name AS IndexName,
    i.type_desc AS IndexType,
    i.is_disabled AS IsDisabled,
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
        WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
        ORDER BY ic.key_ordinal
        FOR XML PATH('')
    ), 1, 2, '') AS KeyColumns,
    STUFF((
        SELECT ', ' + c.name
        FROM sys.index_columns ic
        INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
        WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 1
        ORDER BY ic.key_ordinal
        FOR XML PATH('')
    ), 1, 2, '') AS IncludedColumns
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID('dbo.TarasulNotification')
  AND i.type > 0  -- Exclude heap
ORDER BY i.name

PRINT ''
PRINT '========================================'
PRINT 'TEST COMPLETED'
PRINT '========================================'
PRINT 'Test completed at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)

-- Additional recommendations
PRINT ''
PRINT 'RECOMMENDATIONS:'
PRINT '---------------'
PRINT '1. Monitor the cleanup job execution regularly'
PRINT '2. The two-phase cleanup (marked deleted + old records) is optimal for this table'
PRINT '3. Adjust @BatchSize if cleanup takes too long or causes blocking'
PRINT '4. Consider running manual cleanup before enabling the job if you have many old records'
PRINT '5. Monitor system performance during cleanup operations'
PRINT '6. The IsDeleted flag pattern is properly supported by the cleanup procedure'
PRINT ''

-- Show cleanup command examples
PRINT 'CLEANUP COMMAND EXAMPLES:'
PRINT '------------------------'
PRINT '-- Standard cleanup (1 month retention, both phases):'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup]'
PRINT ''
PRINT '-- Keep 2 months of data:'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup] @RetentionMonths = 2'
PRINT ''
PRINT '-- Only delete old records (skip marked deleted records):'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup] @DeleteMarkedRecords = 0'
PRINT ''
PRINT '-- Use smaller batches for high-load systems:'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup] @BatchSize = 2000'
PRINT ''

GO