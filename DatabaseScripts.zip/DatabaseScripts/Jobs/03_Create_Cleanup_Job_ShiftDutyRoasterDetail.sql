-- =============================================
-- SQL Server Agent Job: Automated Cleanup for Integration_ShiftDutyRoasterDetail
-- Purpose: Create a job to automatically clean up old records daily
-- Schedule: Runs daily at 2:00 AM
-- Retention: Keeps only 1 month of data
-- =============================================

USE [msdb]
GO

DECLARE @jobId BINARY(16)
DECLARE @JobName NVARCHAR(128) = 'JointPortal_Integration_ShiftDutyRoasterDetail_Cleanup'

-- Check if job already exists and delete it
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = @JobName)
BEGIN
    PRINT 'Job already exists. Deleting existing job...'
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName, @delete_unused_schedule = 1
    PRINT 'Existing job deleted.'
END

-- Create the job
EXEC msdb.dbo.sp_add_job 
    @job_name = @JobName,
    @enabled = 1,
    @notify_level_eventlog = 0,
    @notify_level_email = 2,
    @notify_level_netsend = 0,
    @notify_level_page = 0,
    @delete_level = 0,
    @description = N'Automated cleanup job for Integration_ShiftDutyRoasterDetail table. Maintains 1 month of data retention.',
    @category_name = N'Database Maintenance',
    @owner_login_name = N'sa',
    @job_id = @jobId OUTPUT

PRINT 'Job created with ID: ' + CAST(@jobId AS NVARCHAR(50))

-- Add job step
EXEC msdb.dbo.sp_add_jobstep 
    @job_id = @jobId,
    @step_name = N'Cleanup Integration_ShiftDutyRoasterDetail Records',
    @step_id = 1,
    @cmdexec_success_code = 0,
    @on_success_action = 1,
    @on_success_step_id = 0,
    @on_fail_action = 2,
    @on_fail_step_id = 0,
    @retry_attempts = 2,
    @retry_interval = 5,
    @os_run_priority = 0,
    @subsystem = N'TSQL',
    @command = N'-- Cleanup old Integration_ShiftDutyRoasterDetail records
-- Retains 1 month of data (configurable via @RetentionMonths parameter)

DECLARE @StartTime DATETIME2 = GETDATE()
DECLARE @JobMessage NVARCHAR(MAX)

PRINT ''Starting Integration_ShiftDutyRoasterDetail cleanup job...''
RAISERROR(''Starting Integration_ShiftDutyRoasterDetail cleanup job...'', 10, 1) WITH NOWAIT

-- Execute cleanup procedure
EXEC [JointPortal_QA].[dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup] 
    @RetentionMonths = 1,    -- Keep only 1 month of data
    @BatchSize = 5000,       -- Delete in batches of 5000
    @LogResults = 1          -- Enable detailed logging

-- Log job completion
DECLARE @EndTime DATETIME2 = GETDATE()
DECLARE @Duration INT = DATEDIFF(MINUTE, @StartTime, @EndTime)

SET @JobMessage = ''Integration_ShiftDutyRoasterDetail cleanup job completed successfully. Duration: '' + CAST(@Duration AS NVARCHAR(10)) + '' minutes.''
PRINT @JobMessage
RAISERROR(@JobMessage, 10, 1) WITH NOWAIT',
    @database_name = N'JointPortal_QA',
    @flags = 0

PRINT 'Job step added successfully.'

-- Create schedule for daily execution at 2:00 AM
EXEC msdb.dbo.sp_add_schedule 
    @schedule_name = N'Daily_2AM_ShiftDutyRoaster_Cleanup',
    @enabled = 1,
    @freq_type = 4,         -- Daily
    @freq_interval = 1,     -- Every day
    @freq_subday_type = 1,  -- At a specific time
    @freq_subday_interval = 0,
    @freq_relative_interval = 0,
    @freq_recurrence_factor = 0,
    @active_start_date = 20240101,  -- Start from January 1, 2024 (adjust as needed)
    @active_end_date = 99991231,    -- Never end
    @active_start_time = 020000,    -- 2:00 AM
    @active_end_time = 235959

PRINT 'Schedule created successfully.'

-- Attach schedule to job
EXEC msdb.dbo.sp_attach_schedule 
    @job_id = @jobId,
    @schedule_name = N'Daily_2AM_ShiftDutyRoaster_Cleanup'

PRINT 'Schedule attached to job.'

-- Add job to target server
EXEC msdb.dbo.sp_add_jobserver 
    @job_id = @jobId,
    @server_name = N'(local)'

PRINT 'Job added to local server.'

-- Display job information
SELECT 
    j.name AS JobName,
    j.enabled AS JobEnabled,
    j.description AS JobDescription,
    s.name AS ScheduleName,
    s.enabled AS ScheduleEnabled,
    CASE 
        WHEN s.freq_type = 4 THEN 'Daily'
        WHEN s.freq_type = 8 THEN 'Weekly'
        WHEN s.freq_type = 16 THEN 'Monthly'
        ELSE 'Other'
    END AS Frequency,
    RIGHT('0' + CAST(s.active_start_time / 10000 AS VARCHAR(2)), 2) + ':' +
    RIGHT('0' + CAST((s.active_start_time % 10000) / 100 AS VARCHAR(2)), 2) + ':' +
    RIGHT('0' + CAST(s.active_start_time % 100 AS VARCHAR(2)), 2) AS StartTime
FROM msdb.dbo.sysjobs j
INNER JOIN msdb.dbo.sysjobschedules js ON j.job_id = js.job_id
INNER JOIN msdb.dbo.sysschedules s ON js.schedule_id = s.schedule_id
WHERE j.name = @JobName

PRINT ''
PRINT '========================================'
PRINT 'JOB CREATION SUMMARY:'
PRINT '========================================'
PRINT 'Job Name: ' + @JobName
PRINT 'Status: Created and Enabled'
PRINT 'Schedule: Daily at 2:00 AM'
PRINT 'Retention Period: 1 month'
PRINT 'Database: JointPortal_QA'
PRINT 'Table: Integration_ShiftDutyRoasterDetail'
PRINT '========================================'
PRINT ''
PRINT 'IMPORTANT NOTES:'
PRINT '- Job will start automatically according to schedule'
PRINT '- Job logs can be viewed in SQL Server Agent Job History'
PRINT '- To run job manually: EXEC msdb.dbo.sp_start_job @job_name = ''' + @JobName + ''''
PRINT '- To disable job: EXEC msdb.dbo.sp_update_job @job_name = ''' + @JobName + ''', @enabled = 0'
PRINT '- Monitor job execution and adjust batch size if needed'
GO