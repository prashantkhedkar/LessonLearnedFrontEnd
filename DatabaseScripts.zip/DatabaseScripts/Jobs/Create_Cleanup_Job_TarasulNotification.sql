-- =============================================
-- SQL Server Agent Job: Automated Cleanup for TarasulNotification
-- Purpose: Create a job to automatically clean up old records daily
-- Schedule: Runs daily at 2:30 AM (30 minutes after ShiftDutyRoaster cleanup)
-- Retention: Keeps only 1 month of data
-- =============================================

USE [msdb]
GO

DECLARE @jobId BINARY(16)
DECLARE @JobName NVARCHAR(128) = 'JointPortal_TarasulNotification_Cleanup'

-- Check if job already exists and delete it
IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = @JobName)
BEGIN
    PRINT 'Job already exists. Deleting existing job...'
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName, @delete_unused_schedule = 1
    PRINT 'Existing job deleted.'
END

-- Create the job
EXEC msdb.dbo.sp_add_job 
    @job_name = @JobName,
    @enabled = 1,
    @notify_level_eventlog = 0,
    @notify_level_email = 2,
    @notify_level_netsend = 0,
    @notify_level_page = 0,
    @delete_level = 0,
    @description = N'Automated cleanup job for TarasulNotification table. Maintains 1 month of data retention and removes records marked as IsDeleted.',
    @category_name = N'Database Maintenance',
    @owner_login_name = N'sa',
    @job_id = @jobId OUTPUT

PRINT 'Job created with ID: ' + CAST(@jobId AS NVARCHAR(50))

-- Add job step
EXEC msdb.dbo.sp_add_jobstep 
    @job_id = @jobId,
    @step_name = N'Cleanup TarasulNotification Records',
    @step_id = 1,
    @cmdexec_success_code = 0,
    @on_success_action = 1,
    @on_success_step_id = 0,
    @on_fail_action = 2,
    @on_fail_step_id = 0,
    @retry_attempts = 2,
    @retry_interval = 5,
    @os_run_priority = 0,
    @subsystem = N'TSQL',
    @command = N'-- Cleanup old TarasulNotification records
-- Two-phase cleanup: Phase 1 (marked deleted) + Phase 2 (old active records)
-- Retains 1 month of data and deletes records marked as IsDeleted = 1

DECLARE @StartTime DATETIME2 = GETDATE()
DECLARE @JobMessage NVARCHAR(MAX)

PRINT ''Starting TarasulNotification cleanup job...''
RAISERROR(''Starting TarasulNotification cleanup job...'', 10, 1) WITH NOWAIT

-- Check if stored procedure exists
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N''[dbo].[USP_TarasulNotification_Cleanup]'') AND type in (N''P'', N''PC''))
BEGIN
    -- Execute the cleanup procedure
    EXEC [JointPortal_QA].[dbo].[USP_TarasulNotification_Cleanup] 
        @RetentionMonths = 1,        -- Keep only 1 month of data
        @BatchSize = 5000,           -- Delete in batches of 5000
        @LogResults = 1,             -- Enable detailed logging
        @DeleteMarkedRecords = 1     -- Delete records marked as IsDeleted = 1
END
ELSE
BEGIN
    -- Inline cleanup if procedure doesn''t exist
    PRINT ''Stored procedure not found. Running inline cleanup...''
    
    DECLARE @CutoffDate DATETIME = DATEADD(MONTH, -1, GETDATE())
    DECLARE @TotalRowsDeleted BIGINT = 0
    DECLARE @MarkedDeletedRows BIGINT = 0
    DECLARE @BatchRowsDeleted INT = 0
    DECLARE @BatchSize INT = 5000

    BEGIN TRY
        -- Phase 1: Delete records marked as IsDeleted = 1
        PRINT ''Phase 1: Deleting records marked as IsDeleted = 1...''
        
        WHILE EXISTS (SELECT 1 FROM [TarasulNotification] WHERE [IsDeleted] = 1)
        BEGIN
            DELETE TOP (@BatchSize)
            FROM [TarasulNotification]
            WHERE [IsDeleted] = 1
            
            SET @BatchRowsDeleted = @@ROWCOUNT
            SET @MarkedDeletedRows = @MarkedDeletedRows + @BatchRowsDeleted
            
            IF @BatchRowsDeleted > 0
            BEGIN
                PRINT ''Deleted '' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + '' marked records. Total: '' + CAST(@MarkedDeletedRows AS NVARCHAR(20))
                WAITFOR DELAY ''''00:00:01''''
            END
            ELSE
                BREAK
        END
        
        -- Phase 2: Delete old records (older than 1 month)
        PRINT ''Phase 2: Deleting records older than '' + CONVERT(NVARCHAR(23), @CutoffDate, 121) + ''...''
        
        WHILE EXISTS (
            SELECT 1 FROM [TarasulNotification] 
            WHERE [CreatedDate] < @CutoffDate 
              AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
        )
        BEGIN
            DELETE TOP (@BatchSize)
            FROM [TarasulNotification]
            WHERE [CreatedDate] < @CutoffDate
              AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
            
            SET @BatchRowsDeleted = @@ROWCOUNT
            SET @TotalRowsDeleted = @TotalRowsDeleted + @BatchRowsDeleted
            
            IF @BatchRowsDeleted > 0
            BEGIN
                PRINT ''Deleted '' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + '' old records. Total: '' + CAST(@TotalRowsDeleted AS NVARCHAR(20))
                WAITFOR DELAY ''''00:00:02''''
            END
            ELSE
                BREAK
        END
        
        -- Update statistics
        UPDATE STATISTICS [TarasulNotification]
        PRINT ''Table statistics updated.''
        
        PRINT ''Inline cleanup completed. Marked deleted: '' + CAST(@MarkedDeletedRows AS NVARCHAR(20)) + '', Old records: '' + CAST(@TotalRowsDeleted AS NVARCHAR(20))
        
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(MAX) = ''Error during TarasulNotification cleanup: '' + ERROR_MESSAGE() + 
                                             '' (Error Number: '' + CAST(ERROR_NUMBER() AS NVARCHAR(10)) + 
                                             '', Line: '' + CAST(ERROR_LINE() AS NVARCHAR(10)) + '')''
        PRINT @ErrorMessage
        RAISERROR(@ErrorMessage, 16, 1)
        
        -- Log error details
        DECLARE @ErrorDetails NVARCHAR(MAX) = 
            ''Procedure: TarasulNotification_Cleanup_Job (Inline)'' + CHAR(13) + CHAR(10) +
            ''Cutoff Date: '' + CONVERT(NVARCHAR(23), @CutoffDate, 121) + CHAR(13) + CHAR(10) +
            ''Marked Records Deleted Before Error: '' + CAST(@MarkedDeletedRows AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            ''Old Records Deleted Before Error: '' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            ''Error: '' + @ErrorMessage
        
        EXEC xp_logevent 50003, @ErrorDetails, ''ERROR''
    END CATCH
END

-- Log job completion
DECLARE @EndTime DATETIME2 = GETDATE()
DECLARE @Duration INT = DATEDIFF(MINUTE, @StartTime, @EndTime)

SET @JobMessage = ''TarasulNotification cleanup job completed successfully. Duration: '' + CAST(@Duration AS NVARCHAR(10)) + '' minutes.''
PRINT @JobMessage
RAISERROR(@JobMessage, 10, 1) WITH NOWAIT',
    @database_name = N'JointPortal_QA',
    @flags = 0

PRINT 'Job step added successfully.'

-- Create schedule for daily execution at 2:30 AM (30 minutes after ShiftDutyRoaster cleanup)
EXEC msdb.dbo.sp_add_schedule 
    @schedule_name = N'Daily_2-30AM_TarasulNotification_Cleanup',
    @enabled = 1,
    @freq_type = 4,         -- Daily
    @freq_interval = 1,     -- Every day
    @freq_subday_type = 1,  -- At a specific time
    @freq_subday_interval = 0,
    @freq_relative_interval = 0,
    @freq_recurrence_factor = 0,
    @active_start_date = 20240101,  -- Start from January 1, 2024 (adjust as needed)
    @active_end_date = 99991231,    -- Never end
    @active_start_time = 023000,    -- 2:30 AM
    @active_end_time = 235959

PRINT 'Schedule created successfully.'

-- Attach schedule to job
EXEC msdb.dbo.sp_attach_schedule 
    @job_id = @jobId,
    @schedule_name = N'Daily_2-30AM_TarasulNotification_Cleanup'

PRINT 'Schedule attached to job.'

-- Add job to target server
EXEC msdb.dbo.sp_add_jobserver 
    @job_id = @jobId,
    @server_name = N'(local)'

PRINT 'Job added to local server.'

-- Display job information
SELECT 
    j.name AS JobName,
    j.enabled AS JobEnabled,
    j.description AS JobDescription,
    s.name AS ScheduleName,
    s.enabled AS ScheduleEnabled,
    CASE 
        WHEN s.freq_type = 4 THEN 'Daily'
        WHEN s.freq_type = 8 THEN 'Weekly'
        WHEN s.freq_type = 16 THEN 'Monthly'
        ELSE 'Other'
    END AS Frequency,
    RIGHT('0' + CAST(s.active_start_time / 10000 AS VARCHAR(2)), 2) + ':' +
    RIGHT('0' + CAST((s.active_start_time % 10000) / 100 AS VARCHAR(2)), 2) + ':' +
    RIGHT('0' + CAST(s.active_start_time % 100 AS VARCHAR(2)), 2) AS StartTime
FROM msdb.dbo.sysjobs j
INNER JOIN msdb.dbo.sysjobschedules js ON j.job_id = js.job_id
INNER JOIN msdb.dbo.sysschedules s ON js.schedule_id = s.schedule_id
WHERE j.name = @JobName

PRINT ''
PRINT '========================================'
PRINT 'JOB CREATION SUMMARY:'
PRINT '========================================'
PRINT 'Job Name: ' + @JobName
PRINT 'Status: Created and Enabled'
PRINT 'Schedule: Daily at 2:30 AM'
PRINT 'Retention Period: 1 month'
PRINT 'Database: JointPortal_QA'
PRINT 'Table: TarasulNotification'
PRINT 'Special Features: Two-phase cleanup (marked deleted + old records)'
PRINT '========================================'
PRINT ''
PRINT 'CLEANUP PHASES:'
PRINT '- Phase 1: Deletes records with IsDeleted = 1'
PRINT '- Phase 2: Deletes active records older than 1 month'
PRINT ''
PRINT 'IMPORTANT NOTES:'
PRINT '- Job will start automatically according to schedule'
PRINT '- Job logs can be viewed in SQL Server Agent Job History'
PRINT '- To run job manually: EXEC msdb.dbo.sp_start_job @job_name = ''' + @JobName + ''''
PRINT '- To disable job: EXEC msdb.dbo.sp_update_job @job_name = ''' + @JobName + ''', @enabled = 0'
PRINT '- This job runs 30 minutes after ShiftDutyRoaster cleanup to spread load'
PRINT '- Processes both IsDeleted=1 records and old records based on CreatedDate'
PRINT '- Job includes fallback inline cleanup if stored procedure is missing'
PRINT '- Monitor job execution and adjust batch size if needed'
PRINT ''
PRINT 'NEXT STEPS:'
PRINT '1. Create the stored procedure: DatabaseScripts/StoredProcedures/USP_TarasulNotification_Cleanup.sql'
PRINT '2. Test the cleanup: DatabaseScripts/Testing/Test_TarasulNotification_Cleanup.sql'
PRINT '3. For emergency recovery: DatabaseScripts/Emergency/Emergency_Recovery_TarasulNotification.sql'
GO