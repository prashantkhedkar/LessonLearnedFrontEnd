-- =============================================
-- Script: Table Optimization for TarasulNotification
-- Purpose: Add indexes to improve performance
-- Author: Database Optimization
-- Date: Created for performance improvement
-- =============================================

USE [JointPortal_QA]
GO

-- Check if indexes already exist before creating them
PRINT 'Starting index optimization for TarasulNotification table...'

-- Index for CreatedDate (most important for cleanup operations)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.TarasulNotification') AND name = 'IX_TarasulNotification_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_TarasulNotification_CreatedDate]
    ON [dbo].[TarasulNotification] ([CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [FromUserId], [ModuleTypeId])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_TarasulNotification_CreatedDate'
END
ELSE
    PRINT 'Index IX_TarasulNotification_CreatedDate already exists'

-- Index for IsDeleted and CreatedDate (for filtering non-deleted records by date)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.TarasulNotification') AND name = 'IX_TarasulNotification_IsDeleted_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_TarasulNotification_IsDeleted_CreatedDate]
    ON [dbo].[TarasulNotification] ([IsDeleted], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [FromUserId])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_TarasulNotification_IsDeleted_CreatedDate'
END
ELSE
    PRINT 'Index IX_TarasulNotification_IsDeleted_CreatedDate already exists'

-- Index for FromUserId and CreatedDate (for user-specific queries)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.TarasulNotification') AND name = 'IX_TarasulNotification_FromUserId_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_TarasulNotification_FromUserId_CreatedDate]
    ON [dbo].[TarasulNotification] ([FromUserId], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [ModuleTypeId])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_TarasulNotification_FromUserId_CreatedDate'
END
ELSE
    PRINT 'Index IX_TarasulNotification_FromUserId_CreatedDate already exists'

-- Index for NotificationType and CreatedDate (for notification type filtering)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.TarasulNotification') AND name = 'IX_TarasulNotification_NotificationType_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_TarasulNotification_NotificationType_CreatedDate]
    ON [dbo].[TarasulNotification] ([NotificationType], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [FromUserId], [ModuleTypeId])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_TarasulNotification_NotificationType_CreatedDate'
END
ELSE
    PRINT 'Index IX_TarasulNotification_NotificationType_CreatedDate already exists'

-- Index for ModuleTypeId and CreatedDate (for module-specific queries)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.TarasulNotification') AND name = 'IX_TarasulNotification_ModuleTypeId_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_TarasulNotification_ModuleTypeId_CreatedDate]
    ON [dbo].[TarasulNotification] ([ModuleTypeId], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [FromUserId])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_TarasulNotification_ModuleTypeId_CreatedDate'
END
ELSE
    PRINT 'Index IX_TarasulNotification_ModuleTypeId_CreatedDate already exists'

-- Update statistics for better query performance
UPDATE STATISTICS [dbo].[TarasulNotification]
PRINT 'Updated statistics for TarasulNotification table'

-- Display current table statistics
PRINT ''
PRINT '========================================'
PRINT 'TABLE STATISTICS AFTER OPTIMIZATION:'
PRINT '========================================'

DECLARE @TotalRecords BIGINT
DECLARE @DeletedRecords BIGINT
DECLARE @ActiveRecords BIGINT
DECLARE @OldestRecord DATETIME
DECLARE @NewestRecord DATETIME

SELECT @TotalRecords = COUNT(*) FROM [dbo].[TarasulNotification]
SELECT @DeletedRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 1
SELECT @ActiveRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 0 OR [IsDeleted] IS NULL
SELECT @OldestRecord = MIN([CreatedDate]), @NewestRecord = MAX([CreatedDate]) FROM [dbo].[TarasulNotification]

PRINT 'Total records: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Deleted records: ' + CAST(ISNULL(@DeletedRecords, 0) AS NVARCHAR(20))
PRINT 'Active records: ' + CAST(ISNULL(@ActiveRecords, 0) AS NVARCHAR(20))
PRINT 'Oldest record: ' + ISNULL(CONVERT(NVARCHAR(23), @OldestRecord, 121), 'N/A')
PRINT 'Newest record: ' + ISNULL(CONVERT(NVARCHAR(23), @NewestRecord, 121), 'N/A')

PRINT ''
PRINT 'Index optimization completed successfully!'
PRINT 'Next step: Create the cleanup stored procedure'
GO