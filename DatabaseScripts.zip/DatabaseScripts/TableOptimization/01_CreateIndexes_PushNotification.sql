-- =============================================
-- Script: Table Optimization for PushNotification
-- Purpose: Add indexes and optimize performance for high-volume notification operations
-- Author: Database Optimization
-- Date: Created for performance improvement
-- =============================================

USE [JointPortal_QA]
GO

-- Check if indexes already exist before creating them
PRINT 'Starting comprehensive index optimization for PushNotification table...'

-- 1. Index for CreatedDate (most critical for cleanup operations and date-based queries)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_CreatedDate]
    ON [dbo].[PushNotification] ([CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [FromUserId], [ModuleTypeId], [IsDeleted])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 85  -- Leave space for inserts
    )
    
    PRINT 'Created index: IX_PushNotification_CreatedDate'
END
ELSE
    PRINT 'Index IX_PushNotification_CreatedDate already exists'

-- 2. Index for IsDeleted and CreatedDate (essential for filtering active records efficiently)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_IsDeleted_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_IsDeleted_CreatedDate]
    ON [dbo].[PushNotification] ([IsDeleted], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [FromUserId], [ModuleId], [ModuleTypeId])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 90
    )
    
    PRINT 'Created index: IX_PushNotification_IsDeleted_CreatedDate'
END
ELSE
    PRINT 'Index IX_PushNotification_IsDeleted_CreatedDate already exists'

-- 3. Index for FromUserId and CreatedDate (user-specific notification queries)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_FromUserId_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_FromUserId_CreatedDate]
    ON [dbo].[PushNotification] ([FromUserId], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [ModuleTypeId], [IsDeleted])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 85
    )
    
    PRINT 'Created index: IX_PushNotification_FromUserId_CreatedDate'
END
ELSE
    PRINT 'Index IX_PushNotification_FromUserId_CreatedDate already exists'

-- 4. Index for NotificationType and CreatedDate (notification type filtering)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_NotificationType_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_NotificationType_CreatedDate]
    ON [dbo].[PushNotification] ([NotificationType], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [FromUserId], [ModuleTypeId], [IsDeleted])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 90
    )
    
    PRINT 'Created index: IX_PushNotification_NotificationType_CreatedDate'
END
ELSE
    PRINT 'Index IX_PushNotification_NotificationType_CreatedDate already exists'

-- 5. Index for ModuleTypeId and CreatedDate (module-specific queries)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_ModuleTypeId_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_ModuleTypeId_CreatedDate]
    ON [dbo].[PushNotification] ([ModuleTypeId], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [FromUserId], [IsDeleted])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 90
    )
    
    PRINT 'Created index: IX_PushNotification_ModuleTypeId_CreatedDate'
END
ELSE
    PRINT 'Index IX_PushNotification_ModuleTypeId_CreatedDate already exists'

-- 6. Index for ModuleId and ModuleTypeId (for module-specific lookups)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_ModuleId_ModuleTypeId')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_ModuleId_ModuleTypeId]
    ON [dbo].[PushNotification] ([ModuleId], [ModuleTypeId])
    INCLUDE ([NotificationId], [CreatedDate], [FromUserId], [IsDeleted])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 85
    )
    
    PRINT 'Created index: IX_PushNotification_ModuleId_ModuleTypeId'
END
ELSE
    PRINT 'Index IX_PushNotification_ModuleId_ModuleTypeId already exists'

-- 7. Composite index for common filtering scenarios (IsDeleted, NotificationType, CreatedDate)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_IsDeleted_NotificationType_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_IsDeleted_NotificationType_CreatedDate]
    ON [dbo].[PushNotification] ([IsDeleted], [NotificationType], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [FromUserId], [ModuleId], [ModuleTypeId])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 90
    )
    
    PRINT 'Created index: IX_PushNotification_IsDeleted_NotificationType_CreatedDate'
END
ELSE
    PRINT 'Index IX_PushNotification_IsDeleted_NotificationType_CreatedDate already exists'

-- 8. Index for ServiceType (if frequently queried)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.PushNotification') AND name = 'IX_PushNotification_ServiceType_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_PushNotification_ServiceType_CreatedDate]
    ON [dbo].[PushNotification] ([ServiceType], [CreatedDate] DESC)
    INCLUDE ([NotificationId], [NotificationType], [IsDeleted])
    WITH (
        PAD_INDEX = OFF, 
        STATISTICS_NORECOMPUTE = OFF, 
        SORT_IN_TEMPDB = OFF, 
        DROP_EXISTING = OFF, 
        ONLINE = OFF, 
        ALLOW_ROW_LOCKS = ON, 
        ALLOW_PAGE_LOCKS = ON,
        FILLFACTOR = 90
    )
    
    PRINT 'Created index: IX_PushNotification_ServiceType_CreatedDate'
END
ELSE
    PRINT 'Index IX_PushNotification_ServiceType_CreatedDate already exists'

-- Update statistics for better query performance
UPDATE STATISTICS [dbo].[PushNotification] WITH FULLSCAN
PRINT 'Updated statistics for PushNotification table'

-- Enable automatic statistics updates
ALTER DATABASE [JointPortal_QA] SET AUTO_UPDATE_STATISTICS ON
ALTER DATABASE [JointPortal_QA] SET AUTO_UPDATE_STATISTICS_ASYNC ON

-- Display current table statistics
PRINT ''
PRINT '========================================'
PRINT 'TABLE STATISTICS AFTER OPTIMIZATION:'
PRINT '========================================'

DECLARE @TotalRecords BIGINT
DECLARE @DeletedRecords BIGINT
DECLARE @ActiveRecords BIGINT
DECLARE @OldestRecord DATETIME
DECLARE @NewestRecord DATETIME
DECLARE @AvgRecordsPerDay DECIMAL(10,2)
DECLARE @UniqueFromUsers INT
DECLARE @UniqueNotificationTypes INT
DECLARE @UniqueModuleTypes INT

SELECT @TotalRecords = COUNT(*) FROM [dbo].[PushNotification]
SELECT @DeletedRecords = COUNT(*) FROM [dbo].[PushNotification] WHERE [IsDeleted] = 1
SELECT @ActiveRecords = COUNT(*) FROM [dbo].[PushNotification] WHERE [IsDeleted] = 0 OR [IsDeleted] IS NULL
SELECT @OldestRecord = MIN([CreatedDate]), @NewestRecord = MAX([CreatedDate]) FROM [dbo].[PushNotification]
SELECT @UniqueFromUsers = COUNT(DISTINCT [FromUserId]) FROM [dbo].[PushNotification] WHERE [FromUserId] IS NOT NULL
SELECT @UniqueNotificationTypes = COUNT(DISTINCT [NotificationType]) FROM [dbo].[PushNotification]
SELECT @UniqueModuleTypes = COUNT(DISTINCT [ModuleTypeId]) FROM [dbo].[PushNotification] WHERE [ModuleTypeId] IS NOT NULL

-- Calculate average records per day
IF @OldestRecord IS NOT NULL AND @NewestRecord IS NOT NULL AND DATEDIFF(DAY, @OldestRecord, @NewestRecord) > 0
    SET @AvgRecordsPerDay = CAST(@TotalRecords AS DECIMAL(10,2)) / DATEDIFF(DAY, @OldestRecord, @NewestRecord)
ELSE
    SET @AvgRecordsPerDay = 0

PRINT 'Total records: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Deleted records: ' + CAST(ISNULL(@DeletedRecords, 0) AS NVARCHAR(20))
PRINT 'Active records: ' + CAST(ISNULL(@ActiveRecords, 0) AS NVARCHAR(20))
PRINT 'Oldest record: ' + ISNULL(CONVERT(NVARCHAR(23), @OldestRecord, 121), 'N/A')
PRINT 'Newest record: ' + ISNULL(CONVERT(NVARCHAR(23), @NewestRecord, 121), 'N/A')
PRINT 'Average records per day: ' + CAST(@AvgRecordsPerDay AS NVARCHAR(20))
PRINT 'Unique FromUsers: ' + CAST(@UniqueFromUsers AS NVARCHAR(20))
PRINT 'Unique Notification Types: ' + CAST(@UniqueNotificationTypes AS NVARCHAR(20))
PRINT 'Unique Module Types: ' + CAST(@UniqueModuleTypes AS NVARCHAR(20))

-- Check for potential performance issues
IF @TotalRecords > 1000000
    PRINT 'WARNING: Table has over 1 million records. Consider implementing regular cleanup.'

IF @DeletedRecords > (@TotalRecords * 0.1)
    PRINT 'WARNING: More than 10% of records are marked as deleted. Consider cleanup.'

IF DATEDIFF(MONTH, @OldestRecord, GETDATE()) > 6
    PRINT 'INFO: Table contains data older than 6 months. Consider archiving old data.'

PRINT ''
PRINT '========================================'
PRINT 'INDEX INFORMATION:'
PRINT '========================================'

-- Display index information
SELECT 
    i.name AS IndexName,
    i.type_desc AS IndexType,
    i.fill_factor AS FillFactor,
    CASE WHEN i.is_unique = 1 THEN 'UNIQUE' ELSE 'NON-UNIQUE' END AS Uniqueness,
    STUFF((SELECT ', ' + c.name
           FROM sys.index_columns ic
           INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
           WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
           ORDER BY ic.key_ordinal
           FOR XML PATH('')), 1, 2, '') AS KeyColumns,
    STUFF((SELECT ', ' + c.name
           FROM sys.index_columns ic
           INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
           WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 1
           FOR XML PATH('')), 1, 2, '') AS IncludeColumns
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID('dbo.PushNotification')
AND i.type > 0  -- Exclude heap
ORDER BY i.name

PRINT ''
PRINT 'Index optimization completed successfully!'
PRINT 'Recommendations:'
PRINT '1. Monitor query performance with new indexes'
PRINT '2. Set up regular maintenance for statistics updates'
PRINT '3. Consider implementing a cleanup strategy for old records'
PRINT '4. Monitor index fragmentation and rebuild as needed'
PRINT '5. Next step: Create the cleanup stored procedure'
GO