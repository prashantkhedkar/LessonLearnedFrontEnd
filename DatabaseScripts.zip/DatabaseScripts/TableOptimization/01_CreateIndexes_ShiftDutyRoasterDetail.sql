-- =============================================
-- Script: Table Optimization for Integration_ShiftDutyRoasterDetail
-- Purpose: Add indexes to improve performance
-- Author: Database Optimization
-- Date: Created for performance improvement
-- =============================================

USE [JointPortal_QA]
GO

-- Check if indexes already exist before creating them
PRINT 'Starting index optimization for Integration_ShiftDutyRoasterDetail table...'

-- Index for CreatedDate (most important for cleanup operations)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.Integration_ShiftDutyRoasterDetail') AND name = 'IX_Integration_ShiftDutyRoasterDetail_CreatedDate')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_Integration_ShiftDutyRoasterDetail_CreatedDate]
    ON [dbo].[Integration_ShiftDutyRoasterDetail] ([CreatedDate] DESC)
    INCLUDE ([Id], [PersonId], [ApplicationId])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_Integration_ShiftDutyRoasterDetail_CreatedDate'
END
ELSE
    PRINT 'Index IX_Integration_ShiftDutyRoasterDetail_CreatedDate already exists'

-- Index for PersonId and ApplicationId (for queries filtering by these columns)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.Integration_ShiftDutyRoasterDetail') AND name = 'IX_Integration_ShiftDutyRoasterDetail_PersonId_ApplicationId')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_Integration_ShiftDutyRoasterDetail_PersonId_ApplicationId]
    ON [dbo].[Integration_ShiftDutyRoasterDetail] ([PersonId], [ApplicationId])
    INCLUDE ([CreatedDate], [NotificationType], [NotificationTitle])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_Integration_ShiftDutyRoasterDetail_PersonId_ApplicationId'
END
ELSE
    PRINT 'Index IX_Integration_ShiftDutyRoasterDetail_PersonId_ApplicationId already exists'

-- Index for NotificationType (for filtering by notification type)
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID('dbo.Integration_ShiftDutyRoasterDetail') AND name = 'IX_Integration_ShiftDutyRoasterDetail_NotificationType')
BEGIN
    CREATE NONCLUSTERED INDEX [IX_Integration_ShiftDutyRoasterDetail_NotificationType]
    ON [dbo].[Integration_ShiftDutyRoasterDetail] ([NotificationType])
    INCLUDE ([CreatedDate], [PersonId], [NotificationTitle])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    
    PRINT 'Created index: IX_Integration_ShiftDutyRoasterDetail_NotificationType'
END
ELSE
    PRINT 'Index IX_Integration_ShiftDutyRoasterDetail_NotificationType already exists'

-- Update statistics for better query performance
UPDATE STATISTICS [dbo].[Integration_ShiftDutyRoasterDetail]
PRINT 'Updated statistics for Integration_ShiftDutyRoasterDetail table'

PRINT 'Index optimization completed successfully!'
GO