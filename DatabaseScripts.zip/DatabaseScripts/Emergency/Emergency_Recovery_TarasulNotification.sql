-- =============================================
-- Emergency Recovery Script for TarasulNotification
-- Purpose: Disable job and restore data if needed
-- Usage: Use in case cleanup job needs to be stopped or issues arise
-- =============================================

USE [JointPortal_QA]
GO

PRINT '========================================'
PRINT 'TARASULNOTIFICATION EMERGENCY RECOVERY'
PRINT '========================================'
PRINT 'Script started at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)
PRINT ''

-- Option 1: Disable the cleanup job
PRINT '1. DISABLE CLEANUP JOB:'
PRINT '----------------------'

DECLARE @JobName NVARCHAR(128) = 'JointPortal_TarasulNotification_Cleanup'

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = @JobName)
BEGIN
    EXEC msdb.dbo.sp_update_job 
        @job_name = @JobName, 
        @enabled = 0
        
    PRINT 'Job "' + @JobName + '" has been DISABLED.'
    PRINT 'To re-enable: EXEC msdb.dbo.sp_update_job @job_name = ''' + @JobName + ''', @enabled = 1'
END
ELSE
BEGIN
    PRINT 'Job "' + @JobName + '" not found.'
    PRINT 'Checking if job exists with different name...'
    
    SELECT name AS FoundJobs 
    FROM msdb.dbo.sysjobs 
    WHERE name LIKE '%TarasulNotification%' 
       OR name LIKE '%Tarasul%'
    
    IF @@ROWCOUNT = 0
        PRINT 'No TarasulNotification cleanup jobs found.'
END

PRINT ''

-- Option 2: Stop currently running job
PRINT '2. STOP RUNNING JOB (if applicable):'
PRINT '-----------------------------------'

IF EXISTS (
    SELECT 1 
    FROM msdb.dbo.sysjobs j
    INNER JOIN msdb.dbo.sysjobactivity ja ON j.job_id = ja.job_id
    WHERE j.name = @JobName 
      AND ja.run_requested_date IS NOT NULL 
      AND ja.stop_requested_date IS NULL
)
BEGIN
    EXEC msdb.dbo.sp_stop_job @job_name = @JobName
    PRINT 'Stop request sent for job "' + @JobName + '"'
    PRINT 'Note: Job may take a few moments to stop completely.'
END
ELSE
BEGIN
    PRINT 'No running instance of job "' + @JobName + '" found.'
END

PRINT ''

-- Option 3: Check recent job history
PRINT '3. RECENT JOB EXECUTION HISTORY:'
PRINT '-------------------------------'

SELECT TOP 10
    h.instance_id,
    j.name AS JobName,
    h.step_name,
    CASE h.run_status
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 4 THEN 'Running'
    END AS Status,
    msdb.dbo.agent_datetime(h.run_date, h.run_time) AS RunDateTime,
    h.run_duration,
    LEFT(h.message, 200) + CASE WHEN LEN(h.message) > 200 THEN '...' ELSE '' END AS MessagePreview
FROM msdb.dbo.sysjobhistory h
INNER JOIN msdb.dbo.sysjobs j ON h.job_id = j.job_id
WHERE j.name LIKE '%TarasulNotification%' OR j.name LIKE '%Tarasul%'
ORDER BY h.instance_id DESC

PRINT ''

-- Option 4: Current table status
PRINT '4. CURRENT TABLE STATUS:'
PRINT '-----------------------'

DECLARE @TotalRecords BIGINT
DECLARE @DeletedRecords BIGINT
DECLARE @ActiveRecords BIGINT
DECLARE @OldRecords BIGINT
DECLARE @RecentRecords BIGINT
DECLARE @CutoffDate DATETIME = DATEADD(MONTH, -1, GETDATE())

SELECT @TotalRecords = COUNT(*) FROM [dbo].[TarasulNotification]
SELECT @DeletedRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 1
SELECT @ActiveRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 0 OR [IsDeleted] IS NULL
SELECT @OldRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [CreatedDate] < @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
SELECT @RecentRecords = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [CreatedDate] >= @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)

PRINT 'Total records: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Marked deleted records (IsDeleted=1): ' + CAST(ISNULL(@DeletedRecords, 0) AS NVARCHAR(20))
PRINT 'Active records: ' + CAST(ISNULL(@ActiveRecords, 0) AS NVARCHAR(20))
PRINT 'Old active records (>1 month): ' + CAST(ISNULL(@OldRecords, 0) AS NVARCHAR(20))
PRINT 'Recent active records (<=1 month): ' + CAST(ISNULL(@RecentRecords, 0) AS NVARCHAR(20))
PRINT 'Cutoff date: ' + CONVERT(NVARCHAR(23), @CutoffDate, 121)

PRINT ''

-- Option 5: Check for blocking or locks
PRINT '5. CHECK FOR BLOCKING/LOCKS:'
PRINT '----------------------------'

IF EXISTS (
    SELECT 1 
    FROM sys.dm_tran_locks l
    INNER JOIN sys.objects o ON l.resource_associated_entity_id = o.object_id
    WHERE o.name = 'TarasulNotification'
)
BEGIN
    SELECT 
        s.session_id,
        s.login_name,
        s.program_name,
        s.host_name,
        l.resource_type,
        l.resource_description,
        l.request_mode,
        l.request_status,
        r.command,
        r.percent_complete
    FROM sys.dm_tran_locks l
    INNER JOIN sys.objects o ON l.resource_associated_entity_id = o.object_id
    INNER JOIN sys.dm_exec_sessions s ON l.request_session_id = s.session_id
    LEFT JOIN sys.dm_exec_requests r ON s.session_id = r.session_id
    WHERE o.name = 'TarasulNotification'
    
    PRINT 'Found locks on TarasulNotification table (see results above).'
END
ELSE
BEGIN
    PRINT 'No locks found on TarasulNotification table.'
END

PRINT ''

-- Option 6: Delete job completely (commented out for safety)
PRINT '6. DELETE JOB COMPLETELY (COMMENTED OUT):'
PRINT '----------------------------------------'
PRINT '-- To completely remove the job, uncomment and run:'
PRINT '-- EXEC msdb.dbo.sp_delete_job @job_name = ''' + @JobName + ''', @delete_unused_schedule = 1'
PRINT ''

-- Option 7: Modify retention period or job parameters
PRINT '7. MODIFY JOB PARAMETERS:'
PRINT '------------------------'
PRINT '-- To change retention period to 2 months, modify the job step:'
PRINT '-- EXEC msdb.dbo.sp_update_jobstep'
PRINT '--     @job_name = ''' + @JobName + ''','
PRINT '--     @step_id = 1,'
PRINT '--     @command = ''<updated command with @RetentionMonths = 2>'''
PRINT ''
PRINT '-- To change schedule (e.g., to 3:00 AM):'
PRINT '-- EXEC msdb.dbo.sp_update_schedule'
PRINT '--     @schedule_name = ''Daily_2-30AM_TarasulNotification_Cleanup'','
PRINT '--     @active_start_time = 030000'
PRINT ''

-- Option 8: Manual cleanup with different parameters
PRINT '8. MANUAL CLEANUP OPTIONS:'
PRINT '-------------------------'
PRINT '-- Keep 2 months of data instead of 1:'
PRINT '-- EXEC [dbo].[USP_TarasulNotification_Cleanup] @RetentionMonths = 2'
PRINT ''
PRINT '-- Only delete marked records (skip old records):'
PRINT '-- EXEC [dbo].[USP_TarasulNotification_Cleanup] @RetentionMonths = 0, @DeleteMarkedRecords = 1'
PRINT ''
PRINT '-- Only delete old records (skip marked deleted records):'
PRINT '-- EXEC [dbo].[USP_TarasulNotification_Cleanup] @DeleteMarkedRecords = 0'
PRINT ''
PRINT '-- Use smaller batch size for less impact:'
PRINT '-- EXEC [dbo].[USP_TarasulNotification_Cleanup] @BatchSize = 1000'
PRINT ''

-- Option 9: Check stored procedure status
PRINT '9. STORED PROCEDURE STATUS:'
PRINT '--------------------------'

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_TarasulNotification_Cleanup]') AND type in (N'P', N'PC'))
BEGIN
    PRINT 'Stored procedure USP_TarasulNotification_Cleanup EXISTS and is available.'
    
    -- Get procedure details
    SELECT 
        o.name AS ProcedureName,
        o.create_date AS CreatedDate,
        o.modify_date AS LastModified,
        m.definition AS [ProcDefinitionPreview]
    FROM sys.objects o
    LEFT JOIN sys.sql_modules m ON o.object_id = m.object_id
    WHERE o.name = 'USP_TarasulNotification_Cleanup'
    
END
ELSE
BEGIN
    PRINT 'Stored procedure USP_TarasulNotification_Cleanup NOT FOUND.'
    PRINT 'To create it, run: DatabaseScripts/StoredProcedures/USP_TarasulNotification_Cleanup.sql'
END

PRINT ''

-- Option 10: Backup recommendations before making changes
PRINT '10. BACKUP RECOMMENDATIONS:'
PRINT '---------------------------'
PRINT '-- Before making any changes, consider backing up important data:'
PRINT '-- SELECT * INTO TarasulNotification_Backup_' + CONVERT(NVARCHAR(8), GETDATE(), 112)
PRINT '-- FROM TarasulNotification'
PRINT '-- WHERE CreatedDate >= DATEADD(MONTH, -2, GETDATE())'  -- Backup last 2 months
PRINT ''
PRINT '-- To backup only active records:'
PRINT '-- SELECT * INTO TarasulNotification_Active_Backup_' + CONVERT(NVARCHAR(8), GETDATE(), 112)
PRINT '-- FROM TarasulNotification'
PRINT '-- WHERE (IsDeleted = 0 OR IsDeleted IS NULL) AND CreatedDate >= DATEADD(MONTH, -2, GETDATE())'
PRINT ''

-- Option 11: Check notification patterns that might need special handling
PRINT '11. NOTIFICATION PATTERNS ANALYSIS:'
PRINT '----------------------------------'

SELECT 
    'Notification Type Distribution' AS AnalysisType,
    CAST([NotificationType] AS NVARCHAR(50)) AS Category,
    COUNT(*) AS TotalCount,
    COUNT(CASE WHEN [IsDeleted] = 1 THEN 1 END) AS MarkedDeletedCount,
    COUNT(CASE WHEN [CreatedDate] < @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL) THEN 1 END) AS OldActiveCount,
    MIN([CreatedDate]) AS OldestRecord,
    MAX([CreatedDate]) AS NewestRecord
FROM [dbo].[TarasulNotification]
GROUP BY [NotificationType]

UNION ALL

SELECT 
    'Module Type Distribution' AS AnalysisType,
    'Module_' + CAST(ISNULL([ModuleTypeId], 0) AS NVARCHAR(50)) AS Category,
    COUNT(*) AS TotalCount,
    COUNT(CASE WHEN [IsDeleted] = 1 THEN 1 END) AS MarkedDeletedCount,
    COUNT(CASE WHEN [CreatedDate] < @CutoffDate AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL) THEN 1 END) AS OldActiveCount,
    MIN([CreatedDate]) AS OldestRecord,
    MAX([CreatedDate]) AS NewestRecord
FROM [dbo].[TarasulNotification]
GROUP BY [ModuleTypeId]
ORDER BY TotalCount DESC

PRINT ''
PRINT '========================================'
PRINT 'EMERGENCY RECOVERY OPTIONS DISPLAYED'
PRINT '========================================'
PRINT 'Script completed at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)
PRINT ''
PRINT 'IMPORTANT NOTES:'
PRINT '- Job has been DISABLED as a precaution'
PRINT '- Review the options above and execute as needed'
PRINT '- TarasulNotification has special IsDeleted flag handling'
PRINT '- Two-phase cleanup: marked deleted records + old active records'
PRINT '- Test any changes in a non-production environment first'
PRINT '- Monitor system performance after any modifications'
PRINT '- Consider the notification patterns when adjusting retention periods'

-- Show current job status after changes
PRINT ''
PRINT '12. FINAL JOB STATUS CHECK:'
PRINT '---------------------------'

SELECT 
    j.name AS JobName,
    CASE j.enabled WHEN 1 THEN 'ENABLED' ELSE 'DISABLED' END AS CurrentStatus,
    j.description,
    CASE 
        WHEN s.name IS NOT NULL THEN s.name 
        ELSE 'No Schedule' 
    END AS ScheduleName,
    CASE 
        WHEN s.enabled = 1 THEN 'Schedule Enabled' 
        WHEN s.enabled = 0 THEN 'Schedule Disabled'
        ELSE 'No Schedule'
    END AS ScheduleStatus
FROM msdb.dbo.sysjobs j
LEFT JOIN msdb.dbo.sysjobschedules js ON j.job_id = js.job_id
LEFT JOIN msdb.dbo.sysschedules s ON js.schedule_id = s.schedule_id
WHERE j.name LIKE '%TarasulNotification%' OR j.name LIKE '%Tarasul%'

GO