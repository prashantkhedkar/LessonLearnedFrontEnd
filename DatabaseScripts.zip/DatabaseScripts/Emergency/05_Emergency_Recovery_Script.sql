-- =============================================
-- Emergency Recovery Script for Integration_ShiftDutyRoasterDetail
-- Purpose: Disable job and restore data if needed
-- Usage: Use in case cleanup job needs to be stopped or issues arise
-- =============================================

USE [JointPortal_QA]
GO

PRINT '========================================'
PRINT 'EMERGENCY RECOVERY SCRIPT'
PRINT '========================================'
PRINT 'Script started at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)
PRINT ''

-- Option 1: Disable the cleanup job
PRINT '1. DISABLE CLEANUP JOB:'
PRINT '----------------------'

DECLARE @JobName NVARCHAR(128) = 'JointPortal_Integration_ShiftDutyRoasterDetail_Cleanup'

IF EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = @JobName)
BEGIN
    EXEC msdb.dbo.sp_update_job 
        @job_name = @JobName, 
        @enabled = 0
        
    PRINT 'Job "' + @JobName + '" has been DISABLED.'
    PRINT 'To re-enable: EXEC msdb.dbo.sp_update_job @job_name = ''' + @JobName + ''', @enabled = 1'
END
ELSE
BEGIN
    PRINT 'Job "' + @JobName + '" not found.'
END

PRINT ''

-- Option 2: Stop currently running job
PRINT '2. STOP RUNNING JOB (if applicable):'
PRINT '-----------------------------------'

IF EXISTS (
    SELECT 1 
    FROM msdb.dbo.sysjobs j
    INNER JOIN msdb.dbo.sysjobactivity ja ON j.job_id = ja.job_id
    WHERE j.name = @JobName 
      AND ja.run_requested_date IS NOT NULL 
      AND ja.stop_requested_date IS NULL
)
BEGIN
    EXEC msdb.dbo.sp_stop_job @job_name = @JobName
    PRINT 'Stop request sent for job "' + @JobName + '"'
    PRINT 'Note: Job may take a few moments to stop completely.'
END
ELSE
BEGIN
    PRINT 'No running instance of job "' + @JobName + '" found.'
END

PRINT ''

-- Option 3: Check recent job history
PRINT '3. RECENT JOB EXECUTION HISTORY:'
PRINT '-------------------------------'

SELECT TOP 10
    h.instance_id,
    j.name AS JobName,
    h.step_name,
    CASE h.run_status
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 4 THEN 'Running'
    END AS Status,
    msdb.dbo.agent_datetime(h.run_date, h.run_time) AS RunDateTime,
    h.run_duration,
    LEFT(h.message, 100) + CASE WHEN LEN(h.message) > 100 THEN '...' ELSE '' END AS MessagePreview
FROM msdb.dbo.sysjobhistory h
INNER JOIN msdb.dbo.sysjobs j ON h.job_id = j.job_id
WHERE j.name = @JobName
ORDER BY h.instance_id DESC

PRINT ''

-- Option 4: Current table status
PRINT '4. CURRENT TABLE STATUS:'
PRINT '-----------------------'

DECLARE @TotalRecords BIGINT
DECLARE @OldRecords BIGINT
DECLARE @RecentRecords BIGINT
DECLARE @CutoffDate DATETIME = DATEADD(MONTH, -1, GETDATE())

SELECT @TotalRecords = COUNT(*) FROM [dbo].[Integration_ShiftDutyRoasterDetail]
SELECT @OldRecords = COUNT(*) FROM [dbo].[Integration_ShiftDutyRoasterDetail] WHERE [CreatedDate] < @CutoffDate
SELECT @RecentRecords = COUNT(*) FROM [dbo].[Integration_ShiftDutyRoasterDetail] WHERE [CreatedDate] >= @CutoffDate

PRINT 'Total records: ' + CAST(ISNULL(@TotalRecords, 0) AS NVARCHAR(20))
PRINT 'Records older than 1 month: ' + CAST(ISNULL(@OldRecords, 0) AS NVARCHAR(20))
PRINT 'Records within last month: ' + CAST(ISNULL(@RecentRecords, 0) AS NVARCHAR(20))
PRINT 'Cutoff date: ' + CONVERT(NVARCHAR(23), @CutoffDate, 121)

PRINT ''

-- Option 5: Delete job completely (commented out for safety)
PRINT '5. DELETE JOB COMPLETELY (COMMENTED OUT):'
PRINT '----------------------------------------'
PRINT '-- To completely remove the job, uncomment and run:'
PRINT '-- EXEC msdb.dbo.sp_delete_job @job_name = ''' + @JobName + ''', @delete_unused_schedule = 1'
PRINT ''

-- Option 6: Modify retention period
PRINT '6. MODIFY RETENTION PERIOD:'
PRINT '--------------------------'
PRINT '-- To change retention period, modify the job step command:'
PRINT '-- EXEC msdb.dbo.sp_update_jobstep'
PRINT '--     @job_name = ''' + @JobName + ''','
PRINT '--     @step_id = 1,'
PRINT '--     @command = ''EXEC [JointPortal_QA].[dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup] @RetentionMonths = 2'''
PRINT ''

-- Option 7: Manual cleanup with different parameters
PRINT '7. MANUAL CLEANUP OPTIONS:'
PRINT '-------------------------'
PRINT '-- Keep 2 months of data instead of 1:'
PRINT '-- EXEC [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup] @RetentionMonths = 2'
PRINT ''
PRINT '-- Keep 3 months of data:'
PRINT '-- EXEC [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup] @RetentionMonths = 3'
PRINT ''
PRINT '-- Use smaller batch size for less impact:'
PRINT '-- EXEC [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup] @RetentionMonths = 1, @BatchSize = 1000'
PRINT ''

-- Option 8: Check for blocking or locks
PRINT '8. CHECK FOR BLOCKING/LOCKS:'
PRINT '----------------------------'

IF EXISTS (
    SELECT 1 
    FROM sys.dm_tran_locks l
    INNER JOIN sys.objects o ON l.resource_associated_entity_id = o.object_id
    WHERE o.name = 'Integration_ShiftDutyRoasterDetail'
)
BEGIN
    SELECT 
        s.session_id,
        s.login_name,
        s.program_name,
        s.host_name,
        l.resource_type,
        l.resource_description,
        l.request_mode,
        l.request_status
    FROM sys.dm_tran_locks l
    INNER JOIN sys.objects o ON l.resource_associated_entity_id = o.object_id
    INNER JOIN sys.dm_exec_sessions s ON l.request_session_id = s.session_id
    WHERE o.name = 'Integration_ShiftDutyRoasterDetail'
    
    PRINT 'Found locks on Integration_ShiftDutyRoasterDetail table.'
END
ELSE
BEGIN
    PRINT 'No locks found on Integration_ShiftDutyRoasterDetail table.'
END

PRINT ''

-- Option 9: Backup recommendations
PRINT '9. BACKUP RECOMMENDATIONS:'
PRINT '-------------------------'
PRINT '-- Before making any changes, consider backing up the data:'
PRINT '-- SELECT * INTO Integration_ShiftDutyRoasterDetail_Backup_' + CONVERT(NVARCHAR(8), GETDATE(), 112)
PRINT '-- FROM Integration_ShiftDutyRoasterDetail'
PRINT '-- WHERE CreatedDate >= DATEADD(MONTH, -1, GETDATE())'
PRINT ''

PRINT '========================================'
PRINT 'EMERGENCY RECOVERY OPTIONS DISPLAYED'
PRINT '========================================'
PRINT 'Script completed at: ' + CONVERT(NVARCHAR(23), GETDATE(), 121)
PRINT ''
PRINT 'IMPORTANT NOTES:'
PRINT '- Job has been DISABLED as a precaution'
PRINT '- Review the options above and execute as needed'
PRINT '- Test any changes in a non-production environment first'
PRINT '- Monitor system performance after any modifications'

GO