-- =============================================
-- Optional: Create System Error Log Table
-- Purpose: Provides structured error logging for database procedures
-- Usage: Run this script if you want detailed error logging in a table
-- Note: This is optional - the cleanup procedure works without it
-- =============================================

USE [JointPortal_QA]
GO

-- Check if the table already exists
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'SystemErrorLog')
BEGIN
    PRINT 'Creating SystemErrorLog table...'
    
    CREATE TABLE [dbo].[SystemErrorLog](
        [Id] [bigint] IDENTITY(1,1) NOT NULL,
        [ErrorMessage] [nvarchar](max) NOT NULL,
        [ErrorDetails] [nvarchar](max) NULL,
        [ProcedureName] [nvarchar](255) NULL,
        [ErrorNumber] [int] NULL,
        [ErrorSeverity] [int] NULL,
        [ErrorLine] [int] NULL,
        [UserName] [nvarchar](255) NULL,
        [ApplicationName] [nvarchar](255) NULL,
        [HostName] [nvarchar](255) NULL,
        [CreatedDate] [datetime2] NOT NULL CONSTRAINT [DF_SystemErrorLog_CreatedDate] DEFAULT (GETDATE()),
        [SessionId] [int] NULL,
        [DatabaseName] [nvarchar](128) NULL,
        
        CONSTRAINT [PK_SystemErrorLog] PRIMARY KEY CLUSTERED ([Id] ASC)
        WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, 
              ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
    
    PRINT 'SystemErrorLog table created successfully.'
    
    -- Create index on CreatedDate for better query performance
    CREATE NONCLUSTERED INDEX [IX_SystemErrorLog_CreatedDate] 
    ON [dbo].[SystemErrorLog] ([CreatedDate] DESC)
    INCLUDE ([ErrorMessage], [ProcedureName], [ErrorNumber])
    
    PRINT 'Index created on SystemErrorLog.CreatedDate.'
    
END
ELSE
BEGIN
    PRINT 'SystemErrorLog table already exists.'
END
GO

-- Create or update the enhanced error logging procedure
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_LogError]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[USP_LogError]
GO

CREATE PROCEDURE [dbo].[USP_LogError]
    @ErrorMessage NVARCHAR(MAX),
    @ErrorDetails NVARCHAR(MAX) = NULL,
    @ProcedureName NVARCHAR(255) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        INSERT INTO [dbo].[SystemErrorLog] (
            [ErrorMessage],
            [ErrorDetails],
            [ProcedureName],
            [ErrorNumber],
            [ErrorSeverity],
            [ErrorLine],
            [UserName],
            [ApplicationName],
            [HostName],
            [SessionId],
            [DatabaseName],
            [CreatedDate]
        )
        VALUES (
            @ErrorMessage,
            @ErrorDetails,
            ISNULL(@ProcedureName, ERROR_PROCEDURE()),
            ERROR_NUMBER(),
            ERROR_SEVERITY(),
            ERROR_LINE(),
            SUSER_SNAME(),
            APP_NAME(),
            HOST_NAME(),
            @@SPID,
            DB_NAME(),
            GETDATE()
        )
        
    END TRY
    BEGIN CATCH
        -- If error logging fails, write to SQL Server Error Log instead
        DECLARE @LogMessage NVARCHAR(MAX) = 
            'Failed to log error to SystemErrorLog table. Original error: ' + @ErrorMessage
        EXEC xp_logevent 50002, @LogMessage, 'ERROR'
    END CATCH
END
GO

-- Grant execute permissions
GRANT EXECUTE ON [dbo].[USP_LogError] TO [public]
GO

-- Create a cleanup procedure for the error log table to prevent it from growing too large
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_SystemErrorLog_Cleanup]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[USP_SystemErrorLog_Cleanup]
GO

CREATE PROCEDURE [dbo].[USP_SystemErrorLog_Cleanup]
    @RetentionDays INT = 30
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @CutoffDate DATETIME2 = DATEADD(DAY, -@RetentionDays, GETDATE())
    DECLARE @DeletedCount INT
    
    DELETE FROM [dbo].[SystemErrorLog]
    WHERE [CreatedDate] < @CutoffDate
    
    SET @DeletedCount = @@ROWCOUNT
    
    PRINT 'Cleaned up ' + CAST(@DeletedCount AS NVARCHAR(10)) + ' error log records older than ' + 
          CAST(@RetentionDays AS NVARCHAR(10)) + ' days.'
    
    -- Update statistics
    UPDATE STATISTICS [dbo].[SystemErrorLog]
END
GO

-- Grant execute permissions
GRANT EXECUTE ON [dbo].[USP_SystemErrorLog_Cleanup] TO [public]
GO

-- Now update the main cleanup procedure to use structured error logging if the table exists
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup_Enhanced]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup_Enhanced]
GO

CREATE PROCEDURE [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup_Enhanced]
    @RetentionMonths INT = 1,
    @BatchSize INT = 5000,
    @LogResults BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @StartTime DATETIME2 = GETDATE()
    DECLARE @CutoffDate DATETIME
    DECLARE @TotalRowsDeleted BIGINT = 0
    DECLARE @BatchRowsDeleted INT = 0
    DECLARE @LogMessage NVARCHAR(MAX)
    DECLARE @ErrorMessage NVARCHAR(MAX)
    
    BEGIN TRY
        -- Validate input parameters
        IF @RetentionMonths < 0 OR @RetentionMonths > 120
        BEGIN
            SET @ErrorMessage = 'Invalid @RetentionMonths parameter. Must be between 0 and 120.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        IF @BatchSize < 1 OR @BatchSize > 50000
        BEGIN
            SET @ErrorMessage = 'Invalid @BatchSize parameter. Must be between 1 and 50000.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        -- Calculate cutoff date (retain only records from last N months)
        SET @CutoffDate = DATEADD(MONTH, -@RetentionMonths, GETDATE())
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Starting cleanup of Integration_ShiftDutyRoasterDetail table. Cutoff date: ' + CONVERT(NVARCHAR(23), @CutoffDate, 121)
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Get initial count for reporting
        DECLARE @InitialCount BIGINT
        SELECT @InitialCount = COUNT(*) 
        FROM [dbo].[Integration_ShiftDutyRoasterDetail] 
        WHERE [CreatedDate] < @CutoffDate
        
        IF @InitialCount = 0
        BEGIN
            IF @LogResults = 1
                PRINT 'No records found older than cutoff date. Cleanup not required.'
            RETURN
        END
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Found ' + CAST(@InitialCount AS NVARCHAR(20)) + ' records to delete.'
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Delete in batches to avoid long-running transactions
        WHILE EXISTS (SELECT 1 FROM [dbo].[Integration_ShiftDutyRoasterDetail] WHERE [CreatedDate] < @CutoffDate)
        BEGIN
            BEGIN TRANSACTION
            
            DELETE TOP (@BatchSize)
            FROM [dbo].[Integration_ShiftDutyRoasterDetail]
            WHERE [CreatedDate] < @CutoffDate
            
            SET @BatchRowsDeleted = @@ROWCOUNT
            SET @TotalRowsDeleted = @TotalRowsDeleted + @BatchRowsDeleted
            
            COMMIT TRANSACTION
            
            IF @LogResults = 1 AND @BatchRowsDeleted > 0
            BEGIN
                SET @LogMessage = 'Deleted batch of ' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + ' records. Total deleted: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20))
                PRINT @LogMessage
                RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
            END
            
            -- Small delay between batches to reduce system load
            IF @BatchRowsDeleted > 0
                WAITFOR DELAY '00:00:02'
            ELSE
                BREAK -- No more records to delete
        END
        
        -- Log completion
        DECLARE @EndTime DATETIME2 = GETDATE()
        DECLARE @Duration INT = DATEDIFF(SECOND, @StartTime, @EndTime)
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Cleanup completed successfully. Total records deleted: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + 
                             '. Duration: ' + CAST(@Duration AS NVARCHAR(10)) + ' seconds.'
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Update table statistics after cleanup
        UPDATE STATISTICS [dbo].[Integration_ShiftDutyRoasterDetail]
        
        IF @LogResults = 1
            PRINT 'Table statistics updated.'
        
        -- Return summary information
        SELECT 
            @TotalRowsDeleted AS RecordsDeleted,
            @Duration AS DurationSeconds,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            GETDATE() AS CompletedAt
            
    END TRY
    BEGIN CATCH
        -- Rollback transaction if active
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION
        
        SET @ErrorMessage = 'Error during cleanup: ' + ERROR_MESSAGE() + 
                           ' (Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR(10)) + 
                           ', Line: ' + CAST(ERROR_LINE() AS NVARCHAR(10)) + ')'
        
        PRINT @ErrorMessage
        RAISERROR(@ErrorMessage, 16, 1)
        
        -- Try to log to structured error table first
        DECLARE @ErrorDetails NVARCHAR(MAX) = 
            'Retention Months: ' + CAST(@RetentionMonths AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Batch Size: ' + CAST(@BatchSize AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Cutoff Date: ' + ISNULL(CONVERT(NVARCHAR(23), @CutoffDate, 121), 'NULL') + CHAR(13) + CHAR(10) +
            'Records Deleted Before Error: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20))
        
        -- Check if error logging table exists and use it
        IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'SystemErrorLog')
        BEGIN
            EXEC [dbo].[USP_LogError] 
                @ErrorMessage = @ErrorMessage,
                @ErrorDetails = @ErrorDetails,
                @ProcedureName = 'USP_Integration_ShiftDutyRoasterDetail_Cleanup_Enhanced'
        END
        ELSE
        BEGIN
            -- Fallback to SQL Server Error Log
            EXEC xp_logevent 50001, @ErrorDetails, 'ERROR'
        END
        
        -- Return error information
        SELECT 
            @TotalRowsDeleted AS RecordsDeletedBeforeError,
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_MESSAGE() AS ErrorMessage,
            ERROR_LINE() AS ErrorLine,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            GETDATE() AS ErrorOccurredAt
        
    END CATCH
END
GO

-- Grant execute permissions
GRANT EXECUTE ON [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup_Enhanced] TO [public]
GO

PRINT '========================================'
PRINT 'OPTIONAL ERROR LOGGING SETUP COMPLETED'
PRINT '========================================'
PRINT ''
PRINT 'CREATED OBJECTS:'
PRINT '- SystemErrorLog table'
PRINT '- USP_LogError procedure'
PRINT '- USP_SystemErrorLog_Cleanup procedure'
PRINT '- USP_Integration_ShiftDutyRoasterDetail_Cleanup_Enhanced procedure'
PRINT ''
PRINT 'USAGE OPTIONS:'
PRINT '1. Use the original procedure (no error table required):'
PRINT '   EXEC USP_Integration_ShiftDutyRoasterDetail_Cleanup'
PRINT ''
PRINT '2. Use the enhanced procedure (with structured error logging):'
PRINT '   EXEC USP_Integration_ShiftDutyRoasterDetail_Cleanup_Enhanced'
PRINT ''
PRINT '3. Clean up error logs periodically:'
PRINT '   EXEC USP_SystemErrorLog_Cleanup @RetentionDays = 30'
PRINT ''
PRINT 'NOTES:'
PRINT '- Both procedures perform the same cleanup function'
PRINT '- Enhanced version provides better error tracking'
PRINT '- Error log table needs periodic cleanup to prevent growth'
GO