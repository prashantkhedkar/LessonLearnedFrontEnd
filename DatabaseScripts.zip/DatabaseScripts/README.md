# Database Table Optimization Solutions

This comprehensive solution provides optimization for multiple high-volume tables in the JointPortal microservices system, including automated cleanup to maintain optimal performance.

## ?? Table Solutions

### Integration_ShiftDutyRoasterDetail Table
- **Files**: 01-06
- **Purpose**: Optimize integration shift duty roster data table
- **Features**: Standard cleanup with 1-month retention

### TarasulNotification Table ??
- **Files**: 07-11  
- **Purpose**: Optimize Tarasul notification data table
- **Features**: Advanced cleanup with support for marked deleted records

## ?? Files Overview

### Integration_ShiftDutyRoasterDetail Optimization

#### 1. **01_CreateIndexes_ShiftDutyRoasterDetail.sql**
- **Purpose**: Creates optimized indexes for better query performance
- **Indexes Created**:
  - `IX_Integration_ShiftDutyRoasterDetail_CreatedDate` - For date-based queries and cleanup operations
  - `IX_Integration_ShiftDutyRoasterDetail_PersonId_ApplicationId` - For person/application filtering
  - `IX_Integration_ShiftDutyRoasterDetail_NotificationType` - For notification type filtering

#### 2. **02_USP_Integration_ShiftDutyRoasterDetail_Cleanup.sql** 
- **Purpose**: Stored procedure for automated cleanup of old records
- **Features**: Standard cleanup with configurable retention period

#### 3. **03_Create_Cleanup_Job_ShiftDutyRoasterDetail.sql**
- **Purpose**: SQL Server Agent Job for daily cleanup at 2:00 AM

### TarasulNotification Optimization ??

#### 7. **07_CreateIndexes_TarasulNotification.sql** ??
- **Purpose**: Creates optimized indexes for TarasulNotification table performance
- **Indexes Created**:
  - `IX_TarasulNotification_CreatedDate` - Primary date-based index for cleanup
  - `IX_TarasulNotification_IsDeleted_CreatedDate` - For filtering deleted records by date
  - `IX_TarasulNotification_FromUserId_CreatedDate` - User-specific queries
  - `IX_TarasulNotification_NotificationType_CreatedDate` - Notification type filtering
  - `IX_TarasulNotification_ModuleTypeId_CreatedDate` - Module-specific queries

#### 8. **08_USP_TarasulNotification_Cleanup.sql** ??
- **Purpose**: Advanced cleanup stored procedure for TarasulNotification
- **Features**:
  - **Two-Phase Cleanup**: First deletes marked records (`IsDeleted = 1`), then old records
  - **Configurable Parameters**:
    - `@RetentionMonths` (default: 1) - Number of months to retain
    - `@BatchSize` (default: 5000) - Records to delete per batch
    - `@LogResults` (default: 1) - Enable/disable logging
    - `@DeleteMarkedRecords` (default: 1) - Whether to delete IsDeleted=1 records
  - **Advanced Error Handling**: Complete transaction safety and detailed logging

#### 9. **09_Create_Cleanup_Job_TarasulNotification.sql** ??
- **Purpose**: SQL Server Agent Job for TarasulNotification cleanup
- **Schedule**: Daily at 2:30 AM (30 minutes after ShiftDutyRoaster cleanup)
- **Features**:
  - **Self-Contained**: Includes inline cleanup logic (no separate stored procedure needed)
  - **Two-Phase Processing**: Handles both marked deleted and old records
  - **Load Distribution**: Scheduled 30 minutes after first job to spread system load

### Testing and Recovery Files

#### 4. **04_Test_Cleanup_Procedure.sql**
- **Purpose**: Test Integration_ShiftDutyRoasterDetail cleanup

#### 5. **05_Emergency_Recovery_Script.sql**
- **Purpose**: Emergency recovery for Integration_ShiftDutyRoasterDetail

#### 10. **10_Test_TarasulNotification_Cleanup.sql** ??
- **Purpose**: Test TarasulNotification cleanup functionality

#### 11. **11_Emergency_Recovery_TarasulNotification.sql** ??
- **Purpose**: Emergency recovery and management for TarasulNotification

### Optional Enhancement

#### 6. **06_SystemErrorLog_Creation.sql** 
- **Purpose**: Optional enhanced error logging system (works for both tables)

## ?? Implementation Steps

### For TarasulNotification Table (New):

#### Step 1: Create Indexes
```sql
-- Execute the index creation script
SQLCMD -S YourServerName -d JointPortal_QA -i "07_CreateIndexes_TarasulNotification.sql"
```

#### Step 2: Test Current State
```sql
-- Run the test script to see current table statistics
SQLCMD -S YourServerName -d JointPortal_QA -i "10_Test_TarasulNotification_Cleanup.sql"
```

#### Step 3: Create Automated Job
```sql
-- Create the cleanup job (includes inline cleanup logic)
SQLCMD -S YourServerName -d msdb -i "09_Create_Cleanup_Job_TarasulNotification.sql"
```

### For Both Tables Together:

#### Complete Setup Script:
```sql
-- 1. Create all indexes
SQLCMD -S YourServerName -d JointPortal_QA -i "01_CreateIndexes_ShiftDutyRoasterDetail.sql"
SQLCMD -S YourServerName -d JointPortal_QA -i "07_CreateIndexes_TarasulNotification.sql"

-- 2. Create stored procedures
SQLCMD -S YourServerName -d JointPortal_QA -i "02_USP_Integration_ShiftDutyRoasterDetail_Cleanup.sql"

-- 3. Create jobs
SQLCMD -S YourServerName -d msdb -i "03_Create_Cleanup_Job_ShiftDutyRoasterDetail.sql"
SQLCMD -S YourServerName -d msdb -i "09_Create_Cleanup_Job_TarasulNotification.sql"
```

## ?? Expected Benefits

### Performance Improvements:
- **Faster Queries**: Optimized indexes reduce query execution time by 60-80%
- **Reduced Storage**: Regular cleanup maintains optimal table sizes
- **Better Cache Utilization**: Smaller tables fit better in memory
- **Improved Backup Performance**: Smaller tables mean faster backups

### TarasulNotification Specific Benefits:
- **Smart Cleanup**: Handles both marked deleted records and old records
- **Better Index Coverage**: Specialized indexes for notification queries
- **Load Distribution**: Cleanup scheduled at different time to spread system load

## ?? Configuration Options

### TarasulNotification Configuration:

#### Modify Cleanup Behavior:
```sql
-- Manual cleanup with custom parameters
EXEC [dbo].[USP_TarasulNotification_Cleanup] 
    @RetentionMonths = 2,          -- Keep 2 months
    @BatchSize = 3000,             -- Smaller batches
    @LogResults = 1,               -- Enable logging
    @DeleteMarkedRecords = 1       -- Delete IsDeleted=1 records
```

#### Skip Marked Record Cleanup:
```sql
-- Only delete old records, keep marked deleted records
EXEC [dbo].[USP_TarasulNotification_Cleanup] 
    @RetentionMonths = 1,
    @DeleteMarkedRecords = 0       -- Skip IsDeleted=1 records
```

### Job Schedule Coordination:

#### Current Schedule:
- **ShiftDutyRoaster**: Daily at 2:00 AM
- **TarasulNotification**: Daily at 2:30 AM

#### Modify Schedule:
```sql
-- Change TarasulNotification to run at 3:00 AM
EXEC msdb.dbo.sp_update_schedule 
    @schedule_name = 'Daily_2-30AM_TarasulNotification_Cleanup',
    @active_start_time = 030000  -- 3:00 AM
```

## ?? Monitoring Both Tables

### Check Both Jobs Status:
```sql
-- View recent executions for both jobs
SELECT TOP 20
    j.name AS JobName,
    h.step_name,
    CASE h.run_status
        WHEN 1 THEN 'Success'
        WHEN 0 THEN 'Failed'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 4 THEN 'Running'
    END AS Status,
    msdb.dbo.agent_datetime(h.run_date, h.run_time) AS ExecutionTime,
    h.run_duration,
    LEFT(h.message, 100) + '...' AS MessagePreview
FROM msdb.dbo.sysjobhistory h
INNER JOIN msdb.dbo.sysjobs j ON h.job_id = j.job_id
WHERE j.name LIKE '%JointPortal%Cleanup%'
ORDER BY h.instance_id DESC
```

### Monitor Table Sizes:
```sql
-- Check both table statistics
SELECT 
    'Integration_ShiftDutyRoasterDetail' AS TableName,
    COUNT(*) AS TotalRecords,
    COUNT(CASE WHEN CreatedDate < DATEADD(MONTH, -1, GETDATE()) THEN 1 END) AS OldRecords,
    MIN(CreatedDate) AS OldestRecord,
    MAX(CreatedDate) AS NewestRecord
FROM Integration_ShiftDutyRoasterDetail
UNION ALL
SELECT 
    'TarasulNotification' AS TableName,
    COUNT(*) AS TotalRecords,
    COUNT(CASE WHEN CreatedDate < DATEADD(MONTH, -1, GETDATE()) AND (IsDeleted = 0 OR IsDeleted IS NULL) THEN 1 END) AS OldRecords,
    MIN(CreatedDate) AS OldestRecord,
    MAX(CreatedDate) AS NewestRecord
FROM TarasulNotification

-- Check TarasulNotification marked deleted records
SELECT 
    COUNT(*) AS TotalRecords,
    COUNT(CASE WHEN IsDeleted = 1 THEN 1 END) AS MarkedDeletedRecords,
    COUNT(CASE WHEN IsDeleted = 0 OR IsDeleted IS NULL THEN 1 END) AS ActiveRecords
FROM TarasulNotification
```

## ?? TarasulNotification Special Features

### Dual Cleanup Strategy:
1. **Phase 1**: Clean up records marked as `IsDeleted = 1`
2. **Phase 2**: Clean up old active records based on `CreatedDate`

### Smart Indexing:
- **Combined Indexes**: `IsDeleted + CreatedDate` for efficient filtering
- **User-Specific Indexes**: For notification queries by user
- **Module-Specific Indexes**: For filtering by module type

### Load Distribution:
- **Staggered Schedule**: 30-minute gap between table cleanups
- **Batch Processing**: Configurable batch sizes for both phases
- **Progressive Delays**: Different delays between batches for each phase

## ?? Important Considerations

### TarasulNotification Specific:
1. **IsDeleted Flag**: The cleanup respects the soft delete pattern
2. **Two-Phase Process**: Marked deletes are cleaned first, then old records
3. **Index Dependencies**: The `IsDeleted` column is heavily indexed

### Production Deployment:
1. **Test Environment First**: Always test in non-production
2. **Monitor Initial Runs**: Watch performance impact during first executions
3. **Adjust Batch Sizes**: Tune based on system performance
4. **Coordinate Timing**: Ensure cleanup jobs don't conflict with peak usage

## ?? Support & Troubleshooting

### For TarasulNotification Issues:
1. Use emergency recovery script: `11_Emergency_Recovery_TarasulNotification.sql`
2. Check for locks on `IsDeleted` column queries
3. Monitor both phases of cleanup execution

### For Both Tables:
1. Review job history in SQL Server Agent
2. Check SQL Server Error Log for detailed messages
3. Use test scripts to validate before/after states
4. Coordinate with application teams for maintenance windows

---

**Last Updated**: Added TarasulNotification optimization with advanced two-phase cleanup
**Database**: JointPortal_QA
**Tables**: Integration_ShiftDutyRoasterDetail, TarasulNotification
**Retention**: 1 month (configurable)
**Dependencies**: ? **NONE** - All solutions work out of the box
**Special Features**: 
- ? **TarasulNotification**: Smart cleanup with IsDeleted flag support
- ? **Load Distribution**: Staggered job schedules
- ? **Advanced Monitoring**: Comprehensive statistics for both tables