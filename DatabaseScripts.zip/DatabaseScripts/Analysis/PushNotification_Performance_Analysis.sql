-- =============================================
-- Script: PushNotification Performance Analysis
-- Purpose: Analyze current performance and provide indexing recommendations
-- Author: Database Optimization
-- Date: Created for performance assessment
-- =============================================

USE [JointPortal_QA]
GO

PRINT '========================================'
PRINT 'PUSHNOTIFICATION PERFORMANCE ANALYSIS'
PRINT '========================================'

-- 1. TABLE SIZE AND GROWTH ANALYSIS
DECLARE @TableSize_MB DECIMAL(10,2)
DECLARE @IndexSize_MB DECIMAL(10,2)
DECLARE @TotalSize_MB DECIMAL(10,2)
DECLARE @RowCount BIGINT
DECLARE @AvgRowSize_Bytes INT

SELECT 
    @TableSize_MB = SUM(CASE WHEN index_id IN (0,1) THEN (used_page_count * 8) / 1024.0 ELSE 0 END),
    @IndexSize_MB = SUM(CASE WHEN index_id > 1 THEN (used_page_count * 8) / 1024.0 ELSE 0 END),
    @TotalSize_MB = SUM((used_page_count * 8) / 1024.0)
FROM sys.dm_db_partition_stats
WHERE object_id = OBJECT_ID('dbo.PushNotification')

SELECT @RowCount = COUNT(*) FROM [dbo].[PushNotification]
SET @AvgRowSize_Bytes = CASE WHEN @RowCount > 0 THEN (@TableSize_MB * 1024 * 1024) / @RowCount ELSE 0 END

PRINT '1. TABLE SIZE ANALYSIS:'
PRINT '----------------------'
PRINT 'Total Rows: ' + CAST(@RowCount AS NVARCHAR(20))
PRINT 'Table Size: ' + CAST(@TableSize_MB AS NVARCHAR(20)) + ' MB'
PRINT 'Index Size: ' + CAST(@IndexSize_MB AS NVARCHAR(20)) + ' MB'
PRINT 'Total Size: ' + CAST(@TotalSize_MB AS NVARCHAR(20)) + ' MB'
PRINT 'Avg Row Size: ' + CAST(@AvgRowSize_Bytes AS NVARCHAR(10)) + ' bytes'
PRINT 'Index Overhead: ' + CAST(CASE WHEN @TableSize_MB > 0 THEN (@IndexSize_MB / @TableSize_MB) * 100 ELSE 0 END AS NVARCHAR(10)) + '%'

-- 2. DATA DISTRIBUTION ANALYSIS
PRINT ''
PRINT '2. DATA DISTRIBUTION ANALYSIS:'
PRINT '------------------------------'

-- Date distribution
DECLARE @OldestDate DATETIME, @NewestDate DATETIME, @AvgPerDay DECIMAL(10,2)
SELECT @OldestDate = MIN(CreatedDate), @NewestDate = MAX(CreatedDate) FROM [dbo].[PushNotification]

IF DATEDIFF(DAY, @OldestDate, @NewestDate) > 0
    SET @AvgPerDay = @RowCount / DATEDIFF(DAY, @OldestDate, @NewestDate)
ELSE
    SET @AvgPerDay = @RowCount

PRINT 'Date Range: ' + CONVERT(NVARCHAR(23), @OldestDate, 121) + ' to ' + CONVERT(NVARCHAR(23), @NewestDate, 121)
PRINT 'Days of Data: ' + CAST(DATEDIFF(DAY, @OldestDate, @NewestDate) AS NVARCHAR(10))
PRINT 'Avg Records/Day: ' + CAST(@AvgPerDay AS NVARCHAR(20))

-- Check for data skew
SELECT TOP 5
    'NotificationType Distribution:' as Analysis,
    NotificationType,
    COUNT(*) as RecordCount,
    CAST((COUNT(*) * 100.0 / @RowCount) AS DECIMAL(5,2)) as Percentage
FROM [dbo].[PushNotification]
GROUP BY NotificationType
ORDER BY COUNT(*) DESC

-- IsDeleted distribution
SELECT 
    'IsDeleted Distribution:' as Analysis,
    ISNULL(CAST(IsDeleted AS NVARCHAR(5)), 'NULL') as IsDeleted,
    COUNT(*) as RecordCount,
    CAST((COUNT(*) * 100.0 / @RowCount) AS DECIMAL(5,2)) as Percentage
FROM [dbo].[PushNotification]
GROUP BY IsDeleted

-- 3. CURRENT INDEX ANALYSIS
PRINT ''
PRINT '3. CURRENT INDEX ANALYSIS:'
PRINT '--------------------------'

SELECT 
    i.name AS IndexName,
    i.type_desc AS IndexType,
    i.fill_factor AS FillFactor,
    CASE WHEN i.is_unique = 1 THEN 'UNIQUE' ELSE 'NON-UNIQUE' END AS Uniqueness,
    ps.used_page_count * 8 / 1024 AS SizeMB,
    ps.row_count AS IndexRows,
    STUFF((SELECT ', ' + c.name
           FROM sys.index_columns ic
           INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
           WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
           ORDER BY ic.key_ordinal
           FOR XML PATH('')), 1, 2, '') AS KeyColumns,
    STUFF((SELECT ', ' + c.name
           FROM sys.index_columns ic
           INNER JOIN sys.columns c ON ic.object_id = c.object_id AND ic.column_id = c.column_id
           WHERE ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 1
           FOR XML PATH('')), 1, 2, '') AS IncludeColumns
FROM sys.indexes i
LEFT JOIN sys.dm_db_partition_stats ps ON i.object_id = ps.object_id AND i.index_id = ps.index_id
WHERE i.object_id = OBJECT_ID('dbo.PushNotification')
AND i.type > 0  -- Exclude heap
ORDER BY ps.used_page_count DESC

-- 4. INDEX USAGE STATISTICS (if available)
PRINT ''
PRINT '4. INDEX USAGE STATISTICS:'
PRINT '--------------------------'

SELECT 
    i.name AS IndexName,
    ISNULL(ius.user_seeks, 0) as UserSeeks,
    ISNULL(ius.user_scans, 0) as UserScans,
    ISNULL(ius.user_lookups, 0) as UserLookups,
    ISNULL(ius.user_updates, 0) as UserUpdates,
    ISNULL(ius.user_seeks + ius.user_scans + ius.user_lookups, 0) as TotalReads,
    CASE 
        WHEN ius.user_updates > 0 
        THEN CAST((ius.user_seeks + ius.user_scans + ius.user_lookups) AS DECIMAL(10,2)) / ius.user_updates
        ELSE NULL 
    END as ReadWriteRatio,
    ius.last_user_seek,
    ius.last_user_scan
FROM sys.indexes i
LEFT JOIN sys.dm_db_index_usage_stats ius
    ON i.object_id = ius.object_id AND i.index_id = ius.index_id
WHERE i.object_id = OBJECT_ID('dbo.PushNotification')
AND i.type > 0
ORDER BY ISNULL(ius.user_seeks + ius.user_scans + ius.user_lookups, 0) DESC

-- 5. INDEX FRAGMENTATION ANALYSIS
PRINT ''
PRINT '5. INDEX FRAGMENTATION ANALYSIS:'
PRINT '--------------------------------'

SELECT 
    i.name AS IndexName,
    ips.index_type_desc,
    ips.avg_fragmentation_in_percent,
    ips.page_count,
    CASE 
        WHEN ips.avg_fragmentation_in_percent > 30 THEN 'REBUILD REQUIRED'
        WHEN ips.avg_fragmentation_in_percent > 10 THEN 'REORGANIZE RECOMMENDED'
        ELSE 'OK'
    END AS ActionRecommended
FROM sys.dm_db_index_physical_stats(DB_ID(), OBJECT_ID('dbo.PushNotification'), NULL, NULL, 'SAMPLED') ips
JOIN sys.indexes i ON ips.object_id = i.object_id AND ips.index_id = i.index_id
WHERE ips.page_count > 100  -- Only check indexes with significant pages
ORDER BY ips.avg_fragmentation_in_percent DESC

-- 6. PERFORMANCE RECOMMENDATIONS
PRINT ''
PRINT '6. PERFORMANCE RECOMMENDATIONS:'
PRINT '-------------------------------'

-- Check for potential performance issues
IF @RowCount > 10000000
    PRINT '??  CRITICAL: Table has over 10M records. Consider:'
    PRINT '   � Table partitioning by CreatedDate'
    PRINT '   � Aggressive archiving strategy (6 months max)'
    PRINT '   � Read-only replicas for reporting'
ELSE IF @RowCount > 5000000
    PRINT '??  WARNING: Table has over 5M records. Consider:'
    PRINT '   � Monthly archiving of old data'
    PRINT '   � Monitoring query performance closely'
ELSE IF @RowCount > 1000000
    PRINT '??  INFO: Large table. Monitor performance regularly.'

-- Index overhead check
IF (@IndexSize_MB / @TableSize_MB) > 1.5
    PRINT '??  WARNING: Index size is ' + CAST((@IndexSize_MB / @TableSize_MB) * 100 AS NVARCHAR(10)) + '% of table size'
    PRINT '   � Consider removing unused indexes'
    PRINT '   � Review index include columns'
ELSE
    PRINT '? Index overhead is acceptable (' + CAST((@IndexSize_MB / @TableSize_MB) * 100 AS NVARCHAR(10)) + '%)'

-- Data age check
IF DATEDIFF(MONTH, @OldestDate, GETDATE()) > 12
    PRINT '??  WARNING: Table contains data older than 12 months'
    PRINT '   � Implement regular cleanup/archiving'
ELSE IF DATEDIFF(MONTH, @OldestDate, GETDATE()) > 6
    PRINT '??  INFO: Table contains data older than 6 months. Consider cleanup.'

-- Growth rate analysis
IF @AvgPerDay > 50000
    PRINT '??  WARNING: High growth rate (' + CAST(@AvgPerDay AS NVARCHAR(20)) + ' records/day)'
    PRINT '   � Plan for aggressive cleanup'
    PRINT '   � Consider real-time archiving'
ELSE IF @AvgPerDay > 10000
    PRINT '??  INFO: Moderate growth rate (' + CAST(@AvgPerDay AS NVARCHAR(20)) + ' records/day)'

PRINT ''
PRINT 'OPTIMAL INDEXING STRATEGY RECOMMENDATIONS:'
PRINT '----------------------------------------'

-- Calculate optimal number of indexes based on table characteristics
DECLARE @OptimalIndexCount INT
DECLARE @CurrentIndexCount INT

SELECT @CurrentIndexCount = COUNT(*) 
FROM sys.indexes 
WHERE object_id = OBJECT_ID('dbo.PushNotification') AND type > 0

-- Recommendation logic
IF @RowCount < 100000
    SET @OptimalIndexCount = 3
ELSE IF @RowCount < 1000000
    SET @OptimalIndexCount = 5
ELSE IF @RowCount < 5000000
    SET @OptimalIndexCount = 6
ELSE
    SET @OptimalIndexCount = 4  -- For very large tables, fewer indexes

PRINT 'Current Indexes: ' + CAST(@CurrentIndexCount AS NVARCHAR(10))
PRINT 'Recommended Indexes: ' + CAST(@OptimalIndexCount AS NVARCHAR(10))

IF @CurrentIndexCount > @OptimalIndexCount + 2
    PRINT '??  TOO MANY INDEXES: Consider consolidating or removing unused indexes'
ELSE IF @CurrentIndexCount < @OptimalIndexCount - 1
    PRINT '??  CONSIDER ADDING: Strategic indexes for common query patterns'
ELSE
    PRINT '? INDEX COUNT: Appears optimal for table size'

PRINT ''
PRINT 'SPECIFIC RECOMMENDATIONS:'
PRINT '� Use filtered indexes for columns with high NULL percentage'
PRINT '� Combine related columns in composite indexes'
PRINT '� Monitor index usage statistics monthly'
PRINT '� Set appropriate FILLFACTOR (80-85% for high INSERT/UPDATE tables)'
PRINT '� Consider columnstore indexes for analytics workloads'

PRINT ''
PRINT 'Analysis completed. Use this information to optimize your indexing strategy.'
GO