-- =============================================
-- Stored Procedure: Cleanup Old Records from Integration_ShiftDutyRoasterDetail
-- Purpose: Delete records older than specified months to maintain performance
-- Parameters: @RetentionMonths - Number of months to retain (default: 1)
-- Author: Database Optimization
-- Date: Created for automated cleanup
-- =============================================

USE [JointPortal_QA]
GO

-- Drop procedure if it exists
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup]
GO

CREATE PROCEDURE [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup]
    @RetentionMonths INT = 1,
    @BatchSize INT = 5000,
    @LogResults BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @StartTime DATETIME2 = GETDATE()
    DECLARE @CutoffDate DATETIME
    DECLARE @TotalRowsDeleted BIGINT = 0
    DECLARE @BatchRowsDeleted INT = 0
    DECLARE @LogMessage NVARCHAR(MAX)
    DECLARE @ErrorMessage NVARCHAR(MAX)
    
    BEGIN TRY
        -- Validate input parameters
        IF @RetentionMonths < 0 OR @RetentionMonths > 120
        BEGIN
            SET @ErrorMessage = 'Invalid @RetentionMonths parameter. Must be between 0 and 120.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        IF @BatchSize < 1 OR @BatchSize > 50000
        BEGIN
            SET @ErrorMessage = 'Invalid @BatchSize parameter. Must be between 1 and 50000.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        -- Calculate cutoff date (retain only records from last N months)
        SET @CutoffDate = DATEADD(MONTH, -@RetentionMonths, GETDATE())
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Starting cleanup of Integration_ShiftDutyRoasterDetail table. Cutoff date: ' + CONVERT(NVARCHAR(23), @CutoffDate, 121)
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Get initial count for reporting
        DECLARE @InitialCount BIGINT
        SELECT @InitialCount = COUNT(*) 
        FROM [dbo].[Integration_ShiftDutyRoasterDetail] 
        WHERE [CreatedDate] < @CutoffDate
        
        IF @InitialCount = 0
        BEGIN
            IF @LogResults = 1
                PRINT 'No records found older than cutoff date. Cleanup not required.'
            RETURN
        END
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Found ' + CAST(@InitialCount AS NVARCHAR(20)) + ' records to delete.'
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Delete in batches to avoid long-running transactions
        WHILE EXISTS (SELECT 1 FROM [dbo].[Integration_ShiftDutyRoasterDetail] WHERE [CreatedDate] < @CutoffDate)
        BEGIN
            BEGIN TRANSACTION
            
            DELETE TOP (@BatchSize)
            FROM [dbo].[Integration_ShiftDutyRoasterDetail]
            WHERE [CreatedDate] < @CutoffDate
            
            SET @BatchRowsDeleted = @@ROWCOUNT
            SET @TotalRowsDeleted = @TotalRowsDeleted + @BatchRowsDeleted
            
            COMMIT TRANSACTION
            
            IF @LogResults = 1 AND @BatchRowsDeleted > 0
            BEGIN
                SET @LogMessage = 'Deleted batch of ' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + ' records. Total deleted: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20))
                PRINT @LogMessage
                RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
            END
            
            -- Small delay between batches to reduce system load
            IF @BatchRowsDeleted > 0
                WAITFOR DELAY '00:00:02'
            ELSE
                BREAK -- No more records to delete
        END
        
        -- Log completion
        DECLARE @EndTime DATETIME2 = GETDATE()
        DECLARE @Duration INT = DATEDIFF(SECOND, @StartTime, @EndTime)
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Cleanup completed successfully. Total records deleted: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + 
                             '. Duration: ' + CAST(@Duration AS NVARCHAR(10)) + ' seconds.'
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Update table statistics after cleanup
        UPDATE STATISTICS [dbo].[Integration_ShiftDutyRoasterDetail]
        
        IF @LogResults = 1
            PRINT 'Table statistics updated.'
        
        -- Return summary information
        SELECT 
            @TotalRowsDeleted AS RecordsDeleted,
            @Duration AS DurationSeconds,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            GETDATE() AS CompletedAt
            
    END TRY
    BEGIN CATCH
        -- Rollback transaction if active
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION
        
        SET @ErrorMessage = 'Error during cleanup: ' + ERROR_MESSAGE() + 
                           ' (Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR(10)) + 
                           ', Line: ' + CAST(ERROR_LINE() AS NVARCHAR(10)) + ')'
        
        PRINT @ErrorMessage
        RAISERROR(@ErrorMessage, 16, 1)
        
        -- Log error to Windows Event Log (visible in SQL Server logs)
        DECLARE @ErrorDetails NVARCHAR(MAX) = 
            'Procedure: USP_Integration_ShiftDutyRoasterDetail_Cleanup' + CHAR(13) + CHAR(10) +
            'Retention Months: ' + CAST(@RetentionMonths AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Batch Size: ' + CAST(@BatchSize AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Cutoff Date: ' + ISNULL(CONVERT(NVARCHAR(23), @CutoffDate, 121), 'NULL') + CHAR(13) + CHAR(10) +
            'Records Deleted Before Error: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            'Error: ' + @ErrorMessage
        
        -- Write to SQL Server Error Log (viewable in SQL Server Management Studio)
        EXEC xp_logevent 50001, @ErrorDetails, 'ERROR'
        
        -- Return error information
        SELECT 
            @TotalRowsDeleted AS RecordsDeletedBeforeError,
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_MESSAGE() AS ErrorMessage,
            ERROR_LINE() AS ErrorLine,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            GETDATE() AS ErrorOccurredAt
        
    END CATCH
END
GO

-- Grant execute permissions (adjust as needed for your security model)
GRANT EXECUTE ON [dbo].[USP_Integration_ShiftDutyRoasterDetail_Cleanup] TO [public]
GO

PRINT 'Stored procedure USP_Integration_ShiftDutyRoasterDetail_Cleanup created successfully!'
GO