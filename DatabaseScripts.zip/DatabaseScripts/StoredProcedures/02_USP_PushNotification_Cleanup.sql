-- =============================================
-- Stored Procedure: Cleanup Old Records from PushNotification
-- Purpose: Delete records older than specified months to maintain performance
-- Parameters: @RetentionMonths - Number of months to retain (default: 3)
-- Author: Database Optimization
-- Date: Created for automated cleanup
-- =============================================

USE [JointPortal_QA]
GO

-- Drop procedure if it exists
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_PushNotification_Cleanup]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[USP_PushNotification_Cleanup]
GO

CREATE PROCEDURE [dbo].[USP_PushNotification_Cleanup]
    @RetentionMonths INT = 3,
    @BatchSize INT = 5000,
    @LogResults BIT = 1,
    @DeleteMarkedRecords BIT = 1,  -- Whether to delete records marked as IsDeleted = 1
    @ArchiveBeforeDelete BIT = 0,  -- Whether to archive before deleting
    @MaxExecutionMinutes INT = 30  -- Maximum execution time in minutes
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @StartTime DATETIME2 = GETDATE()
    DECLARE @CutoffDate DATETIME
    DECLARE @TotalRowsDeleted BIGINT = 0
    DECLARE @BatchRowsDeleted INT = 0
    DECLARE @MarkedDeletedRows BIGINT = 0
    DECLARE @ArchivedRows BIGINT = 0
    DECLARE @LogMessage NVARCHAR(MAX)
    DECLARE @ErrorMessage NVARCHAR(MAX)
    DECLARE @MaxEndTime DATETIME2
    
    BEGIN TRY
        -- Set maximum execution time
        SET @MaxEndTime = DATEADD(MINUTE, @MaxExecutionMinutes, @StartTime)
        
        -- Validate input parameters
        IF @RetentionMonths < 0 OR @RetentionMonths > 120
        BEGIN
            SET @ErrorMessage = 'Invalid @RetentionMonths parameter. Must be between 0 and 120.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        IF @BatchSize < 1 OR @BatchSize > 50000
        BEGIN
            SET @ErrorMessage = 'Invalid @BatchSize parameter. Must be between 1 and 50000.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        IF @MaxExecutionMinutes < 1 OR @MaxExecutionMinutes > 480
        BEGIN
            SET @ErrorMessage = 'Invalid @MaxExecutionMinutes parameter. Must be between 1 and 480 (8 hours).'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        -- Calculate cutoff date (retain only records from last N months)
        SET @CutoffDate = DATEADD(MONTH, -@RetentionMonths, GETDATE())
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Starting cleanup of PushNotification table. Cutoff date: ' + CONVERT(NVARCHAR(23), @CutoffDate, 121) + 
                             ' | Max execution time: ' + CAST(@MaxExecutionMinutes AS NVARCHAR(10)) + ' minutes'
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Create archive table if archiving is requested
        IF @ArchiveBeforeDelete = 1
        BEGIN
            IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'PushNotification_Archive')
            BEGIN
                IF @LogResults = 1
                BEGIN
                    PRINT 'Creating PushNotification_Archive table...'
                    RAISERROR('Creating PushNotification_Archive table...', 10, 1) WITH NOWAIT
                END
                
                SELECT TOP 0 * 
                INTO [dbo].[PushNotification_Archive]
                FROM [dbo].[PushNotification]
                
                -- Add archive-specific columns
                ALTER TABLE [dbo].[PushNotification_Archive] ADD [ArchivedDate] DATETIME2 DEFAULT GETDATE()
                ALTER TABLE [dbo].[PushNotification_Archive] ADD [ArchiveReason] NVARCHAR(100) DEFAULT 'Automated Cleanup'
                
                -- Create index on archive table
                CREATE CLUSTERED INDEX [IX_PushNotification_Archive_ArchivedDate] 
                ON [dbo].[PushNotification_Archive] ([ArchivedDate])
                
                IF @LogResults = 1
                    PRINT 'Archive table created successfully.'
            END
        END
        
        -- Phase 1: Archive and delete records marked as IsDeleted = 1 if requested
        IF @DeleteMarkedRecords = 1
        BEGIN
            IF @LogResults = 1
            BEGIN
                PRINT 'Phase 1: Processing records marked as IsDeleted = 1...'
                RAISERROR('Phase 1: Processing records marked as IsDeleted = 1...', 10, 1) WITH NOWAIT
            END
            
            -- Get count of marked deleted records
            DECLARE @MarkedRecordsCount BIGINT
            SELECT @MarkedRecordsCount = COUNT(*) FROM [dbo].[PushNotification] WHERE [IsDeleted] = 1
            
            IF @LogResults = 1 AND @MarkedRecordsCount > 0
            BEGIN
                SET @LogMessage = 'Found ' + CAST(@MarkedRecordsCount AS NVARCHAR(20)) + ' records marked for deletion.'
                PRINT @LogMessage
                RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
            END
            
            WHILE EXISTS (SELECT 1 FROM [dbo].[PushNotification] WHERE [IsDeleted] = 1) 
                  AND GETDATE() < @MaxEndTime
            BEGIN
                BEGIN TRANSACTION
                
                -- Archive if requested
                IF @ArchiveBeforeDelete = 1
                BEGIN
                    INSERT INTO [dbo].[PushNotification_Archive] (
                        [NotificationId], [NotificationHeader], [NotificationHeaderExternal],
                        [NotificationBodyEn], [NotificationBodyAr], [NotificationType],
                        [RedirectURL], [FromUserId], [ToUserIds], [ReadUserIds],
                        [CreatedDate], [ModuleId], [ModuleTypeId], [IsDeleted],
                        [ServiceType], [ExternalRequestJSON], [ArchiveReason]
                    )
                    SELECT TOP (@BatchSize)
                        [NotificationId], [NotificationHeader], [NotificationHeaderExternal],
                        [NotificationBodyEn], [NotificationBodyAr], [NotificationType],
                        [RedirectURL], [FromUserId], [ToUserIds], [ReadUserIds],
                        [CreatedDate], [ModuleId], [ModuleTypeId], [IsDeleted],
                        [ServiceType], [ExternalRequestJSON], 'Marked as Deleted'
                    FROM [dbo].[PushNotification]
                    WHERE [IsDeleted] = 1
                    
                    SET @ArchivedRows = @ArchivedRows + @@ROWCOUNT
                END
                
                -- Delete the records
                DELETE TOP (@BatchSize)
                FROM [dbo].[PushNotification]
                WHERE [IsDeleted] = 1
                
                SET @BatchRowsDeleted = @@ROWCOUNT
                SET @MarkedDeletedRows = @MarkedDeletedRows + @BatchRowsDeleted
                
                COMMIT TRANSACTION
                
                IF @LogResults = 1 AND @BatchRowsDeleted > 0
                BEGIN
                    SET @LogMessage = 'Processed batch of ' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + ' marked records. Total processed: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20))
                    IF @ArchiveBeforeDelete = 1
                        SET @LogMessage = @LogMessage + ' (Archived: ' + CAST(@ArchivedRows AS NVARCHAR(20)) + ')'
                    PRINT @LogMessage
                    RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
                END
                
                -- Small delay between batches
                IF @BatchRowsDeleted > 0
                    WAITFOR DELAY '00:00:01'
                ELSE
                    BREAK
                    
                -- Check execution time
                IF GETDATE() >= @MaxEndTime
                BEGIN
                    PRINT 'Phase 1: Maximum execution time reached. Stopping marked records cleanup.'
                    BREAK
                END
            END
            
            IF @LogResults = 1
            BEGIN
                SET @LogMessage = 'Phase 1 completed. Total marked records processed: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20))
                IF @ArchiveBeforeDelete = 1
                    SET @LogMessage = @LogMessage + ' (Archived: ' + CAST(@ArchivedRows AS NVARCHAR(20)) + ')'
                PRINT @LogMessage
                RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
            END
        END
        
        -- Phase 2: Process old records (age-based cleanup)
        IF GETDATE() < @MaxEndTime
        BEGIN
            DECLARE @InitialCount BIGINT
            SELECT @InitialCount = COUNT(*) 
            FROM [dbo].[PushNotification] 
            WHERE [CreatedDate] < @CutoffDate
              AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)  -- Only count active records
            
            IF @InitialCount = 0
            BEGIN
                IF @LogResults = 1
                    PRINT 'Phase 2: No old active records found. Age-based cleanup not required.'
            END
            ELSE
            BEGIN
                IF @LogResults = 1
                BEGIN
                    SET @LogMessage = 'Phase 2: Found ' + CAST(@InitialCount AS NVARCHAR(20)) + ' old active records to process.'
                    PRINT @LogMessage
                    RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
                END
                
                -- Process old records in batches
                WHILE EXISTS (
                    SELECT 1 FROM [dbo].[PushNotification] 
                    WHERE [CreatedDate] < @CutoffDate
                      AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
                ) AND GETDATE() < @MaxEndTime
                BEGIN
                    BEGIN TRANSACTION
                    
                    -- Archive if requested
                    IF @ArchiveBeforeDelete = 1
                    BEGIN
                        INSERT INTO [dbo].[PushNotification_Archive] (
                            [NotificationId], [NotificationHeader], [NotificationHeaderExternal],
                            [NotificationBodyEn], [NotificationBodyAr], [NotificationType],
                            [RedirectURL], [FromUserId], [ToUserIds], [ReadUserIds],
                            [CreatedDate], [ModuleId], [ModuleTypeId], [IsDeleted],
                            [ServiceType], [ExternalRequestJSON], [ArchiveReason]
                        )
                        SELECT TOP (@BatchSize)
                            [NotificationId], [NotificationHeader], [NotificationHeaderExternal],
                            [NotificationBodyEn], [NotificationBodyAr], [NotificationType],
                            [RedirectURL], [FromUserId], [ToUserIds], [ReadUserIds],
                            [CreatedDate], [ModuleId], [ModuleTypeId], [IsDeleted],
                            [ServiceType], [ExternalRequestJSON], 
                            'Age-based cleanup (' + CAST(@RetentionMonths AS NVARCHAR(10)) + ' months retention)'
                        FROM [dbo].[PushNotification]
                        WHERE [CreatedDate] < @CutoffDate
                          AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
                    END
                    
                    -- Delete the old records
                    DELETE TOP (@BatchSize)
                    FROM [dbo].[PushNotification]
                    WHERE [CreatedDate] < @CutoffDate
                      AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
                    
                    SET @BatchRowsDeleted = @@ROWCOUNT
                    SET @TotalRowsDeleted = @TotalRowsDeleted + @BatchRowsDeleted
                    
                    COMMIT TRANSACTION
                    
                    IF @LogResults = 1 AND @BatchRowsDeleted > 0
                    BEGIN
                        SET @LogMessage = 'Processed batch of ' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + ' old records. Total processed: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20))
                        PRINT @LogMessage
                        RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
                    END
                    
                    -- Small delay between batches
                    IF @BatchRowsDeleted > 0
                        WAITFOR DELAY '00:00:02'
                    ELSE
                        BREAK
                        
                    -- Check execution time
                    IF GETDATE() >= @MaxEndTime
                    BEGIN
                        PRINT 'Phase 2: Maximum execution time reached. Stopping age-based cleanup.'
                        BREAK
                    END
                END
            END
        END
        ELSE
        BEGIN
            IF @LogResults = 1
                PRINT 'Phase 2: Skipped due to maximum execution time reached in Phase 1.'
        END
        
        -- Log completion
        DECLARE @EndTime DATETIME2 = GETDATE()
        DECLARE @Duration INT = DATEDIFF(SECOND, @StartTime, @EndTime)
        DECLARE @TotalDeleted BIGINT = @TotalRowsDeleted + @MarkedDeletedRows
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Cleanup completed. ' +
                             'Marked records processed: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20)) + 
                             ', Old records processed: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + 
                             ', Total processed: ' + CAST(@TotalDeleted AS NVARCHAR(20))
            IF @ArchiveBeforeDelete = 1
                SET @LogMessage = @LogMessage + ', Total archived: ' + CAST(@ArchivedRows AS NVARCHAR(20))
            SET @LogMessage = @LogMessage + '. Duration: ' + CAST(@Duration AS NVARCHAR(10)) + ' seconds.'
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Update table statistics after cleanup
        IF @TotalDeleted > 0
        BEGIN
            UPDATE STATISTICS [dbo].[PushNotification] WITH FULLSCAN
            
            IF @LogResults = 1
                PRINT 'Table statistics updated.'
        END
        
        -- Return summary information
        SELECT 
            @MarkedDeletedRows AS MarkedRecordsDeleted,
            @TotalRowsDeleted AS OldRecordsDeleted,
            @TotalDeleted AS TotalRecordsDeleted,
            @ArchivedRows AS TotalRecordsArchived,
            @Duration AS DurationSeconds,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            @DeleteMarkedRecords AS DeletedMarkedRecords,
            @ArchiveBeforeDelete AS ArchivedBeforeDelete,
            CASE WHEN GETDATE() >= @MaxEndTime THEN 'Stopped due to time limit' ELSE 'Completed normally' END AS CompletionStatus,
            GETDATE() AS CompletedAt
            
    END TRY
    BEGIN CATCH
        -- Rollback transaction if active
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION
        
        SET @ErrorMessage = 'Error during cleanup: ' + ERROR_MESSAGE() + 
                           ' (Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR(10)) + 
                           ', Line: ' + CAST(ERROR_LINE() AS NVARCHAR(10)) + ')'
        
        PRINT @ErrorMessage
        RAISERROR(@ErrorMessage, 16, 1)
        
        -- Log error details for troubleshooting
        DECLARE @ErrorDetails NVARCHAR(MAX) = 
            'Procedure: USP_PushNotification_Cleanup' + CHAR(13) + CHAR(10) +
            'Retention Months: ' + CAST(@RetentionMonths AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Batch Size: ' + CAST(@BatchSize AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Delete Marked Records: ' + CAST(@DeleteMarkedRecords AS NVARCHAR(5)) + CHAR(13) + CHAR(10) +
            'Archive Before Delete: ' + CAST(@ArchiveBeforeDelete AS NVARCHAR(5)) + CHAR(13) + CHAR(10) +
            'Max Execution Minutes: ' + CAST(@MaxExecutionMinutes AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Cutoff Date: ' + ISNULL(CONVERT(NVARCHAR(23), @CutoffDate, 121), 'NULL') + CHAR(13) + CHAR(10) +
            'Marked Records Processed: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            'Old Records Processed Before Error: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            'Records Archived: ' + CAST(@ArchivedRows AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            'Error: ' + @ErrorMessage
        
        -- Write to SQL Server Error Log
        EXEC xp_logevent 50002, @ErrorDetails, 'ERROR'
        
        -- Return error information
        SELECT 
            @MarkedDeletedRows AS MarkedRecordsDeletedBeforeError,
            @TotalRowsDeleted AS OldRecordsDeletedBeforeError,
            (@MarkedDeletedRows + @TotalRowsDeleted) AS TotalDeletedBeforeError,
            @ArchivedRows AS RecordsArchivedBeforeError,
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_MESSAGE() AS ErrorMessage,
            ERROR_LINE() AS ErrorLine,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            GETDATE() AS ErrorOccurredAt
        
    END CATCH
END
GO

-- Grant execute permissions (adjust as needed for your security model)
GRANT EXECUTE ON [dbo].[USP_PushNotification_Cleanup] TO [public]
GO

PRINT 'Stored procedure USP_PushNotification_Cleanup created successfully!'
PRINT ''
PRINT 'USAGE EXAMPLES:'
PRINT '==============='
PRINT '-- Basic cleanup (3 months retention, delete marked records):'
PRINT 'EXEC [dbo].[USP_PushNotification_Cleanup]'
PRINT ''
PRINT '-- Keep 6 months of data:'
PRINT 'EXEC [dbo].[USP_PushNotification_Cleanup] @RetentionMonths = 6'
PRINT ''
PRINT '-- Archive before deleting:'
PRINT 'EXEC [dbo].[USP_PushNotification_Cleanup] @ArchiveBeforeDelete = 1'
PRINT ''
PRINT '-- Skip marked deleted records cleanup:'
PRINT 'EXEC [dbo].[USP_PushNotification_Cleanup] @DeleteMarkedRecords = 0'
PRINT ''
PRINT '-- Custom batch size and time limit:'
PRINT 'EXEC [dbo].[USP_PushNotification_Cleanup] @BatchSize = 2000, @MaxExecutionMinutes = 60'
PRINT ''
PRINT '-- Full archival cleanup with 12 months retention:'
PRINT 'EXEC [dbo].[USP_PushNotification_Cleanup] @RetentionMonths = 12, @ArchiveBeforeDelete = 1, @MaxExecutionMinutes = 120'
GO