-- =============================================
-- Stored Procedure: Cleanup Old Records from TarasulNotification
-- Purpose: Delete records older than specified months to maintain performance
-- Parameters: @RetentionMonths - Number of months to retain (default: 1)
-- Author: Database Optimization
-- Date: Created for automated cleanup
-- =============================================

USE [JointPortal_QA]
GO

-- Drop procedure if it exists
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[USP_TarasulNotification_Cleanup]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[USP_TarasulNotification_Cleanup]
GO

CREATE PROCEDURE [dbo].[USP_TarasulNotification_Cleanup]
    @RetentionMonths INT = 1,
    @BatchSize INT = 5000,
    @LogResults BIT = 1,
    @DeleteMarkedRecords BIT = 1  -- Whether to delete records marked as IsDeleted = 1
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @StartTime DATETIME2 = GETDATE()
    DECLARE @CutoffDate DATETIME
    DECLARE @TotalRowsDeleted BIGINT = 0
    DECLARE @BatchRowsDeleted INT = 0
    DECLARE @MarkedDeletedRows BIGINT = 0
    DECLARE @LogMessage NVARCHAR(MAX)
    DECLARE @ErrorMessage NVARCHAR(MAX)
    
    BEGIN TRY
        -- Validate input parameters
        IF @RetentionMonths < 0 OR @RetentionMonths > 120
        BEGIN
            SET @ErrorMessage = 'Invalid @RetentionMonths parameter. Must be between 0 and 120.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        IF @BatchSize < 1 OR @BatchSize > 50000
        BEGIN
            SET @ErrorMessage = 'Invalid @BatchSize parameter. Must be between 1 and 50000.'
            RAISERROR(@ErrorMessage, 16, 1)
            RETURN
        END
        
        -- Calculate cutoff date (retain only records from last N months)
        SET @CutoffDate = DATEADD(MONTH, -@RetentionMonths, GETDATE())
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Starting cleanup of TarasulNotification table. Cutoff date: ' + CONVERT(NVARCHAR(23), @CutoffDate, 121)
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Phase 1: Delete records marked as IsDeleted = 1 if requested
        IF @DeleteMarkedRecords = 1
        BEGIN
            IF @LogResults = 1
            BEGIN
                PRINT 'Phase 1: Deleting records marked as IsDeleted = 1...'
                RAISERROR('Phase 1: Deleting records marked as IsDeleted = 1...', 10, 1) WITH NOWAIT
            END
            
            -- Get count of marked deleted records
            DECLARE @MarkedRecordsCount BIGINT
            SELECT @MarkedRecordsCount = COUNT(*) FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 1
            
            IF @LogResults = 1 AND @MarkedRecordsCount > 0
            BEGIN
                SET @LogMessage = 'Found ' + CAST(@MarkedRecordsCount AS NVARCHAR(20)) + ' records marked for deletion.'
                PRINT @LogMessage
                RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
            END
            
            WHILE EXISTS (SELECT 1 FROM [dbo].[TarasulNotification] WHERE [IsDeleted] = 1)
            BEGIN
                BEGIN TRANSACTION
                
                DELETE TOP (@BatchSize)
                FROM [dbo].[TarasulNotification]
                WHERE [IsDeleted] = 1
                
                SET @BatchRowsDeleted = @@ROWCOUNT
                SET @MarkedDeletedRows = @MarkedDeletedRows + @BatchRowsDeleted
                
                COMMIT TRANSACTION
                
                IF @LogResults = 1 AND @BatchRowsDeleted > 0
                BEGIN
                    SET @LogMessage = 'Deleted batch of ' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + ' marked records. Total marked deleted: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20))
                    PRINT @LogMessage
                    RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
                END
                
                -- Small delay between batches
                IF @BatchRowsDeleted > 0
                    WAITFOR DELAY '00:00:01'
                ELSE
                    BREAK
            END
            
            IF @LogResults = 1
            BEGIN
                SET @LogMessage = 'Phase 1 completed. Total marked records deleted: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20))
                PRINT @LogMessage
                RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
            END
        END
        
        -- Phase 2: Get count of old records for reporting
        DECLARE @InitialCount BIGINT
        SELECT @InitialCount = COUNT(*) 
        FROM [dbo].[TarasulNotification] 
        WHERE [CreatedDate] < @CutoffDate
          AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)  -- Only count active records
        
        IF @InitialCount = 0
        BEGIN
            IF @LogResults = 1
                PRINT 'Phase 2: No old active records found. Age-based cleanup not required.'
        END
        ELSE
        BEGIN
            IF @LogResults = 1
            BEGIN
                SET @LogMessage = 'Phase 2: Found ' + CAST(@InitialCount AS NVARCHAR(20)) + ' old active records to delete.'
                PRINT @LogMessage
                RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
            END
            
            -- Delete old records in batches
            WHILE EXISTS (
                SELECT 1 FROM [dbo].[TarasulNotification] 
                WHERE [CreatedDate] < @CutoffDate
                  AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
            )
            BEGIN
                BEGIN TRANSACTION
                
                DELETE TOP (@BatchSize)
                FROM [dbo].[TarasulNotification]
                WHERE [CreatedDate] < @CutoffDate
                  AND ([IsDeleted] = 0 OR [IsDeleted] IS NULL)
                
                SET @BatchRowsDeleted = @@ROWCOUNT
                SET @TotalRowsDeleted = @TotalRowsDeleted + @BatchRowsDeleted
                
                COMMIT TRANSACTION
                
                IF @LogResults = 1 AND @BatchRowsDeleted > 0
                BEGIN
                    SET @LogMessage = 'Deleted batch of ' + CAST(@BatchRowsDeleted AS NVARCHAR(10)) + ' old records. Total old deleted: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20))
                    PRINT @LogMessage
                    RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
                END
                
                -- Small delay between batches
                IF @BatchRowsDeleted > 0
                    WAITFOR DELAY '00:00:02'
                ELSE
                    BREAK
            END
        END
        
        -- Log completion
        DECLARE @EndTime DATETIME2 = GETDATE()
        DECLARE @Duration INT = DATEDIFF(SECOND, @StartTime, @EndTime)
        DECLARE @TotalDeleted BIGINT = @TotalRowsDeleted + @MarkedDeletedRows
        
        IF @LogResults = 1
        BEGIN
            SET @LogMessage = 'Cleanup completed successfully. ' +
                             'Marked records deleted: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20)) + 
                             ', Old records deleted: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + 
                             ', Total deleted: ' + CAST(@TotalDeleted AS NVARCHAR(20)) +
                             '. Duration: ' + CAST(@Duration AS NVARCHAR(10)) + ' seconds.'
            PRINT @LogMessage
            RAISERROR(@LogMessage, 10, 1) WITH NOWAIT
        END
        
        -- Update table statistics after cleanup
        UPDATE STATISTICS [dbo].[TarasulNotification]
        
        IF @LogResults = 1
            PRINT 'Table statistics updated.'
        
        -- Return summary information
        SELECT 
            @MarkedDeletedRows AS MarkedRecordsDeleted,
            @TotalRowsDeleted AS OldRecordsDeleted,
            @TotalDeleted AS TotalRecordsDeleted,
            @Duration AS DurationSeconds,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            @DeleteMarkedRecords AS DeletedMarkedRecords,
            GETDATE() AS CompletedAt
            
    END TRY
    BEGIN CATCH
        -- Rollback transaction if active
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION
        
        SET @ErrorMessage = 'Error during cleanup: ' + ERROR_MESSAGE() + 
                           ' (Error Number: ' + CAST(ERROR_NUMBER() AS NVARCHAR(10)) + 
                           ', Line: ' + CAST(ERROR_LINE() AS NVARCHAR(10)) + ')'
        
        PRINT @ErrorMessage
        RAISERROR(@ErrorMessage, 16, 1)
        
        -- Log error to Windows Event Log (visible in SQL Server logs)
        DECLARE @ErrorDetails NVARCHAR(MAX) = 
            'Procedure: USP_TarasulNotification_Cleanup' + CHAR(13) + CHAR(10) +
            'Retention Months: ' + CAST(@RetentionMonths AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Batch Size: ' + CAST(@BatchSize AS NVARCHAR(10)) + CHAR(13) + CHAR(10) +
            'Delete Marked Records: ' + CAST(@DeleteMarkedRecords AS NVARCHAR(5)) + CHAR(13) + CHAR(10) +
            'Cutoff Date: ' + ISNULL(CONVERT(NVARCHAR(23), @CutoffDate, 121), 'NULL') + CHAR(13) + CHAR(10) +
            'Marked Records Deleted: ' + CAST(@MarkedDeletedRows AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            'Old Records Deleted Before Error: ' + CAST(@TotalRowsDeleted AS NVARCHAR(20)) + CHAR(13) + CHAR(10) +
            'Error: ' + @ErrorMessage
        
        -- Write to SQL Server Error Log (viewable in SQL Server Management Studio)
        EXEC xp_logevent 50001, @ErrorDetails, 'ERROR'
        
        -- Return error information
        SELECT 
            @MarkedDeletedRows AS MarkedRecordsDeletedBeforeError,
            @TotalRowsDeleted AS OldRecordsDeletedBeforeError,
            (@MarkedDeletedRows + @TotalRowsDeleted) AS TotalDeletedBeforeError,
            ERROR_NUMBER() AS ErrorNumber,
            ERROR_MESSAGE() AS ErrorMessage,
            ERROR_LINE() AS ErrorLine,
            @CutoffDate AS CutoffDate,
            @RetentionMonths AS RetentionMonths,
            GETDATE() AS ErrorOccurredAt
        
    END CATCH
END
GO

-- Grant execute permissions (adjust as needed for your security model)
GRANT EXECUTE ON [dbo].[USP_TarasulNotification_Cleanup] TO [public]
GO

PRINT 'Stored procedure USP_TarasulNotification_Cleanup created successfully!'
PRINT ''
PRINT 'USAGE EXAMPLES:'
PRINT '==============='
PRINT '-- Basic cleanup (1 month retention, delete marked records):'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup]'
PRINT ''
PRINT '-- Keep 2 months of data:'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup] @RetentionMonths = 2'
PRINT ''
PRINT '-- Skip marked deleted records cleanup:'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup] @DeleteMarkedRecords = 0'
PRINT ''
PRINT '-- Custom batch size for high-load systems:'
PRINT 'EXEC [dbo].[USP_TarasulNotification_Cleanup] @BatchSize = 2000'
GO