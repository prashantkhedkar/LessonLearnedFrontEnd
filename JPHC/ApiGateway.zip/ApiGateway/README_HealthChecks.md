# API Gateway Health Checks

This API Gateway now includes comprehensive health checks for all downstream microservices with both built-in .NET health checks and custom status monitoring.

## Health Check Endpoints

### Built-in Health Check Endpoints

#### 1. Main Health Check Endpoint
- **URL**: `http://localhost:5551/health`
- **Method**: GET
- **Description**: Returns detailed health status using .NET built-in health checks

#### 2. Ready Check
- **URL**: `http://localhost:5551/health/ready`
- **Method**: GET
- **Description**: Returns health status for services marked as 'ready'

#### 3. Live Check
- **URL**: `http://localhost:5551/health/live`
- **Method**: GET
- **Description**: Returns health status for all services (liveness probe)

### Custom Health API Endpoints

#### 4. Health Summary
- **URL**: `http://localhost:5551/api/health/summary`
- **Method**: GET
- **Description**: Returns a summary of all services health status

#### 5. Health Services List
- **URL**: `http://localhost:5551/api/health/services`
- **Method**: GET
- **Description**: Returns detailed health information for all services

#### 6. Detailed Health Information
- **URL**: `http://localhost:5551/api/health`
- **Method**: GET
- **Description**: Returns detailed health information including response times and error details

### Status API Endpoints (Recommended for detailed monitoring)

#### 7. All Services Status
- **URL**: `http://localhost:5551/api/status/all`
- **Method**: GET
- **Description**: Returns comprehensive status of all services with response times and detailed information

#### 8. Service List
- **URL**: `http://localhost:5551/api/status/services`
- **Method**: GET
- **Description**: Returns list of all monitored services with their URLs and ports

#### 9. Ping Specific Service
- **URL**: `http://localhost:5551/api/status/ping/{serviceName}`
- **Method**: GET
- **Description**: Ping a specific service by name (e.g., `/api/status/ping/AuthenticationApiService`)

### Dashboard

#### 10. Health Dashboard UI
- **URL**: `http://localhost:5551/health-ui` or `http://localhost:5551/health-dashboard.html`
- **Description**: Interactive web dashboard showing health status of all services with auto-refresh

## Monitored Services

The following downstream services are being monitored:

| Service | Port | Health Check URL | Tags |
|---------|------|------------------|------|
| Authentication API Service | 5209 | http://localhost:5209/health | api, authentication |
| Project API Service | 5059 | http://localhost:5059/health | api, project |
| Watira API Service | 5010 | http://localhost:5010/health | api, watira |
| Meeting Calendar API Service | 5015 | http://localhost:5015/health | api, meeting |
| HR Admin API Service | 5002 | http://localhost:5002/health | api, hr |
| Announcement API Service | 5136 | http://localhost:5136/health | api, announcement |
| Integration API Service | 5005 | http://localhost:5005/health | api, integration |
| Notification API Service | 5100 | http://localhost:5100/health | api, notification |
| Department Website API Service | 5075 | http://localhost:5075/health | api, department |
| Survey API Service | 5006 | http://localhost:5006/health | api, survey |

## Health Check Configuration

- **Request Timeout**: 10 seconds per service
- **Dashboard Auto-refresh**: 30 seconds

## Health Status Codes

- **200 OK**: All services are healthy
- **503 Service Unavailable**: One or more services are unhealthy

## Response Format Examples

### Status API Response (`/api/status/all`)
```json
{
  "totalServices": 10,
  "healthyServices": 8,
  "unhealthyServices": 2,
  "checkedAt": "2024-01-15T10:30:00.000Z",
  "services": [
    {
      "serviceName": "AuthenticationApiService",
      "url": "http://localhost:5209/health",
      "statusCode": 200,
      "isHealthy": true,
      "responseTime": 123,
      "status": "Healthy"
    },
    {
      "serviceName": "ProjectApiService",
      "url": "http://localhost:5059/health",
      "statusCode": 0,
      "isHealthy": false,
      "responseTime": 0,
      "status": "Unreachable",
      "error": "Connection refused"
    }
  ]
}
```

### Built-in Health Check Response (`/health`)
```json
{
  "Status": "Healthy",
  "Duration": "00:00:02.1234567",
  "Info": [
    {
      "Key": "AuthenticationApiService",
      "Description": "Service at http://localhost:5209/health is healthy",
      "Status": "Healthy",
      "Duration": "00:00:00.1234567"
    }
  ]
}
```

### Health Summary Response (`/api/health/summary`)
```json
{
  "status": "Healthy",
  "totalServices": 10,
  "healthyServices": 9,
  "unhealthyServices": 1,
  "degradedServices": 0,
  "totalDuration": 2123.4567,
  "checkedAt": "2024-01-15T10:30:00.000Z",
  "services": [
    {
      "name": "AuthenticationApiService",
      "status": "Healthy",
      "tags": ["api", "authentication"]
    }
  ]
}
```

## Available Service Names for Ping API

Use these exact names with the ping API (`/api/status/ping/{serviceName}`):
- `AuthenticationApiService`
- `ProjectApiService`
- `WatiraApiService`
- `MeetingCalendarApiService`
- `HRAdminApiService`
- `AnnouncementApiService`
- `IntegrationApiService`
- `NotificationApiService`
- `DepartmentWebsiteApiService`
- `SurveyApiService`

## Features

### Web Dashboard
- Real-time health status visualization
- Auto-refresh every 30 seconds
- Color-coded status indicators (Green: Healthy, Red: Unhealthy/Unreachable)
- Response time monitoring
- Service categorization and detailed error information

### API Endpoints
- RESTful API for programmatic access
- JSON responses with detailed information
- Support for different health check types (live, ready)
- Custom status API with detailed service information

## Prerequisites for Downstream Services

Each downstream service should implement a `/health` endpoint that returns:
- **200 OK** when the service is healthy
- **503 Service Unavailable** when the service is unhealthy

Example minimal health endpoint implementation:
```csharp
app.MapHealthChecks("/health");
```

## Usage Examples

### Check All Services
```bash
curl http://localhost:5551/api/status/all
```

### Check Specific Service
```bash
curl http://localhost:5551/api/status/ping/AuthenticationApiService
```

### View Dashboard
Navigate to: `http://localhost:5551/health-ui`

### Built-in Health Check
```bash
curl http://localhost:5551/health
```

## Monitoring Integration

The health check endpoints can be integrated with monitoring systems:
- Use `/health` for Kubernetes health probes
- Use `/api/status/all` for detailed monitoring dashboards
- Use `/health-ui` for human-readable status page

## Troubleshooting

- If a service shows as unhealthy, check if the service is running and accessible
- Verify that each downstream service has implemented a `/health` endpoint
- Check network connectivity between the API Gateway and downstream services
- Use the ping API to test individual services: `/api/status/ping/{serviceName}`
- Review the dashboard for detailed error messages and response times

## Docker/Container Support

If running in containers, update the service URLs in both:
1. `Program.cs` health check configuration
2. `StatusController.cs` service URLs dictionary

Replace `localhost` with appropriate container names or networking addresses.