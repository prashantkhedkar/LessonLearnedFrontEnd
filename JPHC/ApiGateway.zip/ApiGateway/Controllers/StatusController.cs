using Microsoft.AspNetCore.Mvc;

namespace ApiGateway.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatusController : ControllerBase
    {
        private static readonly Dictionary<string, string> ServiceUrls = new()
        {
            { "AuthenticationApiService", "http://localhost:5209/health" },
            { "ProjectApiService", "http://localhost:5059/health" },
            { "WatiraApiService", "http://localhost:5010/health" },
            { "MeetingCalendarApiService", "http://localhost:5015/health" },
            { "HRAdminApiService", "http://localhost:5002/health" },
            { "AnnouncementApiService", "http://localhost:5136/health" },
            { "IntegrationApiService", "http://localhost:5005/health" },
            { "NotificationApiService", "http://localhost:5100/health" },
            { "DepartmentWebsiteApiService", "http://localhost:5075/health" },
            { "SurveyApiService", "http://localhost:5006/health" }
        };

        private static readonly Dictionary<string, string> ExternalApiUrls = new()
        {
            { "MawjoodAPI", "http://localhost:5005/api/ExternalHealth/mawjood" },
            { "TarasulAPI", "http://localhost:5005/api/ExternalHealth/tarasul" },
            { "MawardAPI", "http://localhost:5005/api/ExternalHealth/maward" }
        };

        [HttpGet("services")]
        public IActionResult GetServices()
        {
            var services = ServiceUrls.Select(kvp => new
            {
                Name = kvp.Key,
                Url = kvp.Value,
                Port = ExtractPort(kvp.Value),
                Type = "Microservice"
            });

            return Ok(services);
        }

        [HttpGet("external-apis")]
        public IActionResult GetExternalApis()
        {
            var externalApis = ExternalApiUrls.Select(kvp => new
            {
                Name = kvp.Key,
                Url = kvp.Value,
                Type = "ExternalAPI"
            });

            return Ok(externalApis);
        }

        [HttpGet("ping/{serviceName}")]
        public async Task<IActionResult> PingService(string serviceName)
        {
            if (!ServiceUrls.TryGetValue(serviceName, out string? serviceUrl))
            {
                return NotFound($"Service '{serviceName}' not found");
            }

            try
            {
                using var client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(10);
                
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                var response = await client.GetAsync(serviceUrl);
                stopwatch.Stop();

                var result = new
                {
                    ServiceName = serviceName,
                    Url = serviceUrl,
                    StatusCode = (int)response.StatusCode,
                    IsHealthy = response.IsSuccessStatusCode,
                    ResponseTime = stopwatch.ElapsedMilliseconds,
                    CheckedAt = DateTime.UtcNow,
                    Type = "Microservice"
                };

                return response.IsSuccessStatusCode ? Ok(result) : StatusCode(503, result);
            }
            catch (Exception ex)
            {
                var result = new
                {
                    ServiceName = serviceName,
                    Url = serviceUrl,
                    IsHealthy = false,
                    Error = ex.Message,
                    CheckedAt = DateTime.UtcNow,
                    Type = "Microservice"
                };

                return StatusCode(503, result);
            }
        }

        [HttpGet("ping-external/{apiName}")]
        public async Task<IActionResult> PingExternalApi(string apiName)
        {
            if (!ExternalApiUrls.TryGetValue(apiName, out string? apiUrl))
            {
                return NotFound($"External API '{apiName}' not found");
            }

            try
            {
                using var client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(30);
                
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                var response = await client.GetAsync(apiUrl);
                stopwatch.Stop();

                var content = await response.Content.ReadAsStringAsync();
                
                var result = new
                {
                    ApiName = apiName,
                    Url = apiUrl,
                    StatusCode = (int)response.StatusCode,
                    IsHealthy = response.IsSuccessStatusCode,
                    ResponseTime = stopwatch.ElapsedMilliseconds,
                    CheckedAt = DateTime.UtcNow,
                    Type = "ExternalAPI",
                    Details = response.IsSuccessStatusCode ? System.Text.Json.JsonSerializer.Deserialize<object>(content) : content
                };

                return response.IsSuccessStatusCode ? Ok(result) : StatusCode(503, result);
            }
            catch (Exception ex)
            {
                var result = new
                {
                    ApiName = apiName,
                    Url = apiUrl,
                    IsHealthy = false,
                    Error = ex.Message,
                    CheckedAt = DateTime.UtcNow,
                    Type = "ExternalAPI"
                };

                return StatusCode(503, result);
            }
        }

        [HttpGet("all")]
        public async Task<IActionResult> CheckAllServices()
        {
            var tasks = new List<Task<object>>();
            
            // Add microservices checks
            foreach (var kvp in ServiceUrls)
            {
                tasks.Add(CheckServiceAsync(kvp.Key, kvp.Value, "Microservice"));
            }

            var results = await Task.WhenAll(tasks);
            
            var summary = new
            {
                TotalServices = results.Length,
                HealthyServices = results.Count(r => ((dynamic)r).IsHealthy == true),
                UnhealthyServices = results.Count(r => ((dynamic)r).IsHealthy == false),
                CheckedAt = DateTime.UtcNow,
                Services = results
            };

            var allHealthy = results.All(r => ((dynamic)r).IsHealthy == true);
            return allHealthy ? Ok(summary) : StatusCode(503, summary);
        }

        [HttpGet("all-with-external")]
        public async Task<IActionResult> CheckAllServicesAndExternalApis()
        {
            var tasks = new List<Task<object>>();
            
            // Add microservices checks
            foreach (var kvp in ServiceUrls)
            {
                tasks.Add(CheckServiceAsync(kvp.Key, kvp.Value, "Microservice"));
            }

            // Add external API checks
            foreach (var kvp in ExternalApiUrls)
            {
                tasks.Add(CheckExternalApiAsync(kvp.Key, kvp.Value));
            }

            var results = await Task.WhenAll(tasks);
            
            var microservices = results.Where(r => ((dynamic)r).Type == "Microservice").ToArray();
            var externalApis = results.Where(r => ((dynamic)r).Type == "ExternalAPI").ToArray();
            
            var summary = new
            {
                TotalServices = microservices.Length,
                HealthyServices = microservices.Count(r => ((dynamic)r).IsHealthy == true),
                UnhealthyServices = microservices.Count(r => ((dynamic)r).IsHealthy == false),
                TotalExternalApis = externalApis.Length,
                HealthyExternalApis = externalApis.Count(r => ((dynamic)r).IsHealthy == true),
                UnhealthyExternalApis = externalApis.Count(r => ((dynamic)r).IsHealthy == false),
                CheckedAt = DateTime.UtcNow,
                Microservices = microservices,
                ExternalAPIs = externalApis
            };

            var allHealthy = results.All(r => ((dynamic)r).IsHealthy == true);
            return allHealthy ? Ok(summary) : StatusCode(503, summary);
        }

        [HttpGet("external-only")]
        public async Task<IActionResult> CheckExternalApisOnly()
        {
            try
            {
                using var client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(30);
                
                // First try the IntegrationApiService endpoint
                try
                {
                    var response = await client.GetAsync("http://localhost:5005/api/ExternalHealth/all-external");
                    var content = await response.Content.ReadAsStringAsync();
                    
                    if (response.IsSuccessStatusCode)
                    {
                        var externalApiStatus = System.Text.Json.JsonSerializer.Deserialize<object>(content);
                        return Ok(externalApiStatus);
                    }
                }
                catch (Exception ex)
                {
                    // If IntegrationApiService is not available, fall back to individual checks
                    Console.WriteLine($"IntegrationApiService not available: {ex.Message}");
                }
                
                // Fallback: Check external APIs individually
                var tasks = new List<Task<object>>();
                foreach (var kvp in ExternalApiUrls)
                {
                    tasks.Add(CheckExternalApiAsync(kvp.Key, kvp.Value));
                }

                var results = await Task.WhenAll(tasks);
                
                var healthyCount = results.Count(r => ((dynamic)r).IsHealthy == true);
                var totalCount = results.Length;
                
                var fallbackResponse = new
                {
                    TotalAPIs = totalCount,
                    HealthyAPIs = healthyCount,
                    UnhealthyAPIs = totalCount - healthyCount,
                    HealthPercentage = totalCount > 0 ? (healthyCount * 100.0 / totalCount) : 0,
                    CheckedAt = DateTime.UtcNow,
                    APIs = results.Select(r => new
                    {
                        ApiName = ((dynamic)r).ServiceName,
                        IsHealthy = ((dynamic)r).IsHealthy,
                        StatusCode = ((dynamic)r).StatusCode,
                        ResponseTime = ((dynamic)r).ResponseTime,
                        Url = ((dynamic)r).Url,
                        Error = ((dynamic)r).Error,
                        HasAuthentication = false // Default for fallback
                    }),
                    Note = "Fallback response - IntegrationApiService may not be running"
                };

                return Ok(fallbackResponse);
            }
            catch (Exception ex)
            {
                return StatusCode(503, new { 
                    Error = ex.Message, 
                    CheckedAt = DateTime.UtcNow,
                    TotalAPIs = 0,
                    HealthyAPIs = 0,
                    UnhealthyAPIs = 0,
                    HealthPercentage = 0,
                    APIs = new object[0]
                });
            }
        }

        private async Task<object> CheckServiceAsync(string serviceName, string serviceUrl, string type)
        {
            try
            {
                using var client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(10);
                
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                var response = await client.GetAsync(serviceUrl);
                stopwatch.Stop();

                return new
                {
                    ServiceName = serviceName,
                    Url = serviceUrl,
                    StatusCode = (int)response.StatusCode,
                    IsHealthy = response.IsSuccessStatusCode,
                    ResponseTime = stopwatch.ElapsedMilliseconds,
                    Status = response.IsSuccessStatusCode ? "Healthy" : "Unhealthy",
                    Type = type
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    ServiceName = serviceName,
                    Url = serviceUrl,
                    StatusCode = 0,
                    IsHealthy = false,
                    ResponseTime = 0L,
                    Status = "Unreachable",
                    Error = ex.Message,
                    Type = type
                };
            }
        }

        private async Task<object> CheckExternalApiAsync(string apiName, string apiUrl)
        {
            try
            {
                using var client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(30);
                
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                var response = await client.GetAsync(apiUrl);
                stopwatch.Stop();

                var content = await response.Content.ReadAsStringAsync();
                object? apiResult = null;
                
                if (response.IsSuccessStatusCode)
                {
                    try
                    {
                        apiResult = System.Text.Json.JsonSerializer.Deserialize<object>(content);
                    }
                    catch
                    {
                        apiResult = content;
                    }
                }

                return new
                {
                    ServiceName = apiName,
                    Url = apiUrl,
                    StatusCode = (int)response.StatusCode,
                    IsHealthy = response.IsSuccessStatusCode,
                    ResponseTime = stopwatch.ElapsedMilliseconds,
                    Status = response.IsSuccessStatusCode ? "Healthy" : "Unhealthy",
                    Type = "ExternalAPI",
                    Details = apiResult,
                    Error = response.IsSuccessStatusCode ? null : content
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    ServiceName = apiName,
                    Url = apiUrl,
                    StatusCode = 0,
                    IsHealthy = false,
                    ResponseTime = 0L,
                    Status = "Unreachable",
                    Error = ex.Message,
                    Type = "ExternalAPI"
                };
            }
        }

        private static int ExtractPort(string url)
        {
            try
            {
                var uri = new Uri(url);
                return uri.Port;
            }
            catch
            {
                return 0;
            }
        }
    }
}