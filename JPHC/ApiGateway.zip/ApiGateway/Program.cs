﻿using Ocelot.DependencyInjection;
using Ocelot.Middleware;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Text.Json;

WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

IConfigurationRoot config = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
// var env = config.GetSection("Environment").Value;

//var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
//builder.Environment.EnvironmentName

builder.Configuration.SetBasePath(builder.Environment.ContentRootPath)
    .AddJsonFile("ocelot.json", optional: false, reloadOnChange: true);
//    .AddJsonFile($"ocelot.{env}.json", optional: false, reloadOnChange: true);
//.AddEnvironmentVariables();

// Add Controllers
builder.Services.AddControllers();

builder.Services.AddOcelot(builder.Configuration);

builder.Services.AddCors();

// Configure HttpClient for health checks
builder.Services.AddHttpClient();

// Add Health Checks for all downstream APIs
builder.Services.AddHealthChecks()
    // Authentication API Service (Port: 5209)
    .AddCheck("AuthenticationApiService", () => CheckServiceHealth("http://localhost:5209/health"), 
        tags: new[] { "api", "authentication" })
    // Project API Service (Port: 5059)
    .AddCheck("ProjectApiService", () => CheckServiceHealth("http://localhost:5059/health"), 
        tags: new[] { "api", "project" })
    // Watira API Service (Port: 5010)
    .AddCheck("WatiraApiService", () => CheckServiceHealth("http://localhost:5010/health"), 
        tags: new[] { "api", "watira" })
    // Meeting Calendar API Service (Port: 5015)
    .AddCheck("MeetingCalendarApiService", () => CheckServiceHealth("http://localhost:5015/health"), 
        tags: new[] { "api", "meeting" })
    // HR Admin API Service (Port: 5002)
    .AddCheck("HRAdminApiService", () => CheckServiceHealth("http://localhost:5002/health"), 
        tags: new[] { "api", "hr" })
    // Announcement API Service (Port: 5136)
    .AddCheck("AnnouncementApiService", () => CheckServiceHealth("http://localhost:5136/health"), 
        tags: new[] { "api", "announcement" })
    // Integration API Service (Port: 5005)
    .AddCheck("IntegrationApiService", () => CheckServiceHealth("http://localhost:5005/health"), 
        tags: new[] { "api", "integration" })
    // Notification API Service (Port: 5100)
    .AddCheck("NotificationApiService", () => CheckServiceHealth("http://localhost:5100/health"), 
        tags: new[] { "api", "notification" })
    // Department Website API Service (Port: 5075)
    .AddCheck("DepartmentWebsiteApiService", () => CheckServiceHealth("http://localhost:5075/health"), 
        tags: new[] { "api", "department" })
    // Survey API Service (Port: 5006)
    .AddCheck("SurveyApiService", () => CheckServiceHealth("http://localhost:5006/health"), 
        tags: new[] { "api", "survey" });

WebApplication app = builder.Build();

//Add CORS Policy
app.UseCors(c =>
{
    c.AllowAnyHeader().AllowAnyMethod().AllowCredentials().WithOrigins(builder.Configuration.GetSection("RouteConfig:CorsAllow:AllowedOrigins").Value.Split(","));
});

// Enable static files
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// Handle health check requests before Ocelot
app.Use(async (context, next) =>
{
    var path = context.Request.Path.Value?.ToLower();
    
    // If it's a health check related request, let it pass to controllers
    if (path != null && (path.StartsWith("/api/health") || path.StartsWith("/api/status") || 
                        path.StartsWith("/health") || path.Equals("/health-ui")))
    {
        await next();
        return;
    }
    
    // Otherwise, continue to Ocelot
    await next();
});

// Map Controllers
app.MapControllers();

// Map Health Check endpoints
app.MapHealthChecks("/health", new HealthCheckOptions()
{
    Predicate = _ => true,
    ResponseWriter = WriteResponse
});

app.MapHealthChecks("/health/ready", new HealthCheckOptions()
{
    Predicate = check => check.Tags.Contains("ready"),
    ResponseWriter = WriteResponse
});

app.MapHealthChecks("/health/live", new HealthCheckOptions()
{
    Predicate = _ => true,
    ResponseWriter = WriteResponse
});

// Redirect to health dashboard
app.MapGet("/health-ui", async context =>
{
    context.Response.Redirect("/health-dashboard.html");
});

// Add Ocelot middleware with exclusions for health endpoints
app.UseWhen(
    context => !context.Request.Path.StartsWithSegments("/api/health") &&
               !context.Request.Path.StartsWithSegments("/api/status") &&
               !context.Request.Path.StartsWithSegments("/health") &&
               !context.Request.Path.StartsWithSegments("/health-ui"),
    appBuilder =>
    {
        appBuilder.UseOcelot().Wait();
    });

app.Run();

// Health check method
static HealthCheckResult CheckServiceHealth(string url)
{
    try
    {
        using var client = new HttpClient();
        client.Timeout = TimeSpan.FromSeconds(10);
        var response = client.GetAsync(url).Result;
        
        if (response.IsSuccessStatusCode)
        {
            return HealthCheckResult.Healthy($"Service at {url} is healthy");
        }
        else
        {
            return HealthCheckResult.Unhealthy($"Service at {url} returned {response.StatusCode}");
        }
    }
    catch (Exception ex)
    {
        return HealthCheckResult.Unhealthy($"Service at {url} is unreachable: {ex.Message}");
    }
}

// Custom response writer
static Task WriteResponse(HttpContext httpContext, HealthReport result)
{
    httpContext.Response.ContentType = "application/json";

    var response = new
    {
        Status = result.Status.ToString(),
        Duration = result.TotalDuration,
        Info = result.Entries.Select(e => new
        {
            Key = e.Key,
            Description = e.Value.Description,
            Status = e.Value.Status.ToString(),
            Duration = e.Value.Duration
        })
    };

    return httpContext.Response.WriteAsync(JsonSerializer.Serialize(response));
}

