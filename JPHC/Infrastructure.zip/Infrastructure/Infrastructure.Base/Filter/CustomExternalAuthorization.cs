﻿using JointPortal.Data.Interface.Auth;
using JointPortal.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;

namespace Infrastructure.Base.Filter
{
    public class CustomExternalAuthorization : TypeFilterAttribute
    {
        public CustomExternalAuthorization() : base(typeof(ExternalTokenAuthorizationFilter))
        {
        }
    }

    public class ExternalTokenAuthorizationFilter : Attribute, IAuthorizationFilter
    {
        private readonly IAuthService _authService;
        private readonly string externalAuthKey;
        private RouteConfig _rootConfig;
        public ExternalTokenAuthorizationFilter(IOptions<RouteConfig> rootConfig, IAuthService authService)
        {
            _authService = authService;
            _rootConfig = rootConfig.Value;
            externalAuthKey = _rootConfig.ExternalAuthKey;
        }


        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.Items["startRequestTime"] = DateTime.Now;
            filterContext.HttpContext.Items["transId"] = Guid.NewGuid().ToString();

            //Validate Token and Token Expiry
            string token = filterContext.HttpContext.Request?.Headers["AuthorizationKey"].FirstOrDefault()?.Split(" ").Last();

            string consumer = filterContext.HttpContext.Request?.Headers["Consumer"].FirstOrDefault()?.Split(" ").Last();
            if (consumer != null)
            {
                filterContext.HttpContext.Items["Consumer"] = consumer;
            }
            if (token != externalAuthKey)
            {
                filterContext.Result = new JsonResult(new
                {
                    StatusCode = StatusCodes.Status401Unauthorized,
                    Message = "Token Validation Has Failed. Request Access Denied"
                })
                {
                    StatusCode = StatusCodes.Status401Unauthorized
                };
                return;
            }

        }

    }
}
