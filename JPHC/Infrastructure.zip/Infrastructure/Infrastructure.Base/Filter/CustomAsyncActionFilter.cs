﻿using JointPortal.Data.Context;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Text;

namespace Infrastructure.Base.Filter
{
    public class CustomAsyncActionFilter : IAsyncActionFilter
    {

        private readonly string _actionName;
        private readonly string _moduleName;
        private readonly DataContext _dataContext;


        public CustomAsyncActionFilter(DataContext dataContext)
        {
            //_actionName = actionName;
            //_moduleName = moduleName;
            _dataContext = dataContext;
        }
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            HttpContext httpContext = context.HttpContext;
            HttpRequest request = httpContext.Request;

            string requestUrl = $"{request.Scheme}://{request.Host}{request.Path}{request.QueryString}";
            Console.WriteLine(requestUrl);

            await next();


        }

        public class CustomResultFilter : IAsyncResultFilter
        {


            public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
            {


                await next();


            }
        }

        private async Task<string> FormatRequest(HttpRequest request)
        {
            request.EnableBuffering();
            byte[] buffer = new byte[Convert.ToInt32(request.ContentLength)];
            await request.Body.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
            string bodyAsText = Encoding.UTF8.GetString(buffer);
            request.Body.Position = 0;
            return $"{Environment.NewLine}{Environment.NewLine}{Environment.NewLine}{request.Scheme}  {request.Host}{request.Path} {request.QueryString}  {bodyAsText}{Environment.NewLine}{Environment.NewLine}";
        }

        private async Task<string> FormatResponse(HttpResponse response)
        {
            //We need to read the response stream from the beginning...
            response.Body.Seek(0, SeekOrigin.Begin);
            //...and copy it into a string
            string text = await new StreamReader(response.Body).ReadToEndAsync();
            //We need to reset the reader for the response so that the client can  read it.
            response.Body.Seek(0, SeekOrigin.Begin);
            //Return the string for the response, including the status code (e.g.  200, 404, 401, etc.)
            return $"{response.StatusCode}: {text}";
        }
    }
}
