﻿using JointPortal.Data.Interface.Auth;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.IdentityModel.Tokens.Jwt;

namespace Infrastructure.Base.Filter
{

    public class CustomAuthorizationAttribute : TypeFilterAttribute
    {
        public CustomAuthorizationAttribute() : base(typeof(TokenAuthorizationFilter))
        {
        }
    }


    public class TokenAuthorizationFilter : Attribute, IAuthorizationFilter
    {
        private readonly IAuthService _authService;



        public TokenAuthorizationFilter(IAuthService authService)
        {

            _authService = authService;

        }
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.Items["startRequestTime"] = DateTime.Now;
            filterContext.HttpContext.Items["transId"] = Guid.NewGuid().ToString();
            if (!filterContext.HttpContext.User.Identity.IsAuthenticated)
            {
                // user not authorized

                filterContext.Result = new JsonResult(new
                {
                    StatusCode = StatusCodes.Status401Unauthorized,
                    Message = "Token Validation Has Failed. Request Access Denied"
                })
                {
                    StatusCode = StatusCodes.Status401Unauthorized
                };
                return;
            }

            //Validate Token and Token Expiry
            string token = filterContext.HttpContext.Request?.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

            filterContext.HttpContext.Items["UserId"] = filterContext.HttpContext.Request?.Headers["Username"].FirstOrDefault()?.Split(" ").Last();
            string consumer = filterContext.HttpContext.Request?.Headers["Consumer"].FirstOrDefault()?.Split(" ").Last();
            string language = filterContext.HttpContext.Request?.Headers["Language"].FirstOrDefault()?.Split(" ").Last();
            if (consumer != null)
            {
                filterContext.HttpContext.Items["Consumer"]=consumer;
            }
            else
            {
                filterContext.HttpContext.Items["Consumer"] = "JointPortal";
            }

            if (language != null)
            {
                filterContext.HttpContext.Items["Language"] = language;
            }
            else
            {
                filterContext.HttpContext.Items["Language"] = "En";
            }
            if (token != null)
            {
                if (!_authService.ValidateAccessToken(token))
                {

                    filterContext.Result = new JsonResult(new
                    {
                        StatusCode = StatusCodes.Status401Unauthorized,
                        Message = "Token Validation Has Failed. Request Access Denied"
                    })
                    {
                        StatusCode = StatusCodes.Status401Unauthorized
                    };
                    return;

                }

                if (!CheckTokenIsValid(token))
                {

                    filterContext.Result =
                    new JsonResult(new
                    {
                        StatusCode = StatusCodes.Status401Unauthorized,
                        Message = "Token Validation Has Failed. Request Access Denied"
                    })
                    {
                        StatusCode = StatusCodes.Status401Unauthorized
                    };
                    return;

                }
            }

        }

        public static long GetTokenExpirationTime(string token)
        {
            JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
            JwtSecurityToken jwtSecurityToken = handler.ReadJwtToken(token);
            string tokenExp = jwtSecurityToken.Claims.First(claim => claim.Type.Equals("exp")).Value;
            long ticks = long.Parse(tokenExp);
            return ticks;
        }

        public static bool CheckTokenIsValid(string token)
        {
            // For Back  up
            //var tokenTicks = GetTokenExpirationTime(token);
            //var tokenDate = DateTimeOffset.FromUnixTimeSeconds(tokenTicks).UtcDateTime;

            long tokenTicks = GetTokenExpirationTime(token);
            DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds(tokenTicks);
            DateTime tokenDate = dateTimeOffset.LocalDateTime;

            //var now = DateTime.Now.()();
            bool valid = tokenDate >= DateTime.Now;

            return valid;
        }


    }
}
