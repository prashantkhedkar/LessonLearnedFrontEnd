﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Infrastructure.Base.Filter
{

    public class ExceptionFilter : IAsyncExceptionFilter
    {

        public Task OnExceptionAsync(ExceptionContext context)
        {

            // Set the result
            context.Result = new JsonResult(new
            {
                StatusCode = StatusCodes.Status500InternalServerError,
                Message = "Something went wrong! Internal Server Error."
            })
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };

            return Task.CompletedTask;
        }
    }
}
