﻿using JointPortal.Data.Constants;
using JointPortal.Data.Logs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Net.Http;
using System.Text;

namespace Infrastructure.Base.Filter
{
    public class LogFilter: ActionFilterAttribute
    {
        private readonly IDbLog _idbLog;
        private MemoryStream responseBody;
        private MemoryStream requestBody;
        public LogFilter(IDbLog idbLog) {
            _idbLog = idbLog;
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //...work with the filterContext object before executing the method

            this.responseBody = new MemoryStream();
           
            //// hijack the real stream with our own memory stream 
           filterContext.HttpContext.Response.Body = responseBody;
            
          
            filterContext.HttpContext.Items["startRequestTime"] = DateTime.Now;
            HttpRequest request = filterContext.HttpContext.Request;
          //  var result = BodyToString(request)
        //filterContext.HttpContext.Items["path"] = request.Path;


        ;
        }
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
           
        }

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            // responseBody.Seek(0, SeekOrigin.Begin);
            //var actionName = filterContext.RouteData.Values["action"];
            //HttpRequest request = filterContext.HttpContext.Request;
            //// read our own memory stream 
            //using (StreamReader sr = new StreamReader(responseBody))
            //{
            //    var actionResult = sr.ReadToEnd();
            //    Console.WriteLine(actionResult);
            //    _idbLog.LoggRequestAsync(request.Body, actionResult, actionName.ToString(), request.Path, LogStatus.SUCCESS);
            //}

            //// // no ERROR on the next line!

            //base.OnResultExecuted(filterContext);

            responseBody.Seek(0, SeekOrigin.Begin);

            // read our own memory stream 
            using (StreamReader sr = new StreamReader(responseBody))
            {
                var actionResult = sr.ReadToEnd();
                Console.WriteLine(actionResult);
                // create new stream and sr it to body 
                Stream stream = new MemoryStream();

                filterContext.HttpContext.Response.Body.CopyToAsync(stream);
            }

            // no ERROR on the next line!

            base.OnResultExecuted(filterContext);


        }
        //public  string BodyToString(this HttpRequest request)
        //{
        //    var returnValue = string.Empty;
            
        //    //ensure we read from the begining of the stream - in case a reader failed to read to end before us.
        //    request.Body.Position = 0;
        //    //use the leaveOpen parameter as true so further reading and processing of the request body can be done down the pipeline
        //    using (var stream = new StreamReader(request.Body, Encoding.UTF8, true, 1024, leaveOpen: true))
        //    {
        //        returnValue = stream.ReadToEnd();
        //    }
        //    //reset position to ensure other readers have a clear view of the stream 
        //    request.Body.Position = 0;
        //    return returnValue;
        //}

    }
}
