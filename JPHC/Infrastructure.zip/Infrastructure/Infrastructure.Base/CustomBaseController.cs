﻿using Infrastructure.Base.Filter;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.StaticFiles;
using System.Security.Claims;

namespace Infrastructure.Base
{
    [CustomAuthorization]
    public class CustomBaseController : BaseController
    {
        protected  Dictionary<string, string> resources;
        private readonly IHttpContextAccessor _httpContextAccessor;

        //Enhancement
        public CustomBaseController(IHttpContextAccessor httpContextAccessor) : base(httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        protected string? GetUserId()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            var identity1 = User.Identity as ClaimsIdentity;
            Claim? identityClaim = identity1?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
            var userId = identityClaim?.Value;

            return userId;
        }

        protected string? GetUserEmail()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            var identity1 = User.Identity as ClaimsIdentity;
            Claim? identityClaim = identity1?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name);
            var userEmail = identityClaim?.Value;

            return userEmail;
        }
        
        protected string? GetResource(string key)
        {
            if (resources != null && resources.Count > 0)
            {
                return resources.GetValueOrDefault(key);
            }
            return key;
        }

        protected string GetMimeTypeForFileExtension(string filePath)
        {
            const string DefaultContentType = "application/octet-stream";

            var provider = new FileExtensionContentTypeProvider();

            if (!provider.TryGetContentType(filePath, out string? contentType))
            {
                contentType = DefaultContentType;
            }

            return contentType;
        }

        protected string? GetLanguage()
        {
            string language = _httpContextAccessor.HttpContext.Request?.Headers["Language"].FirstOrDefault()?.Split(" ").Last();
            if (string.IsNullOrWhiteSpace(language))
            {
                language = "en";
            }
            return language;
        }

        protected string? GetUserRole()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            var identity1 = User.Identity as ClaimsIdentity;
            Claim? identityClaim = identity1?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);
            var userId = identityClaim?.Value;

            return userId;
        }

        protected string? GetUnitId()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            var identity1 = User.Identity as ClaimsIdentity;
            Claim? identityClaim = identity1?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.GroupSid);
            var userId = identityClaim?.Value;

            return userId;
        }

        protected string? GetMainUnitId()
        {
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            var identity1 = User.Identity as ClaimsIdentity;
            Claim? identityClaim = identity1?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.PrimaryGroupSid);
            var userId = identityClaim?.Value;

            return userId;
        }
    }
}
