﻿using Infrastructure.Base.Model;

using Microsoft.AspNetCore.Mvc;
using System.Net;

namespace Infrastructure.Base
{
    public class BaseController : ControllerBase
    {
        public readonly IHttpContextAccessor _httpContextAccessor;
        public BaseController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor= httpContextAccessor;
        }
        protected IActionResult CustomResult(string message, HttpStatusCode code = HttpStatusCode.OK)
        {
            ApiResponse apiResponse = new ApiResponse(message);
            apiResponse.StatusCode = (int)code;
            apiResponse.tranxId = _httpContextAccessor.HttpContext.Items["transId"].ToString();
            HttpResponseMessage httpResponseMessage = new HttpResponseMessage(code);
            return new HttpCustomResponse(base.Request, code, apiResponse);
        }

        protected IActionResult CustomResult(object data, HttpStatusCode code = HttpStatusCode.OK)
        {
            ApiResponse apiResponse = new ApiResponse("", data);
            apiResponse.StatusCode = (int)code;
            apiResponse.Data = data;
            return new HttpCustomResponse(base.Request, code, apiResponse);
        }

        protected IActionResult CustomResult(string message, object data, HttpStatusCode code = HttpStatusCode.OK)
        {
            ApiResponse apiResponse = new ApiResponse(message, data);
            apiResponse.StatusCode = (int)code;
            apiResponse.Data = data;
            return new HttpCustomResponse(base.Request, code, apiResponse);
        }

        protected IActionResult CustomResult(HttpStatusCode code = HttpStatusCode.OK)
        {
            return new HttpCustomResponse(base.Request, code, null);
        }
    

        }
}
