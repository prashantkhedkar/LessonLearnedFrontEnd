using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace STApplicationHealthCheck.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatusController : ControllerBase
    {
        private static readonly Dictionary<string, string> ServiceUrls = new()
        {
            { "ApiGateway", "http://localhost:5551/health" },
            { "AuthenticationApiService", "http://localhost:5209/health" },
            { "ProjectApiService", "http://localhost:5059/health" },
            { "WatiraApiService", "http://localhost:5010/health" },
            { "MeetingCalendarApiService", "http://localhost:5015/health" },
            { "HRAdminApiService", "http://localhost:5002/health" },
            { "AnnouncementApiService", "http://localhost:5136/health" },
            { "IntegrationApiService", "http://localhost:5005/health" },
            { "NotificationApiService", "http://localhost:5100/health" },
            { "DepartmentWebsiteApiService", "http://localhost:5075/health" },
            //{ "SurveyApiService", "http://localhost:5006/health" }
        };

        private static readonly string[] ApiGatewayEndpoints = new[]
        {
            "http://localhost:5551/health",
            "http://localhost:5551/api/health",
            "http://localhost:5551",
            "http://localhost:56927/health",
            "http://localhost:56927"
        };

        private static readonly Dictionary<string, string> ExternalApiUrls = new()
        {
            { "MawjoodAPI", "http://localhost:5005/api/ExternalHealth/mawjood" },
            { "TarasulAPI", "http://localhost:5005/api/ExternalHealth/tarasul" },
            { "MawardAPI", "http://localhost:5005/api/ExternalHealth/maward" }
        };

        [HttpGet("services")]
        public IActionResult GetServices()
        {
            var services = ServiceUrls.Select(kvp => new
            {
                Name = kvp.Key,
                Url = kvp.Value,
                Port = ExtractPort(kvp.Value),
                Type = kvp.Key == "ApiGateway" ? "Gateway" : "Microservice"
            });

            return Ok(services);
        }

        [HttpGet("external-apis")]
        public IActionResult GetExternalApis()
        {
            var externalApis = ExternalApiUrls.Select(kvp => new
            {
                Name = kvp.Key,
                Url = kvp.Value,
                Type = "ExternalAPI"
            });

            return Ok(externalApis);
        }

        // Test endpoint to inspect raw health check response
        [HttpGet("debug-auth-health")]
        public async Task<IActionResult> DebugAuthHealth()
        {
            try
            {
                using HttpClient client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(60);

                HttpResponseMessage response = await client.GetAsync("http://localhost:5209/health");
                string content = await response.Content.ReadAsStringAsync();

                return Ok(new
                {
                    StatusCode = (int)response.StatusCode,
                    IsSuccessStatusCode = response.IsSuccessStatusCode,
                    RawContent = content,
                    ContentLength = content.Length,
                    Headers = response.Headers.ToDictionary(h => h.Key, h => string.Join(", ", h.Value))
                });
            }
            catch (Exception ex)
            {
                return Ok(new
                {
                    Error = ex.Message,
                    ErrorType = ex.GetType().Name
                });
            }
        }

        [HttpGet("all")]
        public async Task<IActionResult> CheckAllServices()
        {
            List<Task<object>> tasks = new List<Task<object>>();

            foreach (KeyValuePair<string, string> kvp in ServiceUrls)
            {
                string serviceType = kvp.Key == "ApiGateway" ? "Gateway" : "Microservice";
                tasks.Add(CheckServiceAsync(kvp.Key, kvp.Value, serviceType));
            }

            object[] results = await Task.WhenAll(tasks);

            var summary = new
            {
                TotalServices = results.Length,
                HealthyServices = results.Count(r => ((dynamic)r).IsHealthy == true),
                UnhealthyServices = results.Count(r => ((dynamic)r).IsHealthy == false),
                CheckedAt = DateTime.UtcNow,
                Services = results
            };

            bool allHealthy = results.All(r => ((dynamic)r).IsHealthy == true);
            return allHealthy ? Ok(summary) : StatusCode(503, summary);
        }

        [HttpGet("all-with-external")]
        public async Task<IActionResult> CheckAllServicesAndExternalApis()
        {
            List<Task<object>> tasks = new List<Task<object>>();

            foreach (KeyValuePair<string, string> kvp in ServiceUrls)
            {
                string serviceType = kvp.Key == "ApiGateway" ? "Gateway" : "Microservice";
                tasks.Add(CheckServiceAsync(kvp.Key, kvp.Value, serviceType));
            }

            foreach (KeyValuePair<string, string> kvp in ExternalApiUrls)
            {
                tasks.Add(CheckExternalApiAsync(kvp.Key, kvp.Value));
            }

            object[] results = await Task.WhenAll(tasks);

            object[] infrastructureServices = results.Where(r => ((dynamic)r).Type == "Gateway").ToArray();
            object[] microservices = results.Where(r => ((dynamic)r).Type == "Microservice").ToArray();
            object[] externalApis = results.Where(r => ((dynamic)r).Type == "ExternalAPI").ToArray();

            var summary = new
            {
                TotalServices = infrastructureServices.Length + microservices.Length,
                HealthyServices = infrastructureServices.Count(r => ((dynamic)r).IsHealthy == true) +
                                microservices.Count(r => ((dynamic)r).IsHealthy == true),
                UnhealthyServices = infrastructureServices.Count(r => ((dynamic)r).IsHealthy == false) +
                                   microservices.Count(r => ((dynamic)r).IsHealthy == false),
                TotalExternalApis = externalApis.Length,
                HealthyExternalApis = externalApis.Count(r => ((dynamic)r).IsHealthy == true),
                UnhealthyExternalApis = externalApis.Count(r => ((dynamic)r).IsHealthy == false),
                CheckedAt = DateTime.UtcNow,
                Gateway = infrastructureServices,
                Microservices = microservices,
                ExternalAPIs = externalApis
            };

            bool allHealthy = results.All(r => ((dynamic)r).IsHealthy == true);
            return allHealthy ? Ok(summary) : StatusCode(503, summary);
        }

        [HttpGet("external-only")]
        public async Task<IActionResult> CheckExternalApisOnly()
        {
            try
            {
                using HttpClient client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(30);

                try
                {
                    HttpResponseMessage response = await client.GetAsync("http://localhost:5005/api/ExternalHealth/all-external");
                    string content = await response.Content.ReadAsStringAsync();

                    if (response.IsSuccessStatusCode)
                    {
                        object? externalApiStatus = JsonSerializer.Deserialize<object>(content);
                        return Ok(externalApiStatus);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"IntegrationApiService not available: {ex.Message}");
                }

                List<Task<object>> tasks = new List<Task<object>>();
                foreach (KeyValuePair<string, string> kvp in ExternalApiUrls)
                {
                    tasks.Add(CheckExternalApiAsync(kvp.Key, kvp.Value));
                }

                object[] results = await Task.WhenAll(tasks);

                int healthyCount = results.Count(r => ((dynamic)r).IsHealthy == true);
                int totalCount = results.Length;

                var fallbackResponse = new
                {
                    TotalAPIs = totalCount,
                    HealthyAPIs = healthyCount,
                    UnhealthyAPIs = totalCount - healthyCount,
                    HealthPercentage = totalCount > 0 ? (healthyCount * 100.0 / totalCount) : 0,
                    CheckedAt = DateTime.UtcNow,
                    APIs = results.Select(r => new
                    {
                        ApiName = ((dynamic)r).ServiceName,
                        IsHealthy = ((dynamic)r).IsHealthy,
                        StatusCode = ((dynamic)r).StatusCode,
                        ResponseTime = ((dynamic)r).ResponseTime,
                        Url = ((dynamic)r).Url,
                        Error = ((dynamic)r).Error,
                        HasAuthentication = false
                    }),
                    Note = "Fallback response - IntegrationApiService may not be running"
                };

                return Ok(fallbackResponse);
            }
            catch (Exception ex)
            {
                return StatusCode(503, new
                {
                    Error = ex.Message,
                    CheckedAt = DateTime.UtcNow,
                    TotalAPIs = 0,
                    HealthyAPIs = 0,
                    UnhealthyAPIs = 0,
                    HealthPercentage = 0,
                    APIs = new object[0]
                });
            }
        }

        private async Task<object> CheckServiceAsync(string serviceName, string serviceUrl, string type)
        {
            if (serviceName == "ApiGateway")
            {
                return await CheckApiGatewayAsync();
            }

            try
            {
                using HttpClient client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(60);

                System.Diagnostics.Stopwatch stopwatch = System.Diagnostics.Stopwatch.StartNew();
                HttpResponseMessage response = await client.GetAsync(serviceUrl);
                stopwatch.Stop();

                string content = await response.Content.ReadAsStringAsync();
                string? detailedError = null;

                // Always try to parse the response content, regardless of status code
                try
                {
                    // First, let's see if it's JSON
                    using JsonDocument document = JsonDocument.Parse(content);
                    JsonElement root = document.RootElement;

                    // Check for ASP.NET Core health check format
                    if (root.TryGetProperty("info", out JsonElement infoArray) && infoArray.ValueKind == JsonValueKind.Array)
                    {
                        foreach (JsonElement entry in infoArray.EnumerateArray())
                        {
                            if (entry.TryGetProperty("key", out JsonElement keyElement))
                            {
                                string? key = keyElement.GetString();
                                if (entry.TryGetProperty("status", out JsonElement status) &&
                                    status.GetString() != "Healthy")
                                {
                                    if (entry.TryGetProperty("description", out JsonElement description))
                                    {
                                        detailedError = $"{key}: {description.GetString()}";
                                        break;
                                    }
                                }
                            }
                        }
                    }

                    // If no error found in info array, check the main status and description
                    if (string.IsNullOrEmpty(detailedError))
                    {
                        if (root.TryGetProperty("status", out JsonElement mainStatus))
                        {
                            string? statusText = mainStatus.GetString();
                            if (statusText != "Healthy")
                            {
                                // Look for any description at root level
                                if (root.TryGetProperty("description", out JsonElement desc))
                                {
                                    detailedError = desc.GetString();
                                }
                                else
                                {
                                    detailedError = $"Service status: {statusText}";
                                }
                            }
                        }
                    }
                }
                catch (JsonException)
                {
                    // If it's not JSON, use the raw content as error
                    if (!response.IsSuccessStatusCode)
                    {
                        detailedError = content.Length > 200 ? content.Substring(0, 200) + "..." : content;
                    }
                }

                // If still no specific error and the service is unhealthy, use the raw content
                if (string.IsNullOrEmpty(detailedError) && !response.IsSuccessStatusCode)
                {
                    detailedError = string.IsNullOrWhiteSpace(content) ?
                        $"HTTP {response.StatusCode} - No additional error details" :
                        (content.Length > 200 ? content.Substring(0, 200) + "..." : content);
                }

                return new
                {
                    ServiceName = serviceName,
                    Url = serviceUrl,
                    StatusCode = (int)response.StatusCode,
                    IsHealthy = response.IsSuccessStatusCode,
                    ResponseTime = stopwatch.ElapsedMilliseconds,
                    Status = response.IsSuccessStatusCode ? "Healthy" : "Unhealthy",
                    Type = type,
                    Error = detailedError,
                    RawResponse = content.Length > 1000 ? content.Substring(0, 1000) + "... [truncated]" : content // For debugging
                };
            }
            catch (TaskCanceledException)
            {
                return new
                {
                    ServiceName = serviceName,
                    Url = serviceUrl,
                    StatusCode = 0,
                    IsHealthy = false,
                    ResponseTime = 0L,
                    Status = "Timeout",
                    Error = $"Health check timeout after 60 seconds. For {serviceName}, this likely indicates database connection issues. Check SQL Server connection: {GetConnectionStringInfo(serviceName)}",
                    Type = type
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    ServiceName = serviceName,
                    Url = serviceUrl,
                    StatusCode = 0,
                    IsHealthy = false,
                    ResponseTime = 0L,
                    Status = "Unreachable",
                    Error = ex.Message,
                    Type = type
                };
            }
        }

        private string GetConnectionStringInfo(string serviceName)
        {
            if (serviceName == "AuthenticationApiService")
            {
                return "Server=LAD0061851\\SQLEXPRESS;Database=JointPortal_QA";
            }
            return "Database connection may be required";
        }

        private async Task<object> CheckApiGatewayAsync()
        {
            foreach (string endpoint in ApiGatewayEndpoints)
            {
                try
                {
                    using HttpClient client = new HttpClient();
                    client.Timeout = TimeSpan.FromSeconds(15);

                    System.Diagnostics.Stopwatch stopwatch = System.Diagnostics.Stopwatch.StartNew();
                    HttpResponseMessage response = await client.GetAsync(endpoint);
                    stopwatch.Stop();

                    if (response.IsSuccessStatusCode)
                    {
                        return new
                        {
                            ServiceName = "ApiGateway",
                            Url = endpoint,
                            StatusCode = (int)response.StatusCode,
                            IsHealthy = true,
                            ResponseTime = stopwatch.ElapsedMilliseconds,
                            Status = "Healthy",
                            Type = "Gateway",
                            Note = endpoint != ApiGatewayEndpoints[0] ? "Connected via fallback endpoint" : null
                        };
                    }
                }
                catch (Exception)
                {
                    continue;
                }
            }

            return new
            {
                ServiceName = "ApiGateway",
                Url = "Multiple endpoints tested",
                StatusCode = 0,
                IsHealthy = false,
                ResponseTime = 0L,
                Status = "Unreachable",
                Error = "All API Gateway endpoints unreachable",
                Type = "Gateway",
                TestedEndpoints = ApiGatewayEndpoints
            };
        }

        private async Task<object> CheckExternalApiAsync(string apiName, string apiUrl)
        {
            try
            {
                using HttpClient client = new HttpClient();
                client.Timeout = TimeSpan.FromSeconds(30);

                System.Diagnostics.Stopwatch stopwatch = System.Diagnostics.Stopwatch.StartNew();
                HttpResponseMessage response = await client.GetAsync(apiUrl);
                stopwatch.Stop();

                string content = await response.Content.ReadAsStringAsync();
                object? apiResult = null;

                if (response.IsSuccessStatusCode)
                {
                    try
                    {
                        apiResult = JsonSerializer.Deserialize<object>(content);
                    }
                    catch
                    {
                        apiResult = content;
                    }
                }

                return new
                {
                    ServiceName = apiName,
                    Url = apiUrl,
                    StatusCode = (int)response.StatusCode,
                    IsHealthy = response.IsSuccessStatusCode,
                    ResponseTime = stopwatch.ElapsedMilliseconds,
                    Status = response.IsSuccessStatusCode ? "Healthy" : "Unhealthy",
                    Type = "ExternalAPI",
                    Details = apiResult,
                    Error = response.IsSuccessStatusCode ? null : content
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    ServiceName = apiName,
                    Url = apiUrl,
                    StatusCode = 0,
                    IsHealthy = false,
                    ResponseTime = 0L,
                    Status = "Unreachable",
                    Error = ex.Message,
                    Type = "ExternalAPI"
                };
            }
        }

        private static int ExtractPort(string url)
        {
            try
            {
                Uri uri = new Uri(url);
                return uri.Port;
            }
            catch
            {
                return 0;
            }
        }
    }
}