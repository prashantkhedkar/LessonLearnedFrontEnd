using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using STApplicationHealthCheck.HealthChecks;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure HttpClient for health checks
builder.Services.AddHttpClient<ApiGatewayHealthCheck>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(15);
});

builder.Services.AddHttpClient();

// Add Health Checks for all downstream APIs
builder.Services.AddHealthChecks()
    .AddCheck<ApiGatewayHealthCheck>("ApiGateway", 
        tags: new[] { "infrastructure", "gateway", "critical" })
    .AddCheck("AuthenticationApiService", () => CheckServiceHealth("http://localhost:5209/health"), 
        tags: new[] { "api", "authentication", "database" })
    .AddCheck("ProjectApiService", () => CheckServiceHealth("http://localhost:5059/health"), 
        tags: new[] { "api", "project" })
    .AddCheck("WatiraApiService", () => CheckServiceHealth("http://localhost:5010/health"), 
        tags: new[] { "api", "watira" })
    .AddCheck("MeetingCalendarApiService", () => CheckServiceHealth("http://localhost:5015/health"), 
        tags: new[] { "api", "meeting" })
    .AddCheck("HRAdminApiService", () => CheckServiceHealth("http://localhost:5002/health"), 
        tags: new[] { "api", "hr" })
    .AddCheck("AnnouncementApiService", () => CheckServiceHealth("http://localhost:5136/health"), 
        tags: new[] { "api", "announcement" })
    .AddCheck("IntegrationApiService", () => CheckServiceHealth("http://localhost:5005/health"), 
        tags: new[] { "api", "integration" })
    .AddCheck("NotificationApiService", () => CheckServiceHealth("http://localhost:5100/health"), 
        tags: new[] { "api", "notification" })
    .AddCheck("DepartmentWebsiteApiService", () => CheckServiceHealth("http://localhost:5075/health"), 
        tags: new[] { "api", "department" })
    .AddCheck("SurveyApiService", () => CheckServiceHealth("http://localhost:5006/health"), 
        tags: new[] { "api", "survey" });

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Enable static files
app.UseStaticFiles();

// Enable CORS
app.UseCors();

app.UseHttpsRedirection();

app.UseRouting();
app.UseAuthorization();

// Map Controllers
app.MapControllers();

// Map Health Check endpoints
app.MapHealthChecks("/health", new HealthCheckOptions()
{
    Predicate = _ => true,
    ResponseWriter = WriteResponse
});

app.MapHealthChecks("/health/ready", new HealthCheckOptions()
{
    Predicate = check => check.Tags.Contains("ready"),
    ResponseWriter = WriteResponse
});

app.MapHealthChecks("/health/live", new HealthCheckOptions()
{
    Predicate = _ => true,
    ResponseWriter = WriteResponse
});

// Redirect routes
app.MapGet("/health-ui", async context =>
{
    context.Response.Redirect("/health-dashboard.html");
});

app.MapGet("/", async context =>
{
    context.Response.Redirect("/health-dashboard.html");
});

app.Run();

// Simplified health check method
static HealthCheckResult CheckServiceHealth(string url)
{
    try
    {
        using var client = new HttpClient();
        client.Timeout = TimeSpan.FromSeconds(60); // Extended timeout for database checks
        var response = client.GetAsync(url).Result;
        
        if (response.IsSuccessStatusCode)
        {
            return HealthCheckResult.Healthy($"Service at {url} is healthy");
        }
        else
        {
            return HealthCheckResult.Unhealthy($"Service at {url} returned HTTP {response.StatusCode}");
        }
    }
    catch (TaskCanceledException)
    {
        return HealthCheckResult.Unhealthy($"Service at {url} timed out after 60 seconds - likely database connection issue");
    }
    catch (Exception ex)
    {
        return HealthCheckResult.Unhealthy($"Service at {url} is unreachable: {ex.Message}");
    }
}

// Custom response writer for health check endpoints
static Task WriteResponse(HttpContext httpContext, HealthReport result)
{
    httpContext.Response.ContentType = "application/json";

    var response = new
    {
        Status = result.Status.ToString(),
        Duration = result.TotalDuration,
        Info = result.Entries.Select(e => new
        {
            Key = e.Key,
            Description = e.Value.Description,
            Status = e.Value.Status.ToString(),
            Duration = e.Value.Duration,
            Data = e.Value.Data
        })
    };

    return httpContext.Response.WriteAsync(JsonSerializer.Serialize(response, new JsonSerializerOptions { WriteIndented = true }));
}
